#include<stdio.h>
#include<stdlib.h>
#include"Lista.h"

int main(){
int val;

	printf("Acquisizione lista 1 \n");
	Lista a=Riempi();
	printf("Stampa lista 1 acquisita \n");
	PrintList(a);

	printf("Acquisizione lista 2 \n");
	Lista b=Riempi();
	printf("Stampa lista 2 acquisita \n");
	PrintList(b);


	esercizio(&a,&b);

	printf("Stampa lista 1 dopo rimozione elem minori di 0 \n");
	PrintList(a);

	printf("Stampa lista 2 dopo rimozione elem maggiori di 0 \n");
	PrintList(b);


	printf("Creazione lista interlaving \n");
	Lista Tre=NULL;
	Tre=interlaving(a,b,Tre);
	printf("Stampa lista interlaving di lista 1 e lista 2\n");
	PrintList(Tre);
	
	return 0;
}
