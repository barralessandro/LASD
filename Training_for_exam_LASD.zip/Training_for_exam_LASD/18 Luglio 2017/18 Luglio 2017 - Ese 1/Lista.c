#include<stdio.h>
#include<stdlib.h>
#include"Lista.h"

Lista AllocaNodo(){
	Lista L=(struct nodo*)malloc(sizeof(struct nodo));
	return L;
}

Lista insOrdinato(Lista Head, int elem){
	if(!ListEmpty(Head) && Head->info<=elem)
		Head->next=insOrdinato(Head->next,elem);
	else{
		if(!ListEmpty(Head)){
			Lista app=AllocaNodo();
			app->info=elem;
			app->prev=Head->prev;
			app->next=Head;
			return app;
			}
		else{	//se è nulla
			Lista app=AllocaNodo();
			app->info=elem;
			return app;
		}
 	}
}

void PrintList(Lista L){
	Lista prova=L;
	if(ListEmpty(prova))
		printf("La lista è vuota \n");
	else{
		while(prova!=NULL){
			printf("%d  ",prova->info);
			prova=prova->next;
			}
		printf("\n");
	}
}

//FUNZIONE DALLE SLIDE DEL PROF
Lista Riempi(){
	Lista p, elem;
	int i,n;
	printf("Quanti elementi vuoi inserire nella lista? ");
	scanf("%d",&n);
	printf("\n");
	if (n==0)
		p=NULL;
	else{
			p=AllocaNodo();
			printf("Inserisci 1 ° valore intero:  ");
			scanf("%d",&p->info);
			printf("\n");
			elem=p;
			//p->prev=NULL;
			for(i=2;i<=n;i++){
				elem->next=AllocaNodo();
				elem->next->prev=elem;
				elem=elem->next;
				printf("Inseriscil il %d ° elemento ",i);
				scanf("%d",&elem->info);
				printf("\n");
			} //chiudo il ciclo
			elem->next=NULL;
	}
	return p;
}

int ListEmpty(Lista Head){
	return Head==NULL;
}

Lista eliminaNodo(Lista Head, int elem){
Lista prev,next;
	if(Head!=NULL){
			if(Head->info!=elem)
				eliminaNodo(Head->next,elem);
			else{/*se entro in questo else, vuol dire che ho trovato un nodo
						con campo info uguale ad elem, quindi mi salvo il puntatore
						precedente e quello successivo del nodo, da usare per la
						cancellazione del nodo nei 3 casi */
				prev=Head->prev;
				next=Head->next;
				//caso di eliminazione: l'elemento è nel mezzo
				if(Head->prev!=NULL && Head->next!=NULL){
					next->prev=prev;
					prev->next=next;
				}
				else{/*caso eliminazione: la lista ha un solo elemento o l'elemento da
							eliminare si trova alla fine della lista */
						if(Head->next==NULL){
							if(Head->prev==NULL)
								Head=NULL;
							else
								prev->next=next;
							}
						else{ //caso di eliminazione:l'elemento è in testa alla lista
							Head=Head->next;
							Head->prev=NULL;
						}
					}
				}
			}
		return Head;
}


Lista removeNegatives(Lista Head){
	if(!ListEmpty(Head)){
		removeNegatives(Head->next);
		if(Head->info<0){
			Head=eliminaNodo(Head,Head->info);
		}
	}
	return Head;
}

Lista removePositives(Lista Head){
	if(!ListEmpty(Head)){
		removePositives(Head->next);
		if(Head->info>0){
			Head=eliminaNodo(Head,Head->info);
		}
	}
	return Head;
}

void esercizio (Lista *uno,Lista *due){
	if(!ListEmpty(*uno) && !ListEmpty(*due)){
		(*uno)=removeNegatives(*uno);
		(*due)=removePositives(*due);
	}
}

Lista interlaving(Lista uno,Lista due,Lista tre){
	if(!ListEmpty(uno) && !ListEmpty(due)){
			tre=insOrdinato(tre,uno->info);
			tre=insOrdinato(tre,due->info);
			tre->next=interlaving(uno->next,due->next,tre->next);
	}
	return tre;
}
