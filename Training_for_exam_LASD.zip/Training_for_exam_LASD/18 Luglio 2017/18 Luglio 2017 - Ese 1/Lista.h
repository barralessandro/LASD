#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED


struct nodo{
	struct nodo *prev;
	int info;
	struct nodo *next;
};

typedef struct nodo *Lista;

//funzione di allocazione
Lista AllocaNodo();

//inserimento ordinato di elem nella lista head
Lista insOrdinato(Lista Head, int elem);

//stampa la lista
void PrintList(Lista prova);

//funzione di inserimento con acquisiazione dimensione da tastiera (funzione iterativa)
Lista Riempi();

// ritorna 1 se la lista Head è vuota, 0 altrimenti
int ListEmpty(Lista Head);

//elimina il nodo con valore info uguale a val dalla lista
Lista eliminaNodo(Lista a, int val);

//ritorna la lista in input priva di elementi negativi
Lista removeNegatives(Lista Head);

//ritorna la lisa in input priva di elementi positivi
Lista removePositives(Lista Head);

/* Si implementi una funzione ricorsiva che elimini dalla lista Lista1 tutti
i numeri negativi e dalla lista Lista2 tutti quelli positivi senza usare
strutture dati aggiuntive e senza cambiare l’ordine degli elementi. */
void esercizio (Lista *uno,Lista *due);

/*Si implementi una funzione ricorsiva interleaving che prendendo in input
 le due liste modificate restituisce l’interleaving delle due liste,
 fino a che una delle due liste non diventi nulla. */
Lista interlaving(Lista uno,Lista due,Lista tre);

#endif
