#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

Graph intersezione (Graph G , Graph H,Graph T);

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    

	Graph G = graphCreationMenu(0);
	printGraph(G);
	printf("\n\n");
	Graph H = graphCreationMenu(0);
	printGraph(H);

	Graph T = initGraph(G->nodes_count);
	
	if (G->nodes_count >= H->nodes_count){
		T=intersezione(G,H,T);}
	else{
		T=intersezione(H,G,T);}

	printf("\n\n\n IL GRAFO INTERSEZIONE E' : \n");
	printGraph(T);
	printf("\n\n");

    freeGraph(G);
    return 0;
}



Graph intersezione (Graph G , Graph H,Graph T){
int flag=0,peso_totale;
List g,h;

int *pesi = (int*)calloc(G->nodes_count,sizeof(int));
int *esiste = (int*)calloc(G->nodes_count,sizeof(int));

for(int i=0;i<G->nodes_count;i++){
	g=G->adj[i];
	
	if(i<H->nodes_count){
		flag=1;
		h=H->adj[i];
			    }
			    
// For per azzerrare l'array altrimenti non vengono presi i veri archi in comune
	for(int j=0;j<G->nodes_count;j++){ 
		esiste[j]=0;
	}
	while(g){
		pesi[g->target]=g->peso;
		esiste[g->target]=1;
		g=g->next;
		}
		
	while(h && flag==1){
		if(esiste[h->target]==1){
			if(pesi[h->target]%2 == h->peso%2){
					peso_totale=pesi[h->target]+h->peso;
					addEdge(T,i,h->target,peso_totale);
					}	
				}
		esiste[h->target]=0;	
		h=h->next; 
		}
	}
return T; 
}

		
