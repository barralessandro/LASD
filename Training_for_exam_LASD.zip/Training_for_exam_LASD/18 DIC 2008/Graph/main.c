#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

Graph NewGraph(Graph G, Graph H);
Graph Trasposta(Graph G);
Graph Intersezione(Graph G, Graph H);
int GradoEntrante(Graph G, int vertice);

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
	
    Graph G=NULL,H=NULL;
	int vertice;
	do{
		printf("I due grafi devono avere stessa dimensione \n");
		printf("++++ Acquisizione grafo G \n");
		G = graphCreationMenu(0);
		
		printf("++++ Acquisizione grafo G \n");
		H = graphCreationMenu(0);
	}while(G->nodes_count!=H->nodes_count);
	
	
	printf("++++ Stampa grafo G acquisito \n");
    printGraph(G);
    
	printf("++++ Stampa grafo H acquisito \n");
    printGraph(H);
	
	do{
		printf("Ricorda: l'intero deve essere minore della dimensione del grafo \n");
		printf("Inserisci un vertice di cui vuoi calcolare grado entrante: ");
		scanf("%d",&vertice);
		printf("\n");
	}while(vertice >G->nodes_count);
	
	printf("Il grado entrante del vertice %d è : %d \n",vertice,GradoEntrante(G,vertice));
/*	
	Graph T= NewGraph(G,H);
	printf("++++ Stampa grafo T risultante \n");
    printGraph(T);
	
	Graph A=Trasposta(G);
	printf("++++ Stampa grafo trasposta di G \n");
	printGraph(A);
	
	A=Intersezione(H,A);
	printf("++++ Stampa grafo risultante dall'intersezione fra H e la trasposta di G\n");
    printGraph(A);
	
	
	
	
	freeGraph(T); */
    freeGraph(G);
	freeGraph(H);
	printf("Grafi deallocati \n");
    return 0;
}

Graph NewGraph(Graph G, Graph H){
Graph T=NULL;
	if(G!=NULL && H!=NULL){
		if(G->nodes_count==H->nodes_count)
			T=initGraph(G->nodes_count);
	}
return T;
}

Graph Trasposta(Graph G){
int i;
List g=NULL;
Graph Nuovo=NULL;
	
	if(G!=NULL){
		Nuovo=initGraph(G->nodes_count);
		
		for(i=0; i<G->nodes_count; i++){
			g=G->adj[i];
			
			while(g){
				addEdge(Nuovo,g->target,i,g->peso);
				g=g->next;
			}
		}
	}
freeList(g);
return Nuovo;
}

Graph Intersezione(Graph G, Graph H){
int i,costo,flag;
List g=NULL,h=NULL;
Graph T=NULL;
int *vertix,*pesix;
	if(G!=NULL && H!=NULL){
		
		T=initGraph(G->nodes_count);
		
		for(i=0; i<G->nodes_count; i++){
			g=G->adj[i];
			h=H->adj[i];
			
			vertix=(int *)calloc(G->nodes_count,sizeof(int));
			pesix=(int *)calloc(G->nodes_count,sizeof(int));
				while(g){
					vertix[g->target]++;
					pesix[g->target]=pesix[g->target]+g->peso;
					g=g->next;
				}
				flag=1;
				
				while(h && flag){
					if(vertix[h->target]==1){ //calcolo la differenza fra il peso dell'arco in G e quello in H 
						costo=pesix[h->target]-h->peso;
						if(costo >=0)
							addEdge(T,i,h->target,costo);
					}
					h=h->next;
				}
			flag=0;
			free(vertix);
			free(pesix);
		}
	}
freeList(g);
freeList(h);
return T;
}

int GradoEntrante(Graph G, int vertice){
int i,ris=0;
List g=NULL;

	if(G!=NULL){
		
		for(i=0; i<G->nodes_count; i++){
			g=G->adj[i];
			
			while(g){
				if(g->target==vertice)
					ris=ris+1;
				g=g->next;
			}
		}
		
	}
freeList(g);
return ris;
}
