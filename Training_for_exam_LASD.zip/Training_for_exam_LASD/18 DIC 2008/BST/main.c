#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tree.h"

Tree Minimo(Tree T);
Tree Massimo(Tree T);

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("++++ Acquisizione albero T \n");
    Tree T = treeCreationMenu(0);
    
    printf("++++ Stampa albero T \n");
    inOrderPrint(T);
	
    Tree a=NULL;
	a=Minimo(T);
	Tree b=NULL;
	b=Massimo(T);
    printf("la funzione ritorna minimo : %d  - massimo : %d \n \n",a->info,b->info);
	
    return 0;
}

Tree Minimo(Tree T){
  Tree ris=NULL;
  if(T!=NULL){
	  ris=T;
		if(T->sx!=NULL)
			ris=Minimo(T->sx);
  }
  return ris;
}


Tree Massimo(Tree T){
  Tree ris=NULL;
  if(T!=NULL){
	  ris=T;
	  if(T->dx!=NULL)
		ris=Massimo(T->dx);
  }
  return ris;
}
