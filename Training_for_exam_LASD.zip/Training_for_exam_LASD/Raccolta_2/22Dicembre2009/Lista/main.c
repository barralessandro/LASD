#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "List.h"

List sort(List L);
int menu();
List creaLista(List L);
List accodaListaL2PrimaDixInL1(List L1,List L2);
int cercaEleRestituiscimelo(List L, int el);

// Main
int main(int argc, const char * argv[]) {
	srand((unsigned int)time(NULL));
	menu();
}
	
int menu(){
	int scelta,x,risultato;
	char risp;
	List L1 = NULL;
	List L2 = NULL;
	List L3 = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Crea 2 Liste L1 e L2 \n");
		printf("[2] Visualizza Liste \n");
		printf("[3] Svolgi punto a) \n");
		printf("[4] Svolgi punto b) \n");
		printf("[5] Ordina la lista L1 \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea 2 Liste L1 e L2: \n\n");
				printf("Lista L1: \n");
				L1 = creaLista(L1);
				system("cls");
	
				printf("Lista L2: \n");
				L2 = creaLista(L2);
				system("cls");				
				printf("\nListe create! \n");
				system("PAUSE");
				break;
			}
			case 2:{
				system("cls");
				
				printf("Le Liste L1 e L2 sono:\n");
				printf("L1 = ");
				printList(L1);
				printf("\n");
				printf("L2 = ");
				printList(L2);
				printf("\n");
				
				system("PAUSE");
				break;
			}
			case 3:{
				system("cls");
				
				// Questa funzione rimuovono i numeri negativi
				L1=togliNegativiDaL1eDaL2(L1, &L2);
				printf("\nSi implementi una sola funzione ricorsiva(che eventualmente puo' richiamare sottofunzioni)\n");
				printf("che rimuova sia da Lista 1 che da Lista 2 tutte le occorrenze di numeri negativi.\n");
				printf("La lista L1 e':\n");
				printf("L1 = ");
				printList(L1);
				printf("\n");
				printf("La lista L2 e':\n");
				printf("L2 = ");
				printList(L2);
				printf("\n");
				system("PAUSE");
				break;
			}
			
			case 4:{
//				system("cls");
				printf("\nDato un valore x, scrivere una funzione ricorsiva che, verificata l'esistenza di x in\n");
				printf("Lista1, inserisca Lista 2 prima di x (in Lista1) e restituisca Lista 1 cosi' modificata. Se x\n");
				printf("non esiste in Lista1, accodare Lista2 a Lista1.\n");
				printf("\nScegli x:");
				scanf("%d",&x);
				L3= L1;
				L1=cercaEl(L1,x);
				// Adesso cerco l'elemento x nella Lista 1 e se esiste inserisce la lista 2 prima di x in Lista 1
				if(L1->target==x){
					// se stai all'inizio accoda L1 a L2
					if(L1->prec==NULL){
						L1=accodaLista(L2,L1);
					}
					// se stai alla fine accoda normalmente
					else if(L1->next==NULL){
						L1=accodaLista(L3,L2);
					}
					// se stai al centro della lista
					else
					L1=accodaListaL2PrimaDixInL1(L1,L2);
				}
				else
					L1=accodaLista(L1,L2);
				
				printf("La lista L1 ora modificata e':\n");
				printf("L1 = ");
				printList(L1);
				printf("\n");
				printf("\n");
				system("PAUSE");
				break;
			}
			
			case 5:{
				printf("\nAdesso ordino la lista L1: \n");
				L1=sort(L1);
				// Adesso la capovolgo
				L1=reverseL(L1);
				printf("La lista L1 ora ordinata e':\n");
				printf("L1 = ");
				printList(L1);
				printf("\n");
				printf("\n");
				system("PAUSE");
				break;
			}
			
			case 0: {
				freeList(L1);
				freeList(L2);
				freeList(L3);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeList(L1);
	freeList(L2);
	freeList(L3);
	system("PAUSE");
}


List creaLista(List L){
	int i,n,info;
	
	printf("Quanti elementi vuoi?\n");
	printf("N= ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++){
		// Per numeri Positivi & Negativi ...
		printf("Inserisci %d elemento: ",i+1);
		scanf("%d",&info);
		
//		// Solo per numeri Positivi ...
//		do{
//			printf("Inserisci %d elemento maggiore di 0: ",i+1);
//			scanf("%d",&info);
//		}
//		while(info<=0);
		
		L=appendNodeList(L,info);
	}
	
	return L;
}

List accodaListaL2PrimaDixInL1(List L1,List L2){
	//Se esistono L1
	if (L1) {
		List tmp = L1->prec;
        L1->prec->next = L2;
        L2->prec=L1->prec;
        L1= accodaLista(tmp,L1);
    }
    return L1;
}

 // Ordina una lista in ordine crescente
List sort(List L){
	if((!L)||(!L->next))
		return L;
	
	List curr, max, maxPrec, prev, tmp;
	curr = L;
	max = L;
	prev = L;
	maxPrec= L;
	
	while(curr){
		if((curr->target) > (max->target)){
			maxPrec = prev;
			max = curr;
		}
		prev = curr;
		curr = curr->next;
	}
	
	if(max!=L){
		maxPrec->next = L;
		tmp = L->next;
		L->next = max->next;
		max->next = tmp;
	}
	
	max->next = sort(max->next);
	
	return max;
}


