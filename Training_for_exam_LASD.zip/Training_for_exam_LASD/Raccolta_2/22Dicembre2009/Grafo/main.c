#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Graph.h"

void menu();

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
	menu();	
}

void menu() {
	int scelta, i,j, nodes, source, target, peso;
	char risp;
	Graph G = NULL, H = NULL, T = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Crea due grafi G e H orientati \n");
		printf("[2] Stampa Grafi \n");
		printf("[3] Risolvi punto a)\n");
		printf("[4] Risolvi punto b) \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea Grafo Orientato Manuale ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo G? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("\n");
				G = createGraph(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo H? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("\n");
				H = createGraph(nodes, 0, nodes-1);
				
				printf("\nGrafi creati! \n");
				
				//Inizializzo un grafo T che sar� quello risultante
				T = initGraph(nodes);
				
				system("PAUSE");
				break;
			}
			case 2:{
				system("cls");
				printf("** Stampa Grafi ** \n\n");
				if((G) && (H)) {
					printf("Grafo G: \n");
					printGraph(G);
					printf("\n");
					
					printf("Grafo H: \n");
					printGraph(H);
					printf("\n");
					
//					if(T) {
//						printf("Grafo T: \n");
//						printGraph(T);
//						printf("\n");
//					}
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 3:{
				system("cls");
				printf("\nScrivere in linguaggio C una funzione che, presi in input i due grafi G e H costruisca\n ");
				printf("un terzo grafo T ( e lo restituisca) in cui l'arco (a,b) e' presente se e' presente sia in G\n");
				printf("che in H, oppure in nessuno dei due. Nel primo caso prender� come peso la somma dei pesi dei\n");
				printf("relativi archi in G e H. Nel secondo caso, prendera' peso -1\n");

				//nodo corrente
				for(i=0;i<nodes;i++){
					//nodi a cui verifichi se � collegato o meno
					for(j=0;j<nodes;j++){
						//se non sono lo stesso nodo
						if(i!=j){
							//verifichiamo la presenza di un arco da i a j
							if(((cercaEl(G->adj[i],j))&&(cercaEl(H->adj[i],j)))==1){
								int risultatopesi = (ritornaPeso(G->adj[i],j) + (ritornaPeso(H->adj[i],j)));
									addEdge(T,i,j,risultatopesi);
								}
							else if(((cercaEl(G->adj[i],j))&&(cercaEl(H->adj[i],j)))==0){
								addEdge(T,i,j,-1);
							}
						}
					}
				}
				
				//Ristampo i grafi G e H e il grafo risultante T
				printf("Grafo G: \n");
				printGraph(G);
				printf("\n");
					
				printf("Grafo H: \n");
				printGraph(H);
				printf("\n");
					
				printf("Grafo T: \n");
				printGraph(T);
				printf("\n");
				
				
				
				system("PAUSE");
				break;
			}
			case 4:{
				system("cls");
				printf("\nScrivere una funzione in C che verifichi che per ogni nodo di G e H, il grado\n");
				printf("incidente in G e' uguale al grado adiacente in H\n");
				
				//nodo corrente
				for(i=0;i<nodes;i++){
					//se non sono lo stesso nodo
					if(gradoIncid(G,i) == gradoAdj(H,i))
						printf("Il grado incidente del nodo %d in G e' uguale al grado adiacente del nodo %d in H\n",i,i);
					else
						printf("Il grado incidente del nodo %d in G non e' uguale al grado adiacente del nodo %d in H\n",i,i);
				}				
				system("PAUSE");
				break;
			}
			case 0:{
				freeGraph(G);
				freeGraph(H);
				freeGraph(T);
				return;
			}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
		}	
	}while((risp != 'n') && (risp != 'N'));
	
	freeGraph(G);
	freeGraph(H);
	freeGraph(T);
}

