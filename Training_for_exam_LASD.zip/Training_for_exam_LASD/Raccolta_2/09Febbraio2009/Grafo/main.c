#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include "Graph.h"
#include "List.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void menu();

int main() {
	srand((unsigned int)time(NULL));
	menu();
}

void menu() {
	int scelta, nodes, i=0, j=0;
	char risp;
	Graph G = NULL, H = NULL, T = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Svolgi esercizio sui grafi \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea 2 Grafi Orientati manualmente ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nei grafi? \n");
				printf("N = ");
				scanf("%d", &nodes);
				//Sto creando un grafo G  con 0 archi minimi e nodi-1 nodi
				//G = createGraph(nodes, 0, nodes-1);
				G = randomGraph(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				//Sto creando un grafo H con 0 archi minimi e nodi-1 nodi
				//H = createGraph(nodes, 0, nodes-1);
				H = randomGraph(nodes, 0, nodes-1);
				
				//Inizializzo un grafo T che sar� quello risultante
				T = initGraph(nodes);
				
				printf("\nIl grafo G e' stato creato! \n");
				//Stampo i 2 grafi su schermo
				printGraph(G);
				printf("\n");
				printf("\nIl grafo H e' stato creato! \n");
				printGraph(H);
				printf("\n");

				system("PAUSE");
				
				printf("\nAdesso il grafo T dovra' avere la stessa struttura di G e H");
				printf("\nT avra' un arco (a,b) se e' presente sia in G che in H");
				printf("\ne il suo peso � dato dalla somma del relativo peso di G e H");
				printf("\n+ il grado adiacente di a + il grado incidente di b in H\n");
				
				//nodo corrente
				for(i=0;i<nodes;i++){
					//nodi a cui verifichi se � collegato o meno
					for(j=0;j<nodes;j++){
						//se non sono lo stesso nodo
						if(i!=j){
							//verifichiamo la presenza di un arco da i a j
							if(((cercaEl(G->adj[i],j))&&(cercaEl(H->adj[i],j)))==1){
								int risultatopesi = (ritornaPeso(G->adj[i],j) + (ritornaPeso(H->adj[i],j))) + (gradoAdj(H,i) + gradoIncid(H,j));
								if(risultatopesi > 0 ){
									addEdge(T,i,j,risultatopesi);
								}
//								else{
//									changeP(G->adj[i],j,sottrazionepesi);
									//G->adj[i]->peso = G->adj[i]->peso - H->adj[j]->peso;
								}
							}
						}
					}
				printf("\nQui il grafo P risultante:\n");
				printGraph(T);
				system("PAUSE");
				
				break;
			}
			
			case 0: {
				freeGraph(G);
				freeGraph(H);
				freeGraph(T);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeGraph(G);
	freeGraph(H);
	freeGraph(T);
}
