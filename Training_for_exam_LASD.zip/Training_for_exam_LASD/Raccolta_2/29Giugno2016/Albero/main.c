#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"


int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    Tree T = NULL;
    int nodomassimo,risultato;
    
    // Creo un nuovo albero T
    T= creaBST(T);
    printf("\n\n");
    
    // Visualizzo a schermo l'albero appena creato...
    printf("\nL'albero T appena creato e':\n");
	preOrder(T);
    printf("\n\n");
    
    // Adesso mi cerco l'elemento massimo e lo salvo in una variabile d'appoggio...
    nodomassimo = massimo(T); 
    // Adesso verifico che per tutti i nodi presenti nell'Albero ci sia un successore numerico eccetto per l'ultimo nodo
    risultato=succTuttiNodi(T,T,nodomassimo);
	
    	if(risultato==1){
    		printf("\nL'albero T rispetta quanto chiesto\n");
		}
		else
			printf("\nL'albero T non rispetta quanto richiesto\n");
			
	system("PAUSE");
    
    return 0;
}

