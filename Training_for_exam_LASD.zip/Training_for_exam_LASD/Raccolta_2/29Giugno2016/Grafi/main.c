#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Graph.h"

void menu();
void esercizio(Graph G, Graph H);
int main(int argc, const char * argv[]) {
    //srand((unsigned int)time(NULL));
	menu();	
}

void menu() {
	int scelta,i,j, nodes, min, max, source, target, peso;
	char risp;
	Graph G = NULL, H = NULL, T = NULL, HT = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Crea Grafo Orientato Random \n");
		printf("[2] Crea Grafo Orientato Manuale \n");
		printf("[3] Stampa Grafi \n");
		printf("[4] Aggiungi un arco \n");
		printf("[5] Rimuovi un arco \n");
		printf("[6] Modifica il peso di un arco \n");
		printf("[7] Svolgimento esercizio \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea Grafo Orientato Random ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				G = randomGraph(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				H = randomGraph(nodes, 0, nodes-1);
				
				printf("\nGrafi creati! \n");
				system("PAUSE");
				break;
			}
			case 2:{
				system("cls");
				printf("** Crea Grafo Orientato Manuale ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("\n");
				G = createGraph(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("\n");
				H = createGraph(nodes, 0, nodes-1);
				
				printf("\nGrafi creati! \n");
				system("PAUSE");
				break;
			}
			
			case 3:{
				system("cls");
				printf("** Stampa Grafi ** \n\n");
				if((G) && (H)) {
					printf("Grafo G: \n");
					printGraph(G);
					printf("\n");
					
					printf("Grafo H: \n");
					printGraph(H);
					printf("\n");
					
//					// Creo il grafo trasposto di H
//					HT=initGraph(nodes);
//					HT=trasp(H);
//					printf("Grafo trasposto di H: \n");
//					printGraph(HT);
//					printf("\n");
					
					
					if(T) {
						printf("Grafo T: \n");
						printGraph(T);
						printf("\n");
					}
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 4:{
				system("cls");
				printf("** Aggiungi un arco ** \n\n");
				if((G) && (H)) {
					printf("Inserisci il nodo sorgente: ");
					scanf("%d", &source);
					printf("Inserisci il target: ");
					scanf("%d", &target);
					printf("Inserisci il peso: ");
					scanf("%d", &peso);
					
					if(cercaArco(G->adj[source], target))
						printf("\nEsiste gia' un arco da %d a %d ! \n\n", source, target);
					else {
						addEdge(G, source, target, peso);
						printf("\nArco aggiunto! \n\n");
					}
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 5:{
				system("cls");
				printf("** Rimuovi un arco ** \n\n");
				if((G) && (H)) {
					printf("Inserisci il nodo sorgente: ");
					scanf("%d", &source);
					printf("Inserisci il target: ");
					scanf("%d", &target);
					
					if(cercaArco(G->adj[source], target)){
						removeEdge(G, source, target);
						printf("\nArco rimosso! \n\n");
					}
					else
						printf("\nNon esiste un arco da %d a %d ! \n\n", source, target);
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 6:{
				system("cls");
				printf("** Modifica il peso di un arco ** \n\n");
				if((G) && (H)) {
					printf("Inserisci il nodo sorgente: ");
					scanf("%d", &source);
					printf("Inserisci il target: ");
					scanf("%d", &target);
					
					modifyPeso(G, source, target);
					printf("\nPeso modificato! \n\n");
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 7:{
				system("cls");
				printf("** Svolgimento Esercizio ** \n\n");
				printf("Scrivere una funzione che presi in input G e H restituisce un nuovo grafo T usando la seguente regola.\n");
				printf("Un arco da r ad s con peso p e' presente in T se e' presente in G e nella trasposta di H e p rappresenta\n");
				printf("la differenza tra il peso in G e quello in H\n");
				
				esercizio(G,H);
							
				system("PAUSE");
				break;
			}
			case 0: {
				freeGraph(G);
				freeGraph(H);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeGraph(G);
	freeGraph(H);
}

void esercizio(Graph G, Graph H) {
	int i = 0;
	Graph TH = NULL;
	Graph T = initGraph(G->nodes_count);
	
	TH = trasp(H);
	
	for(i = 0; i < G->nodes_count; i++) {
		List temp = G->adj[i];
		
		while(temp) {
			if(cercaEl(TH->adj[i], temp->target)) {
				addEdge(T, i, temp->target, temp->peso - TH->adj[i]->peso);
			}
			
			temp = temp->next;
		}
	}
	
	printf("Grafo G: \n");
	printGraph(G);
	printf("\n");
	
	printf("Grafo H: \n");
	printGraph(H);
	printf("\n");
	
	printf("Grafo Trasposto di H: \n");
	printGraph(TH);
	printf("\n");
	
	printf("Grafo T: \n");
	printGraph(T);
	printf("\n");
}
