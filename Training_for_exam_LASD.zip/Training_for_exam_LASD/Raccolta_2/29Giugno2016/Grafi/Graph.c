#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include "Graph.h"


Graph initGraph(int nodes_count) {
    Graph G = (Graph)malloc(sizeof(struct TGraph));
    G->adj = (List *)calloc(nodes_count, sizeof(List));
    G->nodes_count = nodes_count;
    return G;
}

Graph randomGraph(int nodes, int edges_min, int edges_max) {
    Graph G = initGraph(nodes);
	int i = 0;
    int x = 0;
    int y = 0;
    int target=0;
    srand((unsigned int)time(NULL));
    assert( edges_min <= edges_max ); // non possono esserci edges_min > edges_max
    if (edges_max > nodes) {
        edges_max = nodes - 1;
    }
    if(nodes>1) { //senza questo controllo,in un grafo con un nodo aggiungeva un arco con target -1
    	for (i = 0; i < nodes; i++) {
       		for (x = 0; x < edges_min; x ++) {
       		 	target=rand()%nodes;
        		if(target==i) //un non ha archi ricorsivi
        			target++;
        		if(target==nodes) //se nell'incremento il target è un nodo che non esiste lo decremento di due
        			target-=2;
        	    addEdge(G, i, target, rand() % 50);
        	}
        	if(edges_min<edges_max)//   crash se edges_min==edges_max  (rand()%0),quindi non aggiunge ulteriori nodi
        	{
        		for (y = 0; y < rand() % (edges_max - edges_min); y++) {
        		    target=rand()%nodes;
					if(target==i) //un non ha archi ricorsivi
						target++;
					if(target==nodes) //se nell'incremento il target è un nodo che non esiste lo decremento di due
						target-=2;
					addEdge(G, i, target, rand() % 50);
        		}
        	}
    	}
    }
    return G;
}

void freeGraph(Graph G) {
    if (G != NULL) {
        if (G->nodes_count > 0) {
            int i = 0;
            for (i = 0; i < G->nodes_count; i++) {
                freeList(G->adj[i]);
            }
        }
        free(G);
    }
}

void printGraph(Graph G) {
    if (G != NULL) {
        int x = 0;
        for (x = 0; x < G->nodes_count; x++) {
            printf("%d -> ", x);
            printList(G->adj[x]);
            printf("\n");
        }
    }
}

void addEdge(Graph G, int source, int target, int peso) {
    assert(G != NULL);
    assert(source < G->nodes_count);
    assert(target < G->nodes_count);
    if (source != target) {
        G->adj[source] = appendNodeList(G->adj[source], target, peso);
    }
    
}

List removeEdge(Graph G, int source, int target) {
    assert(G != NULL);
    assert(source < G->nodes_count);
    assert(target < G->nodes_count);
    if (source != target) {
        G->adj[source] = removeNodeList(G->adj[source], target);
    }
	return G->adj[source];
}

void addNode(Graph G) {
    if (G != NULL) {
        G->adj = (List *)realloc(G->adj, (G->nodes_count+1) * sizeof(List));
        G->nodes_count += 1;
        G->adj[G->nodes_count-1] = NULL;
    }
}

void removeNode(Graph G, int node_to_remove) {
    if (G != NULL) {
        int i = 0;
        int x = 0;
        List *tmp = G->adj;
        G->adj = (List *)calloc(G->nodes_count-1, sizeof(List));
        for (i = 0; i < G->nodes_count; i++) {
            if (i != node_to_remove) {
                G->adj[x] = checkListRemoval(tmp[i], node_to_remove);
                x++;
            } else {
                freeList(G->adj[x]);
            }
        }
        free(tmp);
        G->nodes_count -= 1;
    }
}

List checkListRemoval(List L, int node_to_remove) {
    if (L != NULL) {
        L->next = checkListRemoval(L->next, node_to_remove);
        if (L->target == node_to_remove) {
            List tmp = L->next;
            free(L);
            return tmp;
        } else if (L->target > node_to_remove) {
            L->target -= 1;
        }
    }
    return L;
}

// ##################################################################### FUNZIONI NOSTRE ###############################################################################

// Grafo NON Orientato (RANDOM)
Graph randomGraphNO(int nodes, int edges_min, int edges_max) {
	int target, precT, liberi, i, x, y, n;
	Graph G = initGraph(nodes);
	liberi = edges_max * nodes;
	
	for(i = 0; i < nodes; i++) {
		precT = -1;
		
		if((gradoAdj(G,i) < edges_min) && (liberi > edges_max)) {
			for(x = gradoAdj(G,i); x < edges_min; x++) {
				target = rand() % nodes;
				
				while((target == precT) || (target == i) || (gradoAdj(G,target) >= edges_max) || (cercaArco(G->adj[i], target)))
					target = rand() % nodes;
					
				addEdge(G, i, target, 1);
				addEdge(G, target, i, 1);
				liberi = liberi - 2;
				precT = target;
			}
		}
		
		if((gradoAdj(G,i) < edges_max) && (liberi > edges_max)) {
			n = rand() % ((edges_max - gradoAdj(G,i)) +1);
			
			for(y = 0; y < n; y++) {
				target = rand() % nodes;
				
				while((target == precT) || (target == i) || (gradoAdj(G,target) >= edges_max) || (cercaArco(G->adj[i], target)))
					target = rand() % nodes;
					
				addEdge(G, i, target, 1);
				addEdge(G, target, i, 1);
				liberi = liberi - 2;
				precT = target;
			}
		}
	}
	
	return G;
}

// Grafo Orientato (Manuale)
Graph createGraph(int nodes, int edges_min, int edges_max) {
	int target, peso, precT, i, x, y, n;
	Graph G = initGraph(nodes);
	
	for(i = 0; i < nodes; i++) {
		precT = -1;
		printf("Ora sei sul nodo %d \n", i);
		
		for(x = 0; x < edges_min; x++) {
			printf("Scegli il %d target: ", x + 1);
			scanf("%d", &target);
			printf("Scegli il peso: ");
			scanf("%d", &peso);
				
			while((target == precT) || (target == i) || (cercaArco(G->adj[i], target))) {
				printf("** Attenzione! Target non valido! ** \n");
				printf("Scegli il %d target: ", x + 1);
				scanf("%d", &target);
				printf("Scegli il peso: ");
				scanf("%d", &peso);
			}
				
			addEdge(G, i, target, peso);
			precT = target;
		}
		
		printf("Puoi aggiungere altri %d archi per questo nodo. Quanti vuoi inserirne? (0 per non inserirne) \n", edges_max - edges_min);
		printf("N = ");
		scanf("%d", &n);
//		printf("\n");
			
		for(y = 0; y < n; y++) {
			printf("Scegli il %d target: ", x + (y + 1));
			scanf("%d", &target);
			printf("Scegli il peso: ");
			scanf("%d", &peso);
//			printf("\n");
				
			while((target == precT) || (target == i) || (cercaArco(G->adj[i], target))) {
				printf("** Attenzione! Target non valido! ** \n");
				printf("Scegli il %d target: ", x+1);
				scanf("%d", &target);
				printf("Scegli il peso: ");
				scanf("%d", &peso);
			}
				
			addEdge(G, i, target, peso);
			precT = target;
		}
	}
	
	return G;
}

// Grafo NON Orientato (Manuale)
Graph createGraphNO(int nodes, int edges_min, int edges_max) {
	int target, peso, precT, liberi, i, x, y, n;
	Graph G = initGraph(nodes);
	liberi = edges_max * nodes;
	
	for(i = 0; i < nodes; i++) {
		precT = -1;
		printf("Nodo %d \n", i);
		
		if((gradoAdj(G,i) < edges_min) && (liberi > edges_max)) {
			for(x = gradoAdj(G,i); x < edges_min; x++) {
				printf("Scegli il %d target: ", x + 1);
				scanf("%d", &target);
				printf("Scegli il peso: ");
				scanf("%d", &peso);
				
				while((target == precT) || (target == i) || (gradoAdj(G,target) >= edges_max) || (cercaArco(G->adj[i], target))) {
					printf("** Attenzione! Target non valido! ** \n");
					printf("Scegli il %d target: ", x + 1);
					scanf("%d", &target);
					printf("Scegli il peso: ");
					scanf("%d", &peso);
				}
					
				addEdge(G, i, target, peso);
				addEdge(G, target, i, peso);
				liberi = liberi - 2;
				precT = target;
			}
		}
		
		if((gradoAdj(G,i) < edges_max) && (liberi > edges_max)) {
			printf("\nPuoi aggiungere altri %d archi per questo nodo. Quanti vuoi inserirne? (0 per non inserirne) \n", edges_max - gradoAdj(G,i));
			printf("N = ");
			scanf("%d", &n);
			printf("\n");
			
			for(y = 0; y < n; y++) {
				printf("Scegli il %d target: ", x + (y + 1));
				scanf("%d", &target);
				printf("Scegli il peso: ");
				scanf("%d", &peso);
				
				while((target == precT) || (target == i) || (gradoAdj(G,target) >= edges_max) || (cercaArco(G->adj[i], target))) {
					printf("** Attenzione! Target non valido! ** \n");
					printf("Scegli il %d target: ", x + (y + 1));
					scanf("%d", &target);
					printf("Scegli il peso: ");
					scanf("%d", &peso);
				}
					
				addEdge(G, i, target, peso);
				addEdge(G, target, i, peso);
				liberi = liberi - 2;
				precT = target;
			}
		}
	}
	
	return G;
}

// Grado Incidente
int gradoIncid(Graph G, int node) {
	if(G) {
		int i, conta = 0;
		
		for(i = 0; i < G->nodes_count; i++) {
			if(i != node)
				conta += cercaArco(G->adj[i], node); 
		}
		
		return conta;
	}
}

// Grado Adiacente
int gradoAdj(Graph G, int node) {
	if(G)
		return contaNodi(G->adj[node]);
}

// Grado Max
int gradoMax(Graph G) {
	if(G) {
		int incidenti, adiacenti, i, max = 0;
		
		for(i = 0; i < G->nodes_count; i++) {
			if(G->adj[i]) {
				incidenti = gradoIncid(G, G->adj[i]->target);
				adiacenti = gradoAdj(G, G->adj[i]->target);
				
				if((incidenti + adiacenti) > max)
					max = incidenti + adiacenti;
			}
		}
		
		return max;
	}
}

// Grafo Trasposto
Graph trasp(Graph G) {
	if(G) {
		int i;
		Graph T = initGraph(G->nodes_count);
		
		for(i = 0; i < G->nodes_count; i++) {
			List x = G->adj[i];
			
			while(x) {
				addEdge(T, x->target, i, x->peso);
				x = x->next;
			}
		}
		
		return T;
	}
}

// Modifica Peso Arco
void modifyPeso(Graph G, int source, int target) {
	if(G) {
		int peso;
		
		if(cercaArco(G->adj[source], target)) {
			printf("Inserisci il nuovo peso: ");
			scanf("%d", &peso);
			
			changeP(G->adj[source], target, peso);
		}
		else {
			printf("Non esiste un arco da %d a %d ! \n", source, target);
			system("PAUSE");
		}
	}
}

// Programma che presi in input G e H, restituisce un nuovo grafo T. Un arco da r ad s con peso p � presente in T
// se � presente in G e nella traposta di H e p rappresenta la differenza tra il peso in G e quello in H.
void esercizio(Graph G, Graph H) {
	int i = 0;
	Graph TH = NULL;
	Graph T = initGraph(G->nodes_count);
	
	TH = trasp(H);
	
	for(i = 0; i < G->nodes_count; i++) {
		List temp = G->adj[i];
		
		while(temp) {
			if(cercaEl(TH->adj[i], temp->target)) {
				addEdge(T, i, temp->target, temp->peso - TH->adj[i]->peso);
			}
			
			temp = temp->next;
		}
	}
	
	printf("Grafo G: \n");
	printGraph(G);
	printf("\n");
	
	printf("Grafo H: \n");
	printGraph(H);
	printf("\n");
	
	printf("Grafo Trasposto di H: \n");
	printGraph(TH);
	printf("\n");
	
	printf("Grafo T: \n");
	printGraph(T);
	printf("\n");
}

// Menu per la Gestione dei Grafi
//void menu() {
//	int scelta, nodes, min, max, source, target, peso;
//	char risp;
//	Graph G = NULL, H = NULL, T = NULL;
//	
//	do {
//		system("cls");
//		printf("*** MENU *** \n\n");
//		printf("[1] Crea Grafo Orientato Random \n");
//		printf("[2] Crea Grafo Orientato Manuale \n");
//		printf("[3] Crea Grafo Non Orientato Random \n");
//		printf("[4] Crea Grafo Non Orientato Manuale \n");
//		printf("[5] Stampa Grafi \n");
//		printf("[6] Aggiungi un arco \n");
//		printf("[7] Rimuovi un arco \n");
//		printf("[8] Modifica il peso di un arco \n");
//		printf("[9] Svolgi Esercizio \n");
//		printf("[0] Esci \n\n");
//		
//		printf("Scegli un opzione: ");
//		scanf("%d", &scelta);
//		
//		switch(scelta) {
//			case 1:{
//				system("cls");
//				printf("** Crea Grafo Orientato Random ** \n\n");
//				printf("Grafo G: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				G = randomGraph(nodes, min, max);
//				
//				printf("\nGrafo H: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				H = randomGraph(nodes, min, max);
//				
//				printf("\nGrafi creati! \n");
//				system("PAUSE");
//				break;
//			}
//			case 2:{
//				system("cls");
//				printf("** Crea Grafo Orientato Manuale ** \n\n");
//				printf("Grafo G: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				printf("\n");
//				G = createGraph(nodes, min, max);
//				
//				printf("\nGrafo H: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				printf("\n");
//				H = createGraph(nodes, min, max);
//				
//				printf("\nGrafi creati! \n");
//				system("PAUSE");
//				break;
//			}
//			case 3:{
//				system("cls");
//				printf("** Crea Grafo Non Orientato Random ** \n\n");
//				printf("Grafo G: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				G = randomGraphNO(nodes, min, max);
//				
//				printf("\nGrafo H: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				H = randomGraphNO(nodes, min, max);
//				
//				printf("\nGrafi creati! \n");
//				system("PAUSE");
//				break;
//			}
//			case 4:{
//				system("cls");
//				printf("** Crea Grafo Non Orientato Manuale ** \n\n");
//				printf("Grafo G: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				printf("\n");
//				G = createGraphNO(nodes, min, max);
//				
//				printf("\nGrafo H: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				printf("\n");
//				H = createGraphNO(nodes, min, max);
//				
//				printf("\nGrafi creati! \n");
//				system("PAUSE");
//				break;
//			}
//			case 5:{
//				system("cls");
//				printf("** Stampa Grafi ** \n\n");
//				if((G) && (H)) {
//					printf("Grafo G: \n");
//					printGraph(G);
//					printf("\n");
//					
//					printf("Grafo H: \n");
//					printGraph(H);
//					printf("\n");
//					
//					if(T) {
//						printf("Grafo T: \n");
//						printGraph(T);
//						printf("\n");
//					}
//				}
//				else
//					printf("Devi prima creare i Grafi! \n\n");
//				
//				system("PAUSE");
//				break;
//			}
//			case 6:{
//				system("cls");
//				printf("** Aggiungi un arco ** \n\n");
//				if((G) && (H)) {
//					printf("Inserisci il nodo sorgente: ");
//					scanf("%d", &source);
//					printf("Inserisci il target: ");
//					scanf("%d", &target);
//					printf("Inserisci il peso: ");
//					scanf("%d", &peso);
//					
//					if(cercaArco(G->adj[source], target))
//						printf("\nEsiste gia' un arco da %d a %d ! \n\n", source, target);
//					else {
//						addEdge(G, source, target, peso);
//						printf("\nArco aggiunto! \n\n");
//					}
//				}
//				else
//					printf("Devi prima creare i Grafi! \n\n");
//				
//				system("PAUSE");
//				break;
//			}
//			case 7:{
//				system("cls");
//				printf("** Rimuovi un arco ** \n\n");
//				if((G) && (H)) {
//					printf("Inserisci il nodo sorgente: ");
//					scanf("%d", &source);
//					printf("Inserisci il target: ");
//					scanf("%d", &target);
//					
//					if(cercaArco(G->adj[source], target)){
//						removeEdge(G, source, target);
//						printf("\nArco rimosso! \n\n");
//					}
//					else
//						printf("\nNon esiste un arco da %d a %d ! \n\n", source, target);
//				}
//				else
//					printf("Devi prima creare i Grafi! \n\n");
//				
//				system("PAUSE");
//				break;
//			}
//			case 8:{
//				system("cls");
//				printf("** Modifica il peso di un arco ** \n\n");
//				if((G) && (H)) {
//					printf("Inserisci il nodo sorgente: ");
//					scanf("%d", &source);
//					printf("Inserisci il target: ");
//					scanf("%d", &target);
//					
//					modifyPeso(G, source, target);
//					printf("\nPeso modificato! \n\n");
//				}
//				else
//					printf("Devi prima creare i Grafi! \n\n");
//				
//				system("PAUSE");
//				break;
//			}
//			case 9:{
//				system("cls");
//				printf("** Svolgimento Esercizio ** \n\n");
//				system("PAUSE");
//				break;
//			}
//			case 0: {
//				freeGraph(G);
//				freeGraph(H);
//				freeGraph(T);
//				return;
//			}
//		}
//		
//		system("cls");
//		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
//		printf("Risposta: ");
//		scanf("%s", &risp);
//	}
//	while((risp != 'n') && (risp != 'N'));
//	
//	freeGraph(G);
//	freeGraph(H);
//	freeGraph(T);
//}
