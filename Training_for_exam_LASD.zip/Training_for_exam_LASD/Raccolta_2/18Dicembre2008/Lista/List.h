#ifndef Graph_List_h
#define Graph_List_h

struct TList {
    int target;
    struct TList* next;
    struct TList* prec;
};
typedef struct TList* List;

// Inizializza un nuovo nodo
List initNodeList(int info);

// Crea una lista random, per mod si
// puo' specificare il modulo utilizzato la funzione rand()
// La funzione ritorna sempre la testa della lista
List randomList(int index, int mod);

// Aggiunge un nodo alla fine della lista
// controllandone l'esistenza
// La funzione ritorna sempre la testa della lista
List appendNodeList(List L, int target);

// Aggiunge un nodo in testa alla lista
// controllandone l'esistenza
// La funzione ritorna sempre la testa della lista
List addNodeHead(List L, int target);

// Dealloca la lista interamente
void freeList(List L);

// Stampa la lista
void printList(List L);

// ################################################################## FUNZIONI NOSTRE ################################################################################

// Crea una Lista Manuale
List creaL(List L);

// Rimuove solo un occorrenza di un nodo con il target specificato
// dalla lista
// La funzione ritorna sempre la testa della lista
List removeNodeList(List L, int target);

// Ritorna la Dimensione della Lista
int dimL(List L);

// Somma tutti gli elementi della Lista
int sommaL(List L);

// Salva gli elementi della Lista in un Array
void ListToArray(List L, int tmp[], int i);

// Ritorna la Lista Inversa
List reverseL(List L);

// Rimuove tutti gli elementi Dispari dalla Lista
List togliDispari(List L);

// Rimuove tutti gli elementi Pari dalla Lista
List togliPari(List L);

// Cerca elemento in una lista
List cercaEl(List L, int el);

// Toglie tutte le ripetizioni dalla Lista
List togliRipetizioni(List L);

// Rimuove tutti gli elementi Negativi dalla Lista
List togliNegativi(List L);

// Toglie i multipli di n da L1 e li aggiunge in testa ad L2 e viceversa
// nel main utilizzare L1=cancella_multipli(L1,&L2,2); L2=cancella_multipli(L2,&L1,5);
List cancella_multipli(List L1, List *L2, int n);

// Accoda L2 ad L1
List accodaLista(List L1,List L2);

// Ritorna la Testa della Lista
List headList(List L);

// Ritorna la Coda della Lista
List tailList(List L);

// Togli gli elementi di L1 da L2
List togliL1daL2(List L1, List L2);

// Togli somma valori L1 in L2 e viceversa
void togli_somma(List L1, List L2);

// Rimuovi tutti gli elementi di L2 in L1
List rimuoviElemDiL2inL1(List L1, List L2);
#endif
