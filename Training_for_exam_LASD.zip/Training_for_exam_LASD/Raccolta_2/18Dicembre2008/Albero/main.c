#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"

int main() {
	srand((unsigned int)time(NULL));
	menu();
}

void menu() {
	int scelta, nodes, i=0, j=0, verificauguaglianza;
	char risp;
	//Inizializzo 2 Alberi
	Tree T=NULL, P=NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Svolgi l'esecizio con 2 Alberi creati random \n");
		printf("[2] Svolgi l'esercizio con 2 Alberi creati manualmente\n ");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea 2 Alberi random ** \n\n");
				printf("Albero T: \n");
				printf("Quanti nodi vuoi nell'albero T? \n");
				printf("numero nodi = ");
				scanf("%d", &nodes);
				//Sto creando un albero T  con 0 archi minimi e nodi-1 nodi
				T = randomTree(nodes);
				
				printf("\nAlbero P: \n");
				printf("Quanti nodi vuoi nell'Albero P? \n");
				printf("numero nodi = ");
				scanf("%d", &nodes);
				P = randomTree(nodes);
				
				printf("\nGli alberi T e P sono stati creati! \n");
				//Stampo i 2 alberi
				printf("L'albero T creato in maniera random e':\n");
				preOrder(T);
				printf("\n\n");
				printf("L'albero P creato in maniera random e':\n");
				preOrder(P);
				system("PAUSE");
				
				//Primo punto esercizio
				printf("\nAdesso verifico se i 2 alberi sono uguali:");
				verificauguaglianza= sameBST(T,P);
				
				if(verificauguaglianza==0){
					printf("\nGli alberi T e P non sono uguali!");
				}
				else{
					printf("\nGli alberi T e P sono uguali!");
				}
				system("PAUSE");
				printf("\n");
				//Fine primo punto esercizio
				
				//Secondo punto esercizio
				//printf("\nOra verifichero' che per ogni elemento di T ci sia il suo predecessore e il suo successore:\n");
				//Adesso verifico che ci sia un predecessore 
				printf("\n");
				system("PAUSE");
				
				
				
				break;
			}
			
			case 2:{
				system("cls");
				printf("** Crea 2 Alberi manuali ** \n\n");
				printf("Albero T: \n");
				T=creaBST(T);
				printf("\n\n");
				printf("Albero P: \n");
				P=creaBST(P);
				printf("\n\n");
				
				printf("\nGli alberi T e P sono stati creati! \n");
				//Stampo i 2 alberi
				printf("L'albero T creato in maniera manuale e':\n");
				preOrder(T);
				printf("\n\n");
				printf("L'albero P creato in maniera manuale e':\n");
				preOrder(P);
				system("PAUSE");
				
				//Primo punto esercizio
				printf("\nAdesso verifico se i 2 alberi sono uguali:");
				verificauguaglianza= sameBST(T,P);
				
				if(verificauguaglianza==0){
					printf("\nGli alberi T e P non sono uguali!\n");
				}
				else{
					printf("\nGli alberi T e P sono uguali!\n");
				}
				printf("\n");
				system("PAUSE");
				printf("\n");
				//Fine primo punto esercizio
				
				//Secondo punto esercizio
				//printf("\nOra verifichero' che per ogni elemento di T ci sia il suo predecessore e il suo successore:\n");
				//Adesso verifico che ci sia un predecessore 				
				
				break;
			}
			
			case 0: {
				freeTree(T);
				freeTree(P);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeTree(T);
	freeTree(P);
}


