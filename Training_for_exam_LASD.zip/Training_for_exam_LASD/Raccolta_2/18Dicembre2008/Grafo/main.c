#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include "Graph.h"
#include "List.h"


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	srand((unsigned int)time(NULL));
	menu();
}

void menu() {
	int scelta, nodes, i=0, j=0;
	char risp;
	Graph G = NULL, H = NULL, GT = NULL, P = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Svolgi esercizio sui grafi \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea 2 Grafi Orientati manualmente ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nei grafi? \n");
				printf("N = ");
				scanf("%d", &nodes);
				//Sto creando un grafo G  con 0 archi minimi e nodi-1 nodi
				//G = createGraph(nodes, 0, nodes-1);
				G = randomGraph(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				//Sto creando un grafo H con 0 archi minimi e nodi-1 nodi
				//H = createGraph(nodes, 0, nodes-1);
				H = randomGraph(nodes, 0, nodes-1);
				
				//creo il grafo trasposto di G
				GT = trasp(G);
				//Inizializzo un grafo P che sar� quello risultante
				P = initGraph(nodes);
				
				printf("\nI grafi G e H sono stati creati! \n");
				//Stampo i 2 grafi su schermo
				printGraph(G);
				printf("\n");
				printGraph(H);
				printf("\n");
				printf("Questo e' il grafo traposto di G\n");
				//Stampo il trasposto di G
				printGraph(GT);
				system("PAUSE");
				
				printf("\nAdesso il grafo P dovra' avere gli stessi vertici di G e H");
				printf("\nUn arco (a,b) che sia presente sia in H che nella trasposta di G");
				printf("\ne gli archi corrispondenti in P dovranno avere come peso la differenza dei pesi degli archi corrispondenti");
				printf("\nsolo se questa differenza e' positiva\n");
				
				//nodo corrente
				for(i=0;i<nodes;i++){
					//nodi a cui verifichi se � collegato o meno
					for(j=0;j<nodes;j++){
						//se non sono lo stesso nodo
						if(i!=j){
							//verifichiamo la presenza di un arco da i a j
							if(((cercaEl(H->adj[i],j))&&(cercaEl(GT->adj[i],j)))==1){
								int risultatopesi = ritornaPeso(GT->adj[i],j) - (ritornaPeso(H->adj[i],j));
								if(risultatopesi > 0 ){
									addEdge(P,i,j,risultatopesi);
								}
//								else{
//									changeP(G->adj[i],j,sottrazionepesi);
									//G->adj[i]->peso = G->adj[i]->peso - H->adj[j]->peso;
								}
							}
						}
					}
				printf("\nQui il grafo P risultante:\n");
				printGraph(P);
				printf("\n");
				
				int x=0, risultatogrado=0;
				printf("\nb) Dato G e un suo nodo, calcolare il suo grado incidente:\n");
				do{
					printf("Scegliere un nodo da 0 a %d: ",nodes);
					scanf("%d",&x);
				}
				while(x>nodes||x<0);
				risultatogrado= gradoIncid(G,x);
				printf("\n Il grado incidente del nodo %d e': %d",x,risultatogrado);
				
				printf("\nLa complessita' e' O=(V+E)\n");
				system("PAUSE");
				
				
				
				break;
			}
			
			case 0: {
				freeGraph(G);
				freeGraph(H);
				freeGraph(GT);
				freeGraph(P);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeGraph(G);
	freeGraph(H);
	freeGraph(GT);
	freeGraph(P);
}
