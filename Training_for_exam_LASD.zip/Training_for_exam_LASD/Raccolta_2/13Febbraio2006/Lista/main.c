#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "List.h"

//Prototipo togli negativi
List togli_neg(List L);

//Creo lista con numeri positivi e negativi
List creaLista(List L);
// Main
int main(int argc, const char * argv[]) {
	srand((unsigned int)time(NULL));
	menu();
}
	
void menu(){
	int scelta, elementi, min, max, source, target, peso;
	char risp;
	List L1 = NULL;
	List L2 = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Crea 2 Liste L1 e L2 \n");
		printf("[2] Visualizza Liste \n");
		printf("[3] Rimuovi numeri negativi dalla lista scelta \n");
//		printf("[4] Crea Grafo Non Orientato Manuale \n");
//		printf("[5] Stampa Grafi \n");
//		printf("[6] Aggiungi un arco \n");
//		printf("[7] Rimuovi un arco \n");
//		printf("[8] Modifica il peso di un arco \n");
//		printf("[9] Svolgi Esercizio \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea 2 Liste L1 e L2: \n\n");
				printf("Lista L1: \n");
				L1 = creaLista(L1);
				system("cls");
	
				printf("Lista L2: \n");
				L2 = creaLista(L2);
				system("cls");				
				printf("\nListe create! \n");
				system("PAUSE");
				break;
			}
			case 2:{
				system("cls");
				
				printf("Le Liste L1 e L2 sono:\n");
				printf("L1 = ");
				printList(L1);
				printf("\n");
				printf("L2 = ");
				printList(L2);
				printf("\n");
				
				system("PAUSE");
				break;
			}
			case 3:{
				system("cls");
				printf("\nScegli da quale lista rimuovere i numeri negativi (1 per Lista 1, 2 per Lista 2): ");
				scanf("%d",&scelta);
				if(scelta==1){
					L1 = togli_neg(L1);
				}
				else if(scelta==2){
					L2 = togli_neg(L2);
				}
				printf("\nHo rimosso i numeri negativi dalla lista selezionata! \n");
				system("PAUSE");
				break;
			}
//			case 4:{
//				system("cls");
//				printf("** Crea Grafo Non Orientato Manuale ** \n\n");
//				printf("Grafo G: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				printf("\n");
//				G = createGraphNO(nodes, min, max);
//				
//				printf("\nGrafo H: \n");
//				printf("Quanti nodi vuoi nel grafo? \n");
//				printf("N = ");
//				scanf("%d", &nodes);
//				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
//				printf("Min = ");
//				scanf("%d", &min);
//				printf("Max = ");
//				scanf("%d", &max);
//				printf("\n");
//				H = createGraphNO(nodes, min, max);
//				
//				printf("\nGrafi creati! \n");
//				system("PAUSE");
//				break;
//			}
//			case 5:{
//				system("cls");
//				printf("** Stampa Grafi ** \n\n");
//				if((G) && (H)) {
//					printf("Grafo G: \n");
//					printGraph(G);
//					printf("\n");
//					
//					printf("Grafo H: \n");
//					printGraph(H);
//					printf("\n");
//					
//					if(T) {
//						printf("Grafo T: \n");
//						printGraph(T);
//						printf("\n");
//					}
//				}
//				else
//					printf("Devi prima creare i Grafi! \n\n");
//				
//				system("PAUSE");
//				break;
//			}
//			case 6:{
//				system("cls");
//				printf("** Aggiungi un arco ** \n\n");
//				if((G) && (H)) {
//					printf("Inserisci il nodo sorgente: ");
//					scanf("%d", &source);
//					printf("Inserisci il target: ");
//					scanf("%d", &target);
//					printf("Inserisci il peso: ");
//					scanf("%d", &peso);
//					
//					if(cercaArco(G->adj[source], target))
//						printf("\nEsiste gia' un arco da %d a %d ! \n\n", source, target);
//					else {
//						addEdge(G, source, target, peso);
//						printf("\nArco aggiunto! \n\n");
//					}
//				}
//				else
//					printf("Devi prima creare i Grafi! \n\n");
//				
//				system("PAUSE");
//				break;
//			}
//			case 7:{
//				system("cls");
//				printf("** Rimuovi un arco ** \n\n");
//				if((G) && (H)) {
//					printf("Inserisci il nodo sorgente: ");
//					scanf("%d", &source);
//					printf("Inserisci il target: ");
//					scanf("%d", &target);
//					
//					if(cercaArco(G->adj[source], target)){
//						removeEdge(G, source, target);
//						printf("\nArco rimosso! \n\n");
//					}
//					else
//						printf("\nNon esiste un arco da %d a %d ! \n\n", source, target);
//				}
//				else
//					printf("Devi prima creare i Grafi! \n\n");
//				
//				system("PAUSE");
//				break;
//			}
//			case 8:{
//				system("cls");
//				printf("** Modifica il peso di un arco ** \n\n");
//				if((G) && (H)) {
//					printf("Inserisci il nodo sorgente: ");
//					scanf("%d", &source);
//					printf("Inserisci il target: ");
//					scanf("%d", &target);
//					
//					modifyPeso(G, source, target);
//					printf("\nPeso modificato! \n\n");
//				}
//				else
//					printf("Devi prima creare i Grafi! \n\n");
//				
//				system("PAUSE");
//				break;
//			}
//			case 9:{
//				system("cls");
//				printf("** Svolgimento Esercizio ** \n\n");
//				system("PAUSE");
//				break;
//			}
			case 0: {
				freeList(L1);
				freeList(L2);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeList(L1);
	freeList(L2);
	system("PAUSE");
}

// Funzione togli negativi
List togli_neg(List L){
	if(L != NULL){
		if(L->target < 0){
			L = removeNodeList(L,L->target);
			L = togli_neg(L);
		}
		else{
			togli_neg(L->next);
		}
	}
	
	return L;
}

List creaLista(List L){
	int i,n,info;
	
	printf("Quanti elementi vuoi?\n");
	printf("N= ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++){
//		// Per numeri Positivi & Negativi ...
		printf("Inserisci %d elemento: ",i+1);
		scanf("%d",&info);
		
		// Solo per numeri Positivi ...
//		do{
//			printf("Inserisci %d elemento maggiore di 0: ",i+1);
//			scanf("%d",&info);
//		}
//		while(info<=0);
		
		L=appendNodeList(L,info);
	}
	
	return L;
}

