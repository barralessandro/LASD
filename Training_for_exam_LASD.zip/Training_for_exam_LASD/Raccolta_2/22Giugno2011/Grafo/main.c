#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Graph.h"

void menu();

int main(int argc, const char * argv[]) {
    //srand((unsigned int)time(NULL));
	menu();	
}

void menu() {
	int scelta, i,j, nodes, source, target, peso;
	char risp;
	Graph G = NULL, H = NULL, GT = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Crea due grafi G e H orientati \n");
		printf("[2] Stampa Grafi \n");
		printf("[3] Risolvi punto a)\n");
		printf("[4] Risolvi punto b) \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea Grafo Orientato Manuale ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo G? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("\n");
				G = createGraph(nodes, 0, nodes-1);
				//G = randomGraph(nodes,0,nodes-1);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo H? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("\n");
				H = createGraph(nodes, 0, nodes-1);
				//H = randomGraph(nodes,0,nodes-1);
				
				printf("\nGrafi creati! \n");
				
				system("PAUSE");
				break;
			}
			case 2:{
				system("cls");
				printf("** Stampa Grafi ** \n\n");
				if((G) && (H)) {
					printf("Grafo G: \n");
					printGraph(G);
					printf("\n");
					
					printf("Grafo H: \n");
					printGraph(H);
					printf("\n");
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 3:{
				system("cls");
				printf("\nScrivere in linguaggio C una funzione che, presi in input G ne calcoli il grafo trasposto,il grado incidente\n");
				printf("e adiacente.\n");
				
				GT=trasp(G);
				printf("Grafo G: \n");
				printGraph(G);
				printf("\n");
					
				printf("Grafo H: \n");
				printGraph(H);
				printf("\n");
					
				printf("Grafo trasposto di G: \n");
				printGraph(GT);
				printf("\n");
				
				printf("Calcolo dei grafi incidenti e adiacenti di G: \n");
				for(i=0;i<nodes;i++){
					printf("Il grado incidente del nodo %d e': %d\n",i,gradoIncid(GT,i));
					printf("Il grado adiacente del nodo %d e': %d\n",i,gradoAdj(GT,i));	
				}
				
				
				system("PAUSE");
				break;
			}
			case 4:{
				system("cls");
				printf("\nScrivere in linguaggio C una funzione che presi in input G e H restituisca la differenza 'esclusiva' di G e H\n");
				printf("nel seguente modo: per ogni arco in G presente anche in H con quello in H e se la differenza e' negativa  si elimina\n");
				printf("l'arco da G. Viceversa, se l'arco e' in H ma non in G, si inserisce l'arco in H in G. Se invece e' in G ma non in H,\n");
				printf("l'arco rimane invariato\n");
				
				for(i=0;i<nodes;i++){
					//nodi a cui verifichi se � collegato o meno
					for(j=0;j<nodes;j++){
						//se non sono lo stesso nodo
						if(i!=j){
							//verifichiamo la presenza di un arco da i a j
							if(((cercaEl(G->adj[i],j))&&(cercaEl(H->adj[i],j)))==1){	
								int sottrazionepesi = ((ritornaPeso(G->adj[i],j) - (ritornaPeso(H->adj[i],j))));
								if(sottrazionepesi<0){
									G->adj[i]=removeEdge(G, i, j);
								}
								else{
									changeP(G->adj[i], j, sottrazionepesi);
								}
							}
							else if((cercaEl(H->adj[i],j)==1)&&(cercaEl(G->adj[i],j)==0))
								addEdge(G,i,j,ritornaPeso(H->adj[i],j));
						}
					}
				}
				
				printf("\nStampo i nuovi grafi G e H dopo aver eseguito il secondo punto:\n");
				printf("Grafo G: \n");
				printGraph(G);
				printf("\n");
					
				printf("Grafo H: \n");
				printGraph(H);
				printf("\n");		
				system("PAUSE");
				break;
			}
			case 0:{
				freeGraph(G);
				freeGraph(H);
				freeGraph(GT);
				return;
			}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
		}	
	}while((risp != 'n') && (risp != 'N'));
	
	freeGraph(G);
	freeGraph(H);
	freeGraph(GT);
}



