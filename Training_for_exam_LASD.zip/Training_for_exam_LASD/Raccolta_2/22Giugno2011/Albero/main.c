#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "Tree.h"


int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    Tree T=NULL;
    Tree P=NULL;
    int n, verificaT, verificaP, risultato;
    int verificastruttura;
    
    // Creo un nuovo albero T da 10 nodi
    printf("Creo albero T:\n");
    T = creaBST(T);
    printf("\nCreo albero P:\n");
    P = creaBST(P);
    printf("\n\n");
    
    // Eseguo una Pre Order sugli alberi T e P
    printf("L'albero T � quindi:\n");
    preOrder(T);
    printf("\n\nL'albero P � quindi:\n");
    preOrder(P);
    printf("\n\n");
    
    // Adesso verifico se gli alberi sono entrambi degli ABR
    printf("Verifico se gli alberi sono ABR...\n");
	verificaT = isBST(T,-1);
	verificaP = isBST(P,-1);
	if(verificaT==1){
		printf("\nL'albero T e' un ABR!!!\n");
	}
	else{
		printf("\nL'albero T non e' un ABR!!!\n");
	}
	if(verificaP==1){
		printf("\nL'albero P e' un ABR!!!\n");
	}
	else{
		printf("\nL'albero P non e' un ABR!!!\n");
	}
	
	// Adesso verifico se gli alberi hanno la stessa struttura
    printf("Verifico se gli alberi hanno la stessa struttura...\n");
	verificastruttura = sameStructBST(T, P);
	if(verificastruttura==1){
		printf("\nI due alberi hanno la stessa struttura!\n");
	}
	else{
		printf("\nI due alberi non hanno la stessa struttura!\n");
	}
	
	// Adesso dato un numero n verifico che la massima differenza tra tutti i nodi dell'albero T e dell'albero P siano al pi� n
	printf("\nAdesso dato un numero n verifico che la massima differenza\n");
	printf("tra tutti i nodi dell'albero T e dell'albero P siano al piu' n:\n");
	printf("\nInserisci n: ");
	scanf("%d",&n);
	printf("\n");
	risultato = verificaDifferenza(T,P,n);
	if(risultato==1){
		printf("\nLa massima differenza e' al piu' n!\n");
	}
	else{
		printf("\nLa massima differenza NON e' al piu' n!\n");

	}
	
	

    return 0;
}

