#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include "Graph.h"
#include "List.h"


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	srand((unsigned int)time(NULL));
	menu();
}

void menu() {
	int scelta, nodes, i=0, j=0;
	char risp;
	Graph G = NULL, H = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Svolgi esercizio sui grafi \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea 2 Grafi Orientati manualmente ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				//Sto creando un grafo G  con 0 archi minimi e nodi-1 nodi
				G = createGraph(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				H = createGraph(nodes, 0, nodes-1);
				
				printf("\nI grafi G e H sono stati creati! \n");
				//Stampo i 2 grafi su schermo
				printGraph(G);
				printf("\n");
				printGraph(H);
				system("PAUSE");
				
				printf("\nAdesso sottraggo dal peso degli archi di G il peso degli archi corrispondenti di H");
				printf("\nInoltre se la sottrazione rilascia un valore negativo, rimuovo l'arco corrispondente in G");
				
				//nodo corrente
				for(i=0;i<nodes;i++){
					//nodi a cui verifichi se � collegato o meno
					for(j=0;j<nodes;j++){
						//se non sono lo stesso nodo
						if(i!=j){
							//verifichiamo la presenza di un arco da i a j
							if(((cercaEl(G->adj[i],j))&&(cercaEl(H->adj[i],j)))==1){
								int sottrazionepesi = ritornaPeso(G->adj[i],j) - (ritornaPeso(H->adj[i],j));
								if(sottrazionepesi < 0 ){
									removeEdge(G,i,j);
								}
								else{
									changeP(G->adj[i],j,sottrazionepesi);
									//G->adj[i]->peso = G->adj[i]->peso - H->adj[j]->peso;
								}
							}
						}
					}
				}	
				
				printf("\nQui il grafo G modificato:\n");
				printGraph(G);
				printf("\n");
				
				printf("\nLa complessit� e' O=(V+E)\n");
				system("PAUSE");
				
				
				
				break;
			}
			
			case 0: {
				freeGraph(G);
				freeGraph(H);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeGraph(G);
	freeGraph(H);
}
