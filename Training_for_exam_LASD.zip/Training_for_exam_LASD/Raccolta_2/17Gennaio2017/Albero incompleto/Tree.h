#ifndef ABR_Tree_h
#define ABR_Tree_h

struct TTree {
    int info;
    struct TTree* sx;
    struct TTree* dx;
};

typedef struct TTree* Tree;

// Inserisce un nodo nell'albero BST
Tree insertNodeTree(Tree T, int info);

// Inizializza un nuovo nodo
Tree initNode(int info);

// Crea un albero random, come index bisogna specificare
// il numero dei nodi desiderato nell'albero
Tree randomTree(int index);

// Esegue una visita In Order sull'albero T
void inOrder(Tree T);

// Esegue una visita in Pre Order sull'albero T
void preOrder(Tree T);

// Esegue una visita in Post Order sull'albero T
void postOrder(Tree T);

void freeTree(Tree );

// ################################################################## FUNZIONI NOSTRE #####################################################################################

struct TernTree {
    int info;
    struct TernTree* sx;
    struct TernTree* mid;
    struct TernTree* dx;
};
typedef struct TernTree* Ter;

// Crea ABR
Tree creaBST(Tree T);

// Verifica ABR
int isBST(Tree T);

// Cerca Minimo
Tree minimoBST(Tree T);

// Cerca Massimo
Tree massimoBST(Tree T);

// Successore
Tree succBST(Tree T, int k);
Tree succBST_R(Tree T, int k, Tree Y);

// Predecessore
Tree precBST(Tree T, int k);
Tree precBST_R(Tree T, int k, Tree Y);

// Verifica ABR Uguali
int sameBST(Tree T1, Tree T2);

// Somma Due ABR
Tree sumBST(Tree T1, Tree T2, Tree T3);

// **********  Cerca un nodo in un BST  **********
int cercaBST(Tree T, int x);

// **********  Verifica se due ABR sono uguali  **********
int sameBST(Tree T1, Tree T2);

// **********  Inizializza un nuovo nodo Ternario  **********
Ter initNodeTern(int info);

// **********  Stampa PreOrder Ternario  **********
void preOrderTern(Ter T);

// Successore Numerico
int succNumerico(Tree T, int x);

// Cancella nodo in un ABR
Tree cancellaNodoBST(Tree T, int k);

// Stacca il successore in un ABR
Tree staccaSuccBST(Tree Padre, Tree T);

// Cancella nodi dispari in un ABR
Tree cancellaNodiDispari(Tree T);

// Cancella nodi da un albero T1 in T2 (ABR)
//Tree cancellaT1InT2(Tree T1, Tree T2);
#endif
