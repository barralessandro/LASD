#include <stdio.h>
#include <stdlib.h>
#include "Tree.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, const char * argv[]) {
	srand((unsigned int)time(NULL));
	Tree T1 = NULL;
	Tree T2 = NULL;
	Tree finale = NULL;
	//int risultato, risultatocancellazione;
	
	//Qui creo i due alberi
	printf("Albero T1:\n");
	T1 = creaBST(T1);
	printf("\nAlbero T2:\n");
	T2 = creaBST(T2);
	
	//Adesso stampo i 2 alberi
	printf("Albero T1\n");
	printf("Radice= ");
	preOrder(T1);
	printf("\n\n");
	printf("Albero T2\n");
	printf("Radice= ");
	preOrder(T2);
	printf("\n\n");
	
	T2=cancellaT1InT2(T1,T2);
	//stampo risultato;
	printf("\nAlbero T2 modificato:\n");
	preOrder(T2);
	//Nel caso in cui l'albero T2 sia proprio uguale a quello T1 e quindi T2 � stato svuotato del tutto, stampo a video Albero vuoto!
	if(T2==NULL){
		printf("Albero vuoto!\n");
	}
	printf("\n");
    system("PAUSE");
    
    
	
    return 0;
}
