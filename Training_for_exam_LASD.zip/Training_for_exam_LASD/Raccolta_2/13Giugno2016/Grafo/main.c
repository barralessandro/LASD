#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Graph.h"

void menu();

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
	menu();	
}

void menu() {
	int scelta, nodes, min, max, source, target, peso,i,j;
	char risp;
	Graph G = NULL, H = NULL, T = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Crea Grafo Orientato Random \n");
		printf("[2] Crea Grafo Orientato Manuale \n");
		printf("[5] Stampa Grafi \n");
		printf("[6] Aggiungi un arco \n");
		printf("[7] Rimuovi un arco \n");
		printf("[8] Modifica il peso di un arco \n");
		printf("[9] Svolgi Esercizio \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea Grafo Orientato Random ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				G = randomGraph(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				H = randomGraph(nodes, 0, nodes-1);
				
				//Creo il terzo grafo T con la quantit� di nodi scelti per G e H
				T=initGraph(nodes);
				
				printf("\nGrafi creati! \n");
				system("PAUSE");
				break;
			}
			case 2:{
				system("cls");
				printf("** Crea Grafo Orientato Manuale ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("\n");
				G = createGraph(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("\n");
				H = createGraph(nodes, 0, nodes-1);
				
				//Creo il terzo grafo T con la quantit� di nodi scelti per G e H
				T=initGraph(nodes);
				
				printf("\nGrafi creati! \n");
				system("PAUSE");
				break;
			}
			case 3:{
				system("cls");
				printf("** Crea Grafo Non Orientato Random ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				G = randomGraphNO(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				H = randomGraphNO(nodes, 0, nodes-1);
				
				printf("\nGrafi creati! \n");
				system("PAUSE");
				break;
			}
			case 4:{
				system("cls");
				printf("** Crea Grafo Non Orientato Manuale ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("\n");
				G = createGraphNO(nodes, 0, nodes-1);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");

				printf("\n");
				H = createGraphNO(nodes, 0, nodes-1);
				
				printf("\nGrafi creati! \n");
				system("PAUSE");
				break;
			}
			case 5:{
				system("cls");
				printf("** Stampa Grafi ** \n\n");
				if((G) && (H)) {
					printf("Grafo G: \n");
					printGraph(G);
					printf("\n");
					
					printf("Grafo H: \n");
					printGraph(H);
					printf("\n");
					
					if(T) {
						printf("Grafo T: \n");
						printGraph(T);
						printf("\n");
					}
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 6:{
				system("cls");
				printf("** Aggiungi un arco ** \n\n");
				if((G) && (H)) {
					printf("Inserisci il nodo sorgente: ");
					scanf("%d", &source);
					printf("Inserisci il target: ");
					scanf("%d", &target);
					printf("Inserisci il peso: ");
					scanf("%d", &peso);
					
					if(cercaArco(G->adj[source], target))
						printf("\nEsiste gia' un arco da %d a %d ! \n\n", source, target);
					else {
						addEdge(G, source, target, peso);
						printf("\nArco aggiunto! \n\n");
					}
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 7:{
				system("cls");
				printf("** Rimuovi un arco ** \n\n");
				if((G) && (H)) {
					printf("Inserisci il nodo sorgente: ");
					scanf("%d", &source);
					printf("Inserisci il target: ");
					scanf("%d", &target);
					
					if(cercaArco(G->adj[source], target)){
						removeEdge(G, source, target);
						printf("\nArco rimosso! \n\n");
					}
					else
						printf("\nNon esiste un arco da %d a %d ! \n\n", source, target);
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 8:{
				system("cls");
				printf("** Modifica il peso di un arco ** \n\n");
				if((G) && (H)) {
					printf("Inserisci il nodo sorgente: ");
					scanf("%d", &source);
					printf("Inserisci il target: ");
					scanf("%d", &target);
					
					modifyPeso(G, source, target);
					printf("\nPeso modificato! \n\n");
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 9:{
				system("cls");
				printf("** Svolgimento Esercizio ** \n\n");
				for(i=0;i<nodes;i++){
					//nodi a cui verifichi se � collegato o meno
					for(j=0;j<nodes;j++){
						//se non sono lo stesso nodo
						if(i!=j){
							//verifichiamo la presenza di un arco da i a j
							if(((cercaEl(G->adj[i],j))&&(cercaEl(H->adj[i],j)))==1){
								if(ritornaPeso(G->adj[i],j) <= (ritornaPeso(H->adj[i],j))){
									addEdge(T, i, j, ritornaPeso(H->adj[i],j));
								}
								else
									addEdge(T, i, j, ritornaPeso(G->adj[i],j));
							}
							else if(cercaEl(G->adj[i],j)&&(!cercaEl(H->adj[i],j)))
								addEdge(T, i, j, ritornaPeso(G->adj[i],j));	
							else if(!cercaEl(G->adj[i],j)&&(cercaEl(H->adj[i],j)))
								addEdge(T, i, j, ritornaPeso(H->adj[i],j));	
						}
					}
				}
				system("PAUSE");
				break;
			}
			case 0: {
				freeGraph(G);
				freeGraph(H);
				freeGraph(T);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeGraph(G);
	freeGraph(H);
	freeGraph(T);
}

