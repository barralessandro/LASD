#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    //Inizializzo gli alberi
    Tree T1 = NULL;
    Tree T2 = NULL;
    Ter TER = NULL;
    
    //Creo gli alberi T1 e T2 manualmente
    printf("\nAlbero T1:\n");
    T1= creaBST(T1);
    printf("\nAlbero T2:\n");
    T2= creaBST(T2);
    
    printf("\nAlbero T1 appena creato:\n");
    preOrder(T1);
    printf("\n\n");
    printf("\nAlbero T2 appena creato:\n");
    preOrder(T2);
    printf("\n\n");
    
    //Creo albero Ternario da T1
    TER=daBinarioaTernarioconNodo1(T1,T2,TER);
    
    printf("\nStampo Albero TER con le proprieta' richieste:\n");
    preOrderTern(TER);
    printf("\n\n");
    system("PAUSE");
    
    return 0;
}


