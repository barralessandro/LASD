#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "List.h"

void menu();
List cancella_multipli(List L1, List *L2, int k);

// Main
int main(int argc, const char * argv[]) {
	srand((unsigned int)time(NULL));
	menu();
}
	
void menu(){
	int scelta;
	char risp;
	List L1 = NULL;
	List L2 = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Crea 2 Liste L1 e L2 \n");
		printf("[2] Visualizza Liste \n");
		printf("[3] Effettua esercizio! \n");
//		printf("[4] Crea Grafo Non Orientato Manuale \n");
//		printf("[5] Stampa Grafi \n");
//		printf("[6] Aggiungi un arco \n");
//		printf("[7] Rimuovi un arco \n");
//		printf("[8] Modifica il peso di un arco \n");
//		printf("[9] Svolgi Esercizio \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("** Crea 2 Liste L1 e L2: \n\n");
				printf("Lista L1: \n");
				L1 = creaL(L1);
				system("cls");
	
				printf("Lista L2: \n");
				L2 = creaL(L2);
				system("cls");				
				printf("\nListe create! \n");
				system("PAUSE");
				break;
			}
			case 2:{
				system("cls");
				
				printf("Le Liste L1 e L2 sono:\n");
				printf("L1 = ");
				printList(L1);
				printf("\n");
				printf("L2 = ");
				printList(L2);
				printf("\n");
				
				system("PAUSE");
				break;
			}
			case 3:{
				system("cls");

				L1=cancella_multipli(L1,&L2,2);
				L2=cancella_multipli(L2,&L1,5);
				

				printf("\nHo rimosso tutti i multipli di 2 dalla Lista 1 e messi in testa alla Lista 2 \n");
				printf("\nHo rimosso tutti i multipli di 5 dalla Lista 2 e messi in testa alla Lista 1 \n");
				printf("Le Liste L1 e L2 sono:\n");
				printf("L1 = ");
				printList(L1);
				printf("\n");
				printf("L2 = ");
				printList(L2);
				printf("\n");
				system("PAUSE");
				break;
			}
			
			case 0: {
				freeList(L1);
				freeList(L2);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeList(L1);
	freeList(L2);
	system("PAUSE");
}

// ************* Toglie i multipli di n da L1 e li aggiunge in testa ad L2 ***************
List cancella_multipli(List L, List *L2, int k){
    if((L)&&(L2)){
        if((L->target % k) == 0){
            (*L2) = addNodeHead((*L2), L->target);
            L = removeNodeList(L,L->target);
            L = cancella_multipli(L, L2, k);
        }
        else{
            cancella_multipli(L->next, L2, k);
        }
    }
     
    return L;
}
	

