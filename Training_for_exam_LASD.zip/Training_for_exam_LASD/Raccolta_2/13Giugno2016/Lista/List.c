#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "List.h"

List initNodeList(int info) {
    List L = (List)malloc(sizeof(struct TList));
    L->target = info;
    L->next = NULL;
    L->prec = NULL;
    
    return L;
}

List randomList(int index, int mod) {
    List L = NULL;
    int i = 0;
    for (i = 0; i < index; i++) {
        L = appendNodeList(L, rand() % mod);
    }
    return L;
}

//Mette nodi in coda
List appendNodeList(List L, int target) {
	if (L != NULL) {
        L->next = appendNodeList(L->next, target);
        L->next->prec = L;
    } 
	else {
        L = initNodeList(target);
    }
    return L;
}

//Mette nodi in testa
List addNodeHead(List L, int target) {
    if (L != NULL) {
        List G = (List )malloc(sizeof(struct TList));
        G->target = target;
        G->prec = NULL;
        G->next = L;
        L->prec = G;
        
        return G;
    }
    
    return initNodeList(target);
}

void freeList(List L) {
    if (L != NULL) {
        freeList(L->next);
        free(L);
    }
}

void printList(List L) {
    if (L != NULL) {
        printf(" %d -> ", L->target);
        printList(L->next);
    }
}

// ################################################################## FUNZIONI NOSTRE ################################################################################

// ************************** Crea una Lista Manuale ******************************
List creaL(List L){
	int i,n,info;
	
	printf("Quanti elementi vuoi?\n");
	printf("N= ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++){
//		// Per numeri Positivi & Negativi ...
//		printf("Inserisci %d elemento: ",i+1);
//		scanf("%d",&info);
		
		// Solo per numeri Positivi ...
		do{
			printf("Inserisci %d elemento maggiore di 0: ",i+1);
			scanf("%d",&info);
		}
		while(info<=0);
		
		L=appendNodeList(L,info);
	}
	
	return L;
}

// ************************** Rimuove un Nodo dalla Lista ******************************
List removeNodeList(List L, int target) {
    if (L != NULL) {
        if (L->target == target) {
        	// Se ha un solo nodo
        	if((L->prec==NULL)&&(L->next==NULL)){
        		free(L);
        		L=NULL;
			}
        	// Se � la testa
        	else if(L->prec==NULL){
        		List tmp = L;
        		L->next->prec = NULL;
        		L= L->next;
        		free(tmp);
			}
			// Se � la coda
			else if(L->next==NULL){
				List tmp = L;
				L->prec->next = NULL;
				L = L->prec;
				free(tmp);
			}
			// Se � nel mezzo
			else{
				List tmp = L;
				L->prec->next = L->next;
				L->next->prec = L->prec;
				L = L->next;
				free(tmp);
			}
        }
        else{
        	removeNodeList(L->next,target);
		}
    }
    
    return L;
}

// ************************** Ritorna la Dimensione della Lista ******************************
int dimL(List L){
    if(L!=NULL){
        return 1+dimL(L->next);
    }
    else{
    	return 0;
	}
}

// ************************** Somma gli elementi della Lista ******************************
int sommaL(List L){
	if(L!=NULL){
		return sommaL(L->next)+L->target;
	}
	else{
		return 0;
	}
}

// ************************** Salva la Lista in un Array ******************************
void ListToArray(List L, int tmp[], int i){
	if(L != NULL){
		tmp[i] = L->target;
		ListToArray(L->next, tmp, i+1);
	}
}

// ************************** Ritorna la Lista Inversa ******************************
List reverseL(List L){
	int sizeL,i;
	List R=NULL;
	
	sizeL = dimL(L);
	int tmp[sizeL];
	
	ListToArray(L, tmp, 0);
	
	for(i=sizeL-1;i>=0;i--){
		R = appendNodeList(R, tmp[i]);
	}
	
	return R;
}

// ************************** Rimuove gli elementi Dispari dalla Lista ******************************
List togliDispari(List L){
	if(L != NULL){
		if(L->target%2 != 0){
			L = removeNodeList(L,L->target);
			L = togliDispari(L);
		}
		else{
			togliDispari(L->next);
		}
	}
	
	return L;
}

// ************************** Rimuove gli elementi Pari dalla Lista ******************************
List togliPari(List L){
	if(L){
		if((L->target % 2) == 0){
			L = removeNodeList(L,L->target);
			L = togliPari(L);
		}
		else{
			togliPari(L->next);
		}
	}
	
	return L;
}

// ************************** Cerca elemento in una lista ******************************************
List cercaEl(List L, int el) {
	if(L == NULL)
		return NULL;
	else if(L->target == el)
		return L;
	else
		return cercaEl(L->next, el);
}

// ************************** Toglie tutte le ripetizioni dalla Lista ******************************
List togliRipetizioni(List L){
	if(L) {
		List temp = cercaEl(L->next, L->target);
		
		if(temp) {
			L = removeNodeList(L, temp->target);
			L = togliRipetizioni(L);
		}
		else
			togliRipetizioni(L->next);
	}
	
	return L;
}

// ************************** Toglie tutti gli elementi Negativi dalla Lista ******************************
List togliNegativi(List L){
	if(L != NULL){
		if(L->target < 0){
			L = removeNodeList(L,L->target);
			L = togliNegativi(L);
		}
		else{
			togliNegativi(L->next);
		}
	}
	
	return L;
}

// ************************** Accoda L2 a L1 ******************************
List accodaLista(List L1,List L2){
	if (L1 != NULL) {
        L1->next = accodaLista(L1->next, L2);
        L1->next->prec = L1;
    }
    else{
    	L1 = L2;
	}
    
    return L1;
}

// ************************** Ritorna la Testa della Lista **************************
List headList(List L){
	if((L)&&(L->prec != NULL)){
		L = headList(L->prec);
	}
	
	return L;
}

// ************************** Ritorna la Coda della Lista **************************
List tailList(List L){
	if((L)&&(L->next != NULL)){
		L = tailList(L->next);
	}
	
	return L;
}

// ************************** Togli gli elementi di L1 da L2 **************************
List togliL1daL2(List L1, List L2) {
	if(!L1)
		return L2;
	else if(cercaEl(L2, L1->target)) {
		L2 = removeNodeList(L2, L1->target);
		return togliL1daL2(L1->next, L2);
	}
	else
		return togliL1daL2(L1->next, L2);
}

// ************************** Togli somma valori L1 in L2 e viceversa **************************
void togli_somma(List L1, List L2){
	if((L1)&&(L2)){
		int sommaL1 = sommaL(L1);
		if(cercaEl(L2, sommaL1)) {
			L2 = removeNodeList(L2, sommaL1);
			togli_somma(L1, L2);
		}
		int sommaL2 = sommaL(L2);
		if(cercaEl(L1, sommaL2)) {
			L1 = removeNodeList(L1, sommaL2);
			togli_somma(L1, L2);	
		}
	}
}
