#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "List.h"

List togli_pari_dispari(List L, int a);

// MAIN
int main(int argc, const char * argv[]) {
	srand((unsigned int)time(NULL));
	
	int scelta, sceltanumero;
	
	//creo L1 e L2 vuote
	List L1 = NULL, L2 = NULL;
	
	printf("Creazione L1 \n");
	L1 = creaL(L1);
	system("cls");
	
	printf("Creazione L2 \n");
	L2 = creaL(L2);
	system("cls");
	
	printf("Elimino i dispari dalla Lista 1 se passo 1\n");
	printf("Elimino i pari dalla Lista 2 se passo 0.\n");
	printf("Scegli la lista 1 o 2 e un valore da 0 a 1.\n");
	do{
		printf("\nsu quale lista vuoi lavorare? (1 Lista1, 2 Lista2)  :");
		scanf("%d",&scelta);
	}while((scelta<1)&&(scelta>2));
	
	do{
		printf("\nScegli un numero tra 0 o 1: ");
		scanf("%d",&sceltanumero);
	}while((sceltanumero<0)&&(sceltanumero>1));
	
	if((scelta==1)&&(sceltanumero==1)){
		L1 = togli_pari_dispari(L1,sceltanumero);			
	}
	else if((scelta==2)&&(sceltanumero==0)){
		L2 = togli_pari_dispari(L2,sceltanumero);			
	}
	
	printf("L1 = ");
	printList(L1);
	printf("\n");
	
	printf("L2 = ");
	printList(L2);
	printf("\n");
	
	
	return 0;

}

List togli_pari_dispari(List L, int a){
	if(L){
		if(((L->target % 2) != 0)&&(a==1)){
			L = removeNodeList(L,L->target);
			L = togli_pari_dispari(L,a);
		}
		else if(((L->target %2) == 0)&&(a==0)){
			L = removeNodeList(L,L->target);
			L = togli_pari_dispari(L,a);
		}
		else{
			togli_pari_dispari(L->next,a);
		}
	}
	return L;
}

