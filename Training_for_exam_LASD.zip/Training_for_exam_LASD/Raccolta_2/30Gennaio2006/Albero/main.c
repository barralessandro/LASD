#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    int i=0, x;
    // Creo un nuovo albero T da 10 nodi
    Tree T1 = randomTree(7);
    Tree T2 = randomTree(7);
    //Inizializzo un terzo albero T;
    Tree T;
    
    // Eseguo una Pre Order sull'albero T
    printf("Stampa Pre Order albero T1:\n");
	preOrder(T1);
	printf("\n\n");
	printf("Stampa Pre Order albero T2:\n");
	preOrder(T2);
    printf("\n\n");
    T1=cancellaNodiDispari(T1);
    printf("Stampa Pre Order albero T1 senza nodi dispari:\n");
    preOrder(T1);
    T=sumBST(T1,T2,T);
    printf("\n\n");
    printf("in T mettero' la somma dei nodi di T1 modificato e T2:\n");
    preOrder(T);
    
    system("PAUSE");
    
    
	
    return 0;
}

