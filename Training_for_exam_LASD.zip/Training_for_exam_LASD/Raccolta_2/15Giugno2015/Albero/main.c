#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"

Ter daBinarioaTernarioEsercizio(Tree T3, Ter TER);


int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    Tree T1 = NULL;
    Tree T2 = NULL;
    Tree T3 = NULL;
    Ter TER = NULL;
    printf("Albero T1:\n");
    T1 = creaBST(T1);
    printf("\n");
    printf("Albero T2:\n");
    T2 = creaBST(T2);
    printf("\n");
    T3 = sumBST(T1,T2,T3);
    TER= daBinarioaTernarioEsercizio(T3,TER);
    
    // Eseguo una In Order sull'albero T
    printf("Albero T1:\n");
    preOrder(T1);
    printf("\n\n");
    printf("Albero T2:\n");
    preOrder(T2);
    printf("\n\n");
    printf("Albero T3:\n");
    preOrder(T3);
    printf("\n\n");
    printf("Albero TER:\n");
    preOrderTern(TER);
    printf("\n\n");
    

    return 0;
}

Ter daBinarioaTernarioEsercizio(Tree T3,Ter TER){
	int media;
	
	if(T3 != NULL){
		TER = initNodeTern(T3->info);
		
		if((T3->sx != NULL)&&(T3->dx != NULL)){
			media = (T3->sx->info + T3->dx->info)/2;
			TER->mid = initNodeTern(media);
		}
		TER->sx = daBinarioaTernarioEsercizio(T3->sx,TER->sx);
		TER->dx = daBinarioaTernarioEsercizio(T3->dx,TER->dx);
	}
	
	return TER;
}

