#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Tree.h"

Tree randomTree(int index) {
    int i = 0;
    Tree T = NULL;
    for (i = 0; i < index; i++) {
        T = insertNodeTree(T, rand() % 40);
    }
    return T;
}

Tree initNode(int info) {
    Tree T = (Tree)malloc(sizeof(struct TTree));
    T->info = info;
    T->sx = NULL;
    T->dx = NULL;
    return T;
}

Tree insertNodeTree(Tree T, int info) {
    if (T == NULL) {
        T = initNode(info);
    } else {
        if (T->info > info) {
            T->sx = insertNodeTree(T->sx, info);
        } else if (T->info < info) {
            T->dx = insertNodeTree(T->dx, info);
        }
    }
    return T;
}


void inOrder(Tree T) {
    if (T != NULL) {
        inOrder(T->sx);
        printf("%d ", T->info);
        inOrder(T->dx);
    }
}

void preOrder(Tree T) {
    if (T != NULL) {
        printf("Nodo %d \n", T->info);
        if(T->sx)
        	printf("Figlio sinistro di %d: %d \n", T->info, T->sx->info);
        else
        	printf("Figlio sinistro di %d: NULL \n", T->info);
        if(T->dx)
        	printf("Figlio destro di %d: %d \n", T->info, T->dx->info);
        else
        	printf("Figlio destro di %d: NULL \n", T->info);
        	
        preOrder(T->sx);
        preOrder(T->dx);
    }
}

void postOrder(Tree T) {
    if (T != NULL) {
        postOrder(T->sx);
        postOrder(T->dx);
        printf("%d ", T->info);
    }
}

void freeTree(Tree T) {
	if(T) {
		freeTree(T->sx);
		freeTree(T->dx);
		free(T);
	}
}

// ################################################################## FUNZIONI NOSTRE #####################################################################################

// Crea ABR
Tree creaBST(Tree T) {
    int nodo, n, i = 0;
    
    printf("Inserisci il numero di nodi: ");
    scanf("%d", &n);
    printf("\n");
    
    for (i = 0; i < n; i++) {
    	printf("Inserisci %d nodo: ", i + 1);
    	scanf("%d", &nodo);
        T = insertNodeTree(T, nodo);
    }
    
    return T;
}

// Verifica ABR richiamare la funzione nel main passandogli -1 isBST(T,-1);
int isBST(Tree T, int x) {
	if(T) {
		isBST(T->sx, x);
		
		if(T->info > x) {
			x = T->info;
			isBST(T->dx, x);
		}
		else if(T->info < x) {
			x = -1;
			
			return 0;
		}
		
		return 1;
	}
}

// Cerca Minimo
Tree minimoBST(Tree T) {
	if(T == NULL)
		return NULL;
	if((T) && (T->sx))
		return minimoBST(T->sx);
	
	return T;
}

// Cerca Massimo
Tree massimoBST(Tree T) {
	if(T == NULL)
		return NULL;
	if((T) && (T->dx))
		return massimoBST(T->dx);
	
	return T;
}

// Successore
Tree succBST(Tree T, int k) {
	return succBST_R(T, k, NULL);
}

Tree succBST_R(Tree T, int k, Tree Y) {
	if(T) {
		if(k > T->info)
			return succBST_R(T->dx, k, Y);
		else if(k < T->info)
			return succBST_R(T->sx, k, T);
		else {
			if(T->dx)
				return minimoBST(T->dx);
		}
	}
	
	return Y;
}

// Predecessore
Tree precBST(Tree T, int k) {
	return precBST_R(T, k, NULL);
}

Tree precBST_R(Tree T, int k, Tree Y) {
	if(T) {
		if(k > T->info)
			return precBST_R(T->dx, k, Y);
		else if(k < T->info)
			return precBST_R(T->sx, k, T);
		else {
			if(T->sx)
				return massimoBST(T->sx);
		}
	}
	
	return Y;
}

// Verifica ABR Uguali
//int sameBST(Tree T1, Tree T2) {
//	if((T1 == NULL) && (T2 == NULL))
//		return 1;
//	else if((T1->info == T2->info) && (sameBST(T1->sx, T2->sx)) && ((sameBST(T1->dx, T2->dx))))
//		return 1;
//	else
//		return 0;
//}

// Somma Due ABR
Tree sumBST(Tree T1, Tree T2, Tree T3) {
	if((T1) && (T2))
		T3 = insertNodeTree(T3, T1->info + T2->info);
	if((T1->sx) && (T2->sx))
		T3->sx = sumBST(T1->sx, T2->sx, T3->sx);
	if((T1->dx) && (T2->dx))
		T3->dx = sumBST(T1->dx, T2->dx, T3->dx);
	
	return T3;
}

// **********  Cerca un nodo in un BST  **********
int cercaBST(Tree T, int x) { 
    if(T == NULL)
        return 0;    // x non c'�
    else if(T->info == x)
        return 1;     // x trovato
    else if(x < T->info)
        return cercaBST(T->sx, x);
    else
        return cercaBST(T->dx, x);
}

// **********  Verifica se due ABR sono uguali  **********
int sameBST(Tree T1, Tree T2) {
	if((T1)&&(T2))
		return ((T1->info==T2->info) && (sameBST(T1->sx,T2->sx)) && (sameBST(T1->dx,T2->dx)));
	else if(!(T1) && !(T2))
		return 1;
	else
		return 0;
}

// **********  Differenza non superiore ad x dei nodi corrispondenti ABR **********
int verificaDifferenza(Tree T1, Tree T2, double x) {
	if((T1) && (T2)){
		if(fabs((T1->info) - (T2->info)) <= x) 
			return (1) && ((verificaDifferenza(T1->sx,T2->sx, x)) && (verificaDifferenza(T1->dx,T2->dx, x)));
		else
			return 0;	
	}
	else
		return 1;
}

// **********  Stessa struttura tra 2 Alberi  **********
int sameStructBST(Tree T1, Tree T2) {
	if((T1)&&(T2))
		return (sameStructBST(T1->sx,T2->sx)) && (sameStructBST(T1->dx,T2->dx));
	else if(!(T1) && !(T2))
		return 1;
	else
		return 0;
}

// **********  Inizializza un nuovo nodo Ternario  **********
Ter initNodeTern(int info) {
    Ter TER = (Ter)malloc(sizeof(struct TernTree));
    TER->info = info;
    TER->sx = NULL;
    TER->dx = NULL;
    TER->mid = NULL;
    
    return TER;
}

// **********  Crea Albero Ternario da uno Binario con operazione  **********
// modificare l'operazione

Ter daBinarioaTernario(Tree T,Ter TER){
	int media;
	
	if(T != NULL){
		TER = initNodeTern(T->info);
		
		if((T->sx != NULL)&&(T->dx != NULL)){
			media = (T->sx->info + T->dx->info)/2;
			TER->mid = initNodeTern(media);
		}
		TER->sx = daBinarioaTernario(T->sx,TER->sx);
		TER->dx = daBinarioaTernario(T->dx,TER->dx);
	}
	
	return TER;
}

// **********  Stampa PreOrder Ternario  **********
void preOrderTern(Ter T) {
    if (T) {
        printf("Nodo %d \n", T->info);
        
        if(T->sx)
        	printf("Figlio sinistro di %d: %d \n", T->info, T->sx->info);
        else
        	printf("Figlio sinistro di %d: NULL \n", T->info);
        if(T->mid)
        	printf("Figlio centrale di %d: %d \n", T->info, T->mid->info);
        else
        	printf("Figlio centrale di %d: NULL \n", T->info);
        if(T->dx)
        	printf("Figlio destro di %d: %d \n", T->info, T->dx->info);
        else
        	printf("Figlio destro di %d: NULL \n", T->info);
        
        preOrderTern(T->sx);
        preOrderTern(T->dx);
	}
}

// Successore Numerico
int succNumerico(Tree T, int x) {
	if(!T)
		return 0;
	else if(T->info == x + 1)
		return 1;
	else if(x + 1 < T->info)
		return succNumerico(T->sx, x);
	else
		return succNumerico(T->dx, x);
}

// Cancella nodo in un ABR
Tree cancellaNodoBST(Tree T, int k){
	if(T){
		if(k < T->info)
			T->sx = cancellaNodoBST(T->sx, k);
		else if(k > T->info)
			T->dx = cancellaNodoBST(T->dx, k);
		else {
			Tree nodo = T;
			if(nodo->dx==NULL)
				T = nodo->sx;
			else if(nodo->sx==NULL)
				T = nodo->dx;
			else{
				nodo = staccaSuccBST(T, T->dx);
				T->info = nodo->info;
				free(nodo);
			}	
		}
	}
	return T;
}

// Stacca il successore in un ABR
Tree staccaSuccBST(Tree Padre, Tree T){
	if(T){
		if(T->sx)
			return staccaSuccBST(T, T->sx);
		else if(T == Padre->sx)
			Padre->sx = T->dx;
		else
			Padre->dx = T->dx;
	}
	return T;
}

// Cancella nodi dispari in un ABR
Tree cancellaNodiDispari(Tree T) {
    if (T) {
    	if((T->info % 2) != 0){
    		T=cancellaNodoBST(T,T->info);
    		T= cancellaNodiDispari(T);
		}
		else{
			T->sx=cancellaNodiDispari(T->sx);
			T->dx=cancellaNodiDispari(T->dx);
		}
    }
    return T;
}
