#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"
#include <math.h>

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    Tree T = NULL;
    Ter TER = NULL;
    int verificaABR;
    printf("Albero T\n");
    T= creaBST(T);
	printf("\n\n");    
    printf("L'albero T risultante e':\n");
    preOrder(T);
    printf("\n\n");
    
    printf("Adesso verifico se si tratta di un ABR:\n");
    verificaABR= isBST(T, -1);
    if(verificaABR==1){
    	printf("\nL'albero T e' un ABR!\n");
	}
	else{
		printf("\nL'albero T non � un ABR!\n");
	}
	
	TER=daBinarioaTernario(T, TER);
	// Stampo albero ternario;
	printf("\n Albero Ternario TER completo: \n");
	preOrderTern(TER);
	printf("\n\n");
    
    system("PAUSE");
    return 0;
}

