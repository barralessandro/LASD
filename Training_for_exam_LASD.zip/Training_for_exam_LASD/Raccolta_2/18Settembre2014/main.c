#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Graph.h"
void modifyPeso2(Graph G, int source, int target, int nuovopeso);

void main(){
	menu();
}

void modifyPeso2(Graph G, int source, int target, int nuovopeso) {
	if(G) {
		
		if(cercaEl(G->adj[source], target)) {
			
			changeP(G->adj[source], target, nuovopeso);
		}
		else {
			printf("Non esiste un arco da %d a %d ! \n", source, target);
			system("PAUSE");
		}
	}
}

void menu() {
	int scelta, nodes, min, max, source, target, peso, x;
	char risp;
	Graph G = NULL, H = NULL, T = NULL;
	
	do {
		system("cls");
		printf("*** MENU *** \n\n");
		printf("[1] Creazione Grafo Orientato\n");
		printf("[2] Calcolo grado massimo (somma grado entrante + uscente)");
//		printf("[2] Crea Grafo Orientato Manuale \n");
//		printf("[3] Crea Grafo Non Orientato Random \n");
//		printf("[4] Crea Grafo Non Orientato Manuale \n");
		printf("[5] Stampa Grafi \n");
		printf("[6] Aggiungi un arco \n");
		printf("[7] Rimuovi un arco \n");
		printf("[8] Modifica il peso di un arco \n");
		printf("[9] Svolgi Esercizio \n");
		printf("[0] Esci \n\n");
		
		printf("Scegli un opzione: ");
		scanf("%d", &scelta);
		
		switch(scelta) {
			case 1:{
				system("cls");
				printf("Crea Grafo Orientato Random\n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				G = randomGraph(nodes, 0, nodes-1);
				printf("\nGrafo creato! \n");
				printf("Questo e' il grafo appena creato: \n\n");
				if(G) {
					printf("Grafo G: \n");
					printGraph(G);
					printf("\n");
				}
				else{
					printf("Devi prima creare il Grafo! \n\n");
				}
				printf("\nIl grado massimo (somma grado uscente + grado entrante) e': %d \n",gradoMax(G));
				printf("\n");
					do{
						printf("Seleziona un nodo x da 0 a %d: ",nodes);
						scanf("%d",&x);
					}while(x>nodes);
					if(gradoIncid(G,x)>gradoAdj(G,x)){
						removeNode(G, x);
						printGraph(G);
						system("PAUSE");
					}
				int i=0,j=0,pesoA=0,pesoB=0;
				List tmp = G->adj[x];
				for(i=0;i<nodes;i++){
					//se esiste x nella lista di adiacenza del nodo che stiamo analizzando
					if(cercaEl(G->adj[i],x)){
						while(tmp!=NULL){
							if(cercaEl(G->adj[i], tmp->target)){
								pesoA=ritornaPeso(G->adj[i],x)+ritornaPeso(tmp,tmp->target);
								pesoB=ritornaPeso(G->adj[i],tmp->target);
								if(pesoB<pesoA){
										modifyPeso2(G, i, tmp->target, pesoA);
								}
							}
							else{
								pesoA=ritornaPeso(G->adj[i],x)+ritornaPeso(tmp,tmp->target);
								addEdge(G, tmp->target,i, pesoA);
							}
						tmp=tmp->next;	
						}
						
					}
						
				}
				printGraph(G);
				system("PAUSE");
				//printf("%d",grado(G));
				break;
			}
			case 2:{
				system("cls");
				printf("** Crea Grafo Orientato Manuale ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
				printf("Min = ");
				scanf("%d", &min);
				printf("Max = ");
				scanf("%d", &max);
				printf("\n");
				G = createGraph(nodes, min, max);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
				printf("Min = ");
				scanf("%d", &min);
				printf("Max = ");
				scanf("%d", &max);
				printf("\n");
				H = createGraph(nodes, min, max);
				
				printf("\nGrafi creati! \n");
				system("PAUSE");
				break;
			}
			case 3:{
				system("cls");
				printf("** Crea Grafo Non Orientato Random ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
				printf("Min = ");
				scanf("%d", &min);
				printf("Max = ");
				scanf("%d", &max);
				G = randomGraphNO(nodes, min, max);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
				printf("Min = ");
				scanf("%d", &min);
				printf("Max = ");
				scanf("%d", &max);
				H = randomGraphNO(nodes, min, max);
				
				printf("\nGrafi creati! \n");
				system("PAUSE");
				break;
			}
			case 4:{
				system("cls");
				printf("** Crea Grafo Non Orientato Manuale ** \n\n");
				printf("Grafo G: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
				printf("Min = ");
				scanf("%d", &min);
				printf("Max = ");
				scanf("%d", &max);
				printf("\n");
				G = createGraphNO(nodes, min, max);
				
				printf("\nGrafo H: \n");
				printf("Quanti nodi vuoi nel grafo? \n");
				printf("N = ");
				scanf("%d", &nodes);
				printf("Inserisci il numero minimo e massimo di archi per ogni nodo: \n");
				printf("Min = ");
				scanf("%d", &min);
				printf("Max = ");
				scanf("%d", &max);
				printf("\n");
				H = createGraphNO(nodes, min, max);
				
				printf("\nGrafi creati! \n");
				system("PAUSE");
				break;
			}
			case 5:{
				system("cls");
				printf("** Stampa Grafi ** \n\n");
				if((G) && (H)) {
					printf("Grafo G: \n");
					printGraph(G);
					printf("\n");
					
					printf("Grafo H: \n");
					printGraph(H);
					printf("\n");
					
					if(T) {
						printf("Grafo T: \n");
						printGraph(T);
						printf("\n");
					}
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 6:{
				system("cls");
				printf("** Aggiungi un arco ** \n\n");
				if((G) && (H)) {
					printf("Inserisci il nodo sorgente: ");
					scanf("%d", &source);
					printf("Inserisci il target: ");
					scanf("%d", &target);
					printf("Inserisci il peso: ");
					scanf("%d", &peso);
					
					if(cercaEl(G->adj[source], target))
						printf("\nEsiste gia' un arco da %d a %d ! \n\n", source, target);
					else {
						addEdge(G, source, target, peso);
						printf("\nArco aggiunto! \n\n");
					}
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 7:{
				system("cls");
				printf("** Rimuovi un arco ** \n\n");
				if((G) && (H)) {
					printf("Inserisci il nodo sorgente: ");
					scanf("%d", &source);
					printf("Inserisci il target: ");
					scanf("%d", &target);
					
					if(cercaEl(G->adj[source], target)){
						removeEdge(G, source, target);
						printf("\nArco rimosso! \n\n");
					}
					else
						printf("\nNon esiste un arco da %d a %d ! \n\n", source, target);
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 8:{
				system("cls");
				printf("** Modifica il peso di un arco ** \n\n");
				if((G) && (H)) {
					printf("Inserisci il nodo sorgente: ");
					scanf("%d", &source);
					printf("Inserisci il target: ");
					scanf("%d", &target);
					
					modifyPeso(G, source, target);
					printf("\nPeso modificato! \n\n");
				}
				else
					printf("Devi prima creare i Grafi! \n\n");
				
				system("PAUSE");
				break;
			}
			case 9:{
				system("cls");
				printf("** Svolgimento Esercizio ** \n\n");
				system("PAUSE");
				break;
			}
			case 0: {
				freeGraph(G);
				freeGraph(H);
				freeGraph(T);
				return;
			}
		}
		
		system("cls");
		printf("Si desidera tornare al menu' principale? ( [Y] Si, [N] No ) \n");
		printf("Risposta: ");
		scanf("%s", &risp);
	}
	while((risp != 'n') && (risp != 'N'));
	
	freeGraph(G);
	freeGraph(H);
	freeGraph(T);
}
