#include <stdio.h>
#include "stack.h"
#include "queue.h"
int main(int argc, const char * argv[]) {
    int err = 0;
    Stack S = initStack();

    push(S,2,&err);
    push(S,1,&err);
    push(S,0,&err);
    printf("stampa stack S \n");
    printStack(S, &err);

    int a=sommaElemStack(S);
    printf("La somma degli elementi di S e' %d \n", a);
    // Inizializzo una coda
    Queue Q = initQueue();
    // Creo due code random di 10 elementi
    randQueue(Q, 1, &err);

    // Stampo le code
    printf("Stampa coda Q \n");
    printQueue(Q, &err);
    printf("\n");

    a=sommaElemCoda(Q);
    printf("La somma degli elementi di Q e' %d \n", a);



    return 0;
}

/* QUEUE & STACK - funzione che prende in input uno stack S e una coda Q e restituisce S e Q così modificati:
 - I valori dispari di S sono copiati in testa a Q (in ordine di lettura).
 - I valori pari di Q sono rimossi e inseriti in testa ad S se la somma dei valori di Q è inferirore a quella
   dei valori di S, altrimenti l'ordine  è inverito (cioè vanno inseriti sotto ai valori di Q). */
