/* GRAFI - INTERSEZIONE*/
Graph intersezione(Graph G,Graph H){
Graph T = initGraph(H->nodes_count);
List g,h;
int flag,peso,i;
int *arrayEsiste = (int*)calloc(H->nodes_count,sizeof(int));
int *arrayPesi = (int*)calloc(H->nodes_count,sizeof(int));

  for (i = 0;i < H->nodes_count;++i){
    flag = 0;
    if(i-G->nodes_count){
      flag = 1;
      g = G->adj[i];
    }
    h = H->adj[i];
    while (h){
      arrayPesi[h->target] = h->peso;
      arrayEsiste[h->target] = 1;
      h = h->next;
    }
    while (g && flag){
      if (arrayEsiste[g->target] == 1){
        //arco in comune
        peso = arrayPesi[g->target] + g->peso;
        addEdge(T,i,g->target,peso);
        arrayEsiste[g->target] = 0;
      }
      g = g->next;
    }
  }

free(arrayEsiste);
free(arrayPesi);

return T;
}
