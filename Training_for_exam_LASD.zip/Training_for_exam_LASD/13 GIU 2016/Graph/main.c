#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("Acquisizione grafo G \n");
    Graph G = graphCreationMenu(0);
    
    printf("Stampa grafo G \n");
    printGraph(G);
    
    printf("Acquisizione grafo H \n");
    Graph H = graphCreationMenu(0);
    
    printf("Stampa grafo H \n");
    printGraph(H);

    Graph T=Esercizio(G,H);
    printf("Stampa grafo T risultante \n");
    printGraph(T);
    
    freeGraph(G);
    freeGraph(H);
    freeGraph(T);
    return 0;
}

