#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    int vertice;

    printf("Acquizione grafo G \n");
    Graph G = NULL;
    G = graphCreationMenu(0);
    printf("Stampa 'grafo G creato \n");
    printGraph(G);
    printf("\n");

    Graph G1=NULL;
    G1=Trasposto(G);
    printf("Stampa 'grafo trasposto di G \n");
    printGraph(G1);
    printf("\n");

    Graph T=NULL;
    T = Unione(G,G1);
    printf("Stampa 'grafo risultate da esercizio\n");
    printGraph(T);
    printf("\n");

    printf("Inserisci vertice di cui vuoi conoscere Grado entrante/uscente :");
    scanf("%d",&vertice);
    printf("\n");
    int *entrante=malloc(G->nodes_count*sizeof(int));
    int *uscente=malloc(G->nodes_count*sizeof(int));
    CalcolaGradi(G,entrante,uscente);
    printf("vertice:  %d  - grado entrante:  %d  - grado uscente:  %d   \n",vertice,entrante[vertice],uscente[vertice]);

    freeGraph(G);
    freeGraph(G1);
    freeGraph(T);
    printf("Grafi G, G1 e T deallocati \n");
    return 0;
}
