#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main(int argc, char *argv[]) {


	printf("Acquisizione stack \n");
	Stack S=stackCreationMenu(0);


	printf("Stampa stack acquisito \n");
	printStack(S);


	moltiplica(S);
	printf("Stampa stack dopo la funzione moltiplica \n");
	printStack(S);

	printf("\n");

	free(S);
	printf("Stack deallocato \n");
	return 0;
}
