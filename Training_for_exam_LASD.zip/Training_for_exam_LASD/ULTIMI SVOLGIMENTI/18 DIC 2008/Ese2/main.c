#include <stdlib.h>
#include <stdio.h>
#include "lista.h"

int main(){

  printf("Acquisizione lista uno \n");
  Lista a=riempi();
  printf("Stampa lista uno acquisita\n");
  StampaLista(a);
  printf("\n");

  printf("Acquisizione lista due \n");
  Lista b=riempi();
  printf("Stampa lista due acquisita\n");
  StampaLista(b);
  printf("\n");

  esercizio(&a,&b);
  printf("Stampa lista uno dopo esercizio\n");
  StampaLista(a);
  printf("\n");
  printf("Stampa lista due dopo esercizio\n");
  StampaLista(b);
  printf("\n");

  return 0;
}
