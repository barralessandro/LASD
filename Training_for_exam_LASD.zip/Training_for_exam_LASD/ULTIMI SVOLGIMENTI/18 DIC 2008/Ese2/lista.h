#ifndef listaDoppiam_h
#define listaDoppiam_h


struct listDoppiam {
  struct listDoppiam *prev;
  int info;
  struct listDoppiam *next;
};
typedef struct listDoppiam* Lista;


Lista AllocaNodo(int info);

int ListaVuota(Lista Head);

Lista InserisciTesta(Lista Head,int elem);

Lista InserisciCoda(Lista Head,int elem);

Lista riempi();

void StampaLista(Lista Head);

void RimuoviOccorrenze(Lista *Head,int elem);

Lista AggiornaTesta(Lista Head);

Lista InsOrdinato(Lista Head,int val);

Lista EliminaNodo(Lista Head,int elem);

void esercizio(Lista *Uno, Lista *Due);
#endif
