#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    printf("Acquisizione grafo G \n");
    Graph G = graphCreationMenu(0);
    printf("Stampa grafo G \n");
    printGraph(G);

    //punto a.1
    Graph H=Trasposto(G);
    printf("Stampa grafo H trasposto del grafo G \n");
    printGraph(H);

    int *aux1=(int *)malloc(G->nodes_count*sizeof(int));
    int *aux2=(int *)malloc(G->nodes_count*sizeof(int));
    
    //punto a.2
    CalcolaGradi(G,aux1,aux2);
    int j;
    
    for(j=0; j<G->nodes_count; j++){
    	printf("Vertice %d - GradoEntrante %d - GradoUscente %d \n",j,aux1[j],aux2[j]);
    }
    
    Esercizio(&G,&H);
    printf("Stampa grafo G dopo esercizio \n");
    printGraph(G);
    
    printf("Stampa grafo H dopo esercizio \n");
    printGraph(H);

    freeGraph(G);
    freeGraph(H);
    printf("Grafi deallocati \n");
    
    return 0;
}
