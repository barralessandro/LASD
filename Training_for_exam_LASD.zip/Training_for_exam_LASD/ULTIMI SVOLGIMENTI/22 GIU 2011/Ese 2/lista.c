#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int EmptyList(Lista Head){
  return Head==NULL;
}

Lista AllocaNodo(int elem){
  Lista Head=malloc(sizeof(struct nodo));
  Head->info=elem;
  Head->next=NULL;
  Head->prev=NULL;
return Head;
}

Lista InserisciInTesta(Lista Head,int elem){
  Lista App=NULL;
  if(!EmptyList(Head)){
    App=AllocaNodo(elem);
    App->next=Head;
  }
  else
    App=AllocaNodo(elem);

return App;
}

Lista InserisciInCoda(Lista Head,int elem){
  if(!EmptyList(Head))
    Head->next=InserisciInCoda(Head->next,elem);
  else
    Head=InserisciInTesta(Head,elem);

return Head;
}

Lista Riempi(){
  Lista Head=NULL;
  int n,elem,i;

  printf("Quanti elementi vuoi inserire nella lista? : ");
  scanf("%d",&n);

  while(n<1){
    printf("Devi inserire una dimensione maggiore o uguale ad 1 \n");
    printf("Quanti elementi vuoi inserire nella lista? : ");
    scanf("%d",&n);
  }

  for(i=0; i<n; i++){
    printf("Inserisci  %d ° elemento della lista  ",i+1);
    scanf("%d",&elem);
    Head=InserisciInCoda(Head,elem);
    printf("\n");
  }

  return Head;
}

Lista EliminaElemPari(Lista Head){
  Lista app=NULL;
  if(!EmptyList(Head)){
    if(Head->info%2!=0)
        Head->next=EliminaElemPari(Head->next);
    else{
          app=Head;
          if(!EmptyList(Head->next))
          //Head->prev->next=app->next;
          Head->next->prev=app->next;
          Head=Head->next;
          Head=EliminaElemPari(Head);
        }
  }
return Head;
}

Lista EliminaElemDispari(Lista Head){
  Lista app=NULL;
  if(!EmptyList(Head)){
    if(Head->info%2==0)
        Head->next=EliminaElemDispari(Head->next);
    else{
          app=Head;
          if(!EmptyList(Head->next))
          //Head->prev->next=app->next;
          Head->next->prev=app->next;
          Head=Head->next;
          Head=EliminaElemDispari(Head);
        }
  }
  return Head;
}

Lista EliminaEdInserisciMultipliDiTre(Lista Uno,Lista *Due){
  Lista app=NULL;
  if(!EmptyList(Uno)){
    if(Uno->info%3!=0)
        Uno->next=EliminaEdInserisciMultipliDiTre(Uno->next,&(*Due));
    else{
          (*Due)=InserisciInTesta((*Due),Uno->info);
          app=Uno;
          if(!EmptyList(Uno->next))
          //Head->prev->next=app->next;
          Uno->next->prev=app->next;
          Uno=Uno->next;
          Uno=EliminaEdInserisciMultipliDiTre(Uno,&(*Due));
        }
  }
  return Uno;
}

void PrintList(Lista Head){
  if(!EmptyList(Head)){
    printf(" %d -> ",Head->info);
    PrintList(Head->next);
  }
  else
    printf(" NULL \n \n");
}
