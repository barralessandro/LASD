#ifndef LISTA_LIBRARY
#define LISTA_LIBRARY

struct nodo{
  struct nodo* prev;
  int info;
  struct nodo *next;
};
typedef struct nodo* Lista;

int EmptyList(Lista Head);

Lista AllocaNodo(int elem);

Lista InserisciInTesta(Lista Head,int elem);

Lista InserisciInCoda(Lista Head,int elem);

Lista Riempi();

Lista EliminaElemPari(Lista Head);
Lista EliminaElemDispari(Lista Head);
Lista EliminaEdInserisciMultipliDiTre(Lista Uno,Lista *Due);

void PrintList(Lista Head);

#endif
