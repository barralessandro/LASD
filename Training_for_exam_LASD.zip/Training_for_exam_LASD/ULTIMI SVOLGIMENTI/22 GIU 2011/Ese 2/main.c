#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
int main(){

    printf("Acquisizione lista uno \n");
    Lista a=Riempi();

    printf("Stampa lista uno \n");
    PrintList(a);

    printf("Acquisizione lista due \n");
    Lista b=Riempi();

    printf("Stampa lista due \n");
    PrintList(b);

    a=EliminaElemPari(a);
    printf("Stampa lista dopo eliminazione pari \n");
    PrintList(a);

    b=EliminaElemDispari(b);
    printf("Stampa lista dopo eliminazione dispari \n");
    PrintList(b);

    a=EliminaEdInserisciMultipliDiTre(a,&b);
    printf("Stampa lista dopo eliminazione multipli di 3 \n");
    PrintList(a);
    printf("Stampa lista dopo inserimento in testa elementi multipli di 3 \n");
    PrintList(b);
    return 0;
}
