#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tree.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    int n;

    printf("Acquisizione albero T1 \n");
    Tree T1 = treeCreationMenu(0);
    printf("Stampa albero T1 \n");
    preOrderPrint(T1);
    printf("Acquisizione albero T2 \n");
    Tree T2 = treeCreationMenu(0);
    printf("Stampa albero T2 \n");
    preOrderPrint(T2);
    // punto a esercizio
    if(CheckAbr(T1))
      printf("+++ L'albero T1 è un ABR \n");
    else
      printf("+++ L'albero T1 non è un ABR \n");
    // punto a esercizio
    if(CheckAbr(T2))
      printf("+++ L'albero T2 è un ABR \n");
    else
      printf("+++ L'albero T2 non è un ABR \n");

    // punto b esercizio
    if(CheckSameStructure(T1,T2))
      printf("+++ I due alberi T1 e T2 hanno la stessa struttura \n");
    else
      printf("+++ I due alberi T1 e T2 non hanno la stessa struttura \n");

    // punto c esercizio
    printf("Inserisci differenza massima che deve esserci fra le chiavi dei due alberi: ");
    scanf("%d",&n);
    printf("\n");
    printf("La funzione ritorna %d \n",CheckDifference(T1,T2,n));
    printf("\n");

    return 0;
}
