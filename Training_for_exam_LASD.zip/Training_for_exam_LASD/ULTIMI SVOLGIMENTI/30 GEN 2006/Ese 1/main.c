#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main(int argc, char *argv[]) {
	printf("Acquisizione stack uno \n");
	Stack S=stackCreationMenu(0);
	
	printf("Stampa stack uno acquisito \n");
	printStack(S);
	
	Raddoppia(S);
	
	printf("Stampa stack uno dopo funzione raddoppia \n");
	printStack(S);
	free(S);
	return 0;
}
