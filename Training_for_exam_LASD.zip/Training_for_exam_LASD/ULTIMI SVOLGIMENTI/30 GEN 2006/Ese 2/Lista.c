#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"


int ListaVuota(Lista Head){
	return Head==NULL;
}

Lista AllocaNodo(int elem){
	Lista Head=malloc(sizeof(struct nodo));
	Head->info=elem;
	Head->next=NULL;
	Head->prev=NULL;
return Head;
}

Lista InserisciInCoda(Lista Head, int elem){
	if(ListaVuota(Head))
		Head=AllocaNodo(elem);
	else
		Head->next=InserisciInCoda(Head->next,elem);
}

void StampaLista(Lista Head){
	if(!ListaVuota(Head)){
		printf(" %d -> ",Head->info);
		StampaLista(Head->next);
		}
	else
		printf(" NULL \n \n");
}

Lista Riempi(){
int i,elem,n;
Lista Head=NULL;	
	printf("Quanti elementi vuoi inerire nella lista? : ");
	scanf("%d",&n);
	
	while(n<1){
			printf("Devi inserire una dimensione maggiore o uguale ad 1 per la lista!! \n");
			printf("Quanti elementi vuoi inerire nella lista? : ");
			scanf("%d",&n);
		}
	
	for(i=0; i<n; i++){
		printf("Inserisci %d° elemento della lista: ",i+1);
		scanf("%d",&elem);
		Head=InserisciInCoda(Head,elem);
		printf("\n");
		}
		
return Head;
}

void Togli_Pari_Dispari(Lista *Head,int elem){
Lista *App;
	if(!ListaVuota(*Head)){
		if( ((*Head)->info)%2 != elem)
			Togli_Pari_Dispari(&(*Head)->next,elem);
		else{
			*App=*Head;
			if(!ListaVuota((*Head)->next))
				(*Head)->next->prev=(*App)->next;
				(*Head)=(*Head)->next;
				Togli_Pari_Dispari(&(*Head),elem);
			}
	}
}

Lista Interlaving(Lista *Uno, Lista *Due,Lista Tre){
//Lista Tre=NULL;
	if(!ListaVuota(*Uno) && !ListaVuota(*Due)){
		Tre=InserisciInCoda(Tre,(*Uno)->info);
		Tre=InserisciInCoda(Tre,(*Due)->info);
		Tre=Interlaving(&(*Uno)->next,&(*Due)->next,Tre);
		}
	
	else{
		if(!ListaVuota((*Uno))){
			Tre=InserisciInCoda(Tre,(*Uno)->info);
			Tre=Interlaving(&(*Uno)->next,&(*Due),Tre);	
			}
			
		if(!ListaVuota((*Due))){
			Tre=InserisciInCoda(Tre,(*Due)->info);
			Tre=Interlaving(&(*Uno),&(*Due)->next,Tre);	
			}
		}	
			
return Tre;
}

