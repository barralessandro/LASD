#ifndef LIBRARY_LIST_C
#define LIBRARY_LIST_C

struct nodo{
	struct nodo* prev;
	int info;
	struct nodo* next;
};
typedef struct nodo* Lista;


int ListaVuota(Lista Head);

Lista AllocaNodo(int elem);

Lista InserisciInCoda(Lista Head, int elem);

void StampaLista(Lista Head);

Lista Riempi();

//passare 0 al posto di elem per eliminare elementi pari, passare 1 per eliminare elementi dispari
void Togli_Pari_Dispari(Lista *Head,int elem);

Lista Interlaving(Lista *Uno, Lista *Due,Lista Tre);
#endif
