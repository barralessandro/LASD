#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"
int main(){
	
	printf("Acquisizione lista uno \n");
	Lista Uno=Riempi();
	
	printf("Stampa lista uno acquisita \n");
	StampaLista(Uno);
	
	printf("Acquisizione lista due \n");
	Lista Due=Riempi();
	
	printf("Stampa lista uno acquisita \n");
	StampaLista(Due);
	
	Togli_Pari_Dispari(&Uno,1);
	Togli_Pari_Dispari(&Due,0);
	
	printf("Stampa lista uno dopo eliminazione pari  \n");
	StampaLista(Uno);
	
	printf("Stampa lista uno dopo eliminazione dispari  \n");
	StampaLista(Due);
	
	Lista Tre=Interlaving(&Uno,&Due,NULL);
	printf("Stampa lista risultante da interlaving \n");
	StampaLista(Tre);	
	
return 0;
}
