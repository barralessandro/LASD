#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("Acquisizione grafo G \n");
    Graph G = graphCreationMenu(0);
    printf("Stampa grafo G \n");
    printGraph(G);
    
    printf("Acquisizione grafo H \n");
    Graph H = graphCreationMenu(0);
    printf("Stampa grafo H \n");
    printGraph(H);


    G=Esercizio(G,H);
    
    printf("Stampa grafo G  dopo esercizio\n");
    printGraph(G);
    
    printf("Stampa grafo H dopo esercizio\n");
    printGraph(H);

    freeGraph(G);
    freeGraph(H);
    
    return 0;
}

