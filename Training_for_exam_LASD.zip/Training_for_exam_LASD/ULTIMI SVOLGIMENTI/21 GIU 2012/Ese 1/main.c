#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main(int argc, const char * argv[]) {

    printf("Acquisizione coda \n");
    Queue coda = queueCreationMenu(0);
    printf("Stampa coda acquisita \n");
    printQueue(coda);


    gioco(coda);

    printf("Stampa coda dopo gioco \n");
    printQueue(coda);
    return 0;
}
