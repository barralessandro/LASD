#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tree.h"
#include <limits.h>

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    printf("Acquisizione albero T \n");
    Tree T = treeCreationMenu(0);

    printf("Stampa albero T\n");
    preOrderPrint(T);

    printf("\n la funzione ritorna %d \n",checkAbr(T));
/*
    Ternario A=TernFromBst(T);
    printf("Stampa albero T in ternario A \n");
    preOrderTern(A);
    printf("\n");

    A=AddMiddleSon(A);
    printf("Stampa albero A dopo aggiunta figlio centrale \n");
    preOrderTern(A);
    printf("\n");

    freeTree(T);
    printf("Albero T deallocato \n");
*/
    return 0;
}
