#include <stdio.h>
#include <stdlib.h>
#include "tree.h"
#include "inputReader.h"
#include <limits.h>

Tree randomTree(int nodes) {
    int i = 0;
    Tree T = NULL;
    for (i = 0; i < nodes; i++) {
        T = insertNodeTree(T, rand() % 40);
    }
    return T;
}

Tree treeCreationMenu(int n){
	int input=1;
	do{
		if(input==0 || input>3) printf("Nessuna azione associata al codice %d\n",input);
		printf("Seleziore il metodo di creazione del nuovo albero:\n");
		printf("1) Albero vuoto\n");
		printf("2) Albero popolato da valori forniti in input\n");
		printf("3) Albero popolato da valori random\n");
	} while(!getPositive(&input) || input>3 ||input ==0);

	if (n<=0) {
		do{
			printf("Quanti elementi da inserire?\n");
		}
		while(!getPositive(&n));
	}
	if(input==2){
		printf("Digita gli elementi da inserire : \n");
		Tree T = NULL;
		int i;
		for (i=0; i<n; i++) {
			printf("Mancano %d valori\n", n-i);
			while(!getInt(&input)){ printf("Il valore digitato non � un intero, riprovare.\n");};
			T = insertNodeTree(T, input);
		}
		return T;
	}
	else {
		return randomTree(n);
	}
}

Tree initNode(int info) {
    Tree T = (Tree)malloc(sizeof(struct TTree));
    T->info = info;
    T->sx = NULL;
    T->dx = NULL;
    return T;
}

Tree insertNodeTree(Tree T, int info) {
    if (T == NULL) {
        T = initNode(info);
    } else {
        if (T->info > info) {
            T->sx = insertNodeTree(T->sx, info);
        } else if (T->info < info) {
            T->dx = insertNodeTree(T->dx, info);
        }
    }
    return T;
}


void inOrder(Tree T) {
    if (T != NULL) {
        inOrder(T->sx);
        printf("%d ", T->info);
        inOrder(T->dx);
    }
}
void inOrderPrint(Tree T) {
	inOrder(T);
	printf("\n\n");
}

void preOrder(Tree T) {
    if (T != NULL) {
        printf("%d ", T->info);
        preOrder(T->sx);
        preOrder(T->dx);
    }
}
void preOrderPrint(Tree T) {
	preOrder(T);
	printf("\n\n");
}

void postOrder(Tree T) {
    if (T != NULL) {
        postOrder(T->sx);
        postOrder(T->dx);
        printf("%d ", T->info);
    }
}
void postOrderPrint(Tree T) {
	postOrder(T);
	printf("\n\n");
}

void graphic(Tree tree, char *str, int last){
    char tmp[100];
	if(tree!=NULL){
        //Cambia la modalit� di stampa se � l'ultimo figlio
        if(!last)
            printf("%s--%d\n", str, tree->info);
        else
            printf("%s\\-%d\n", str, tree->info);

        //Stampa i sottoalberi solo se almeno uno dei due non � vuoto
        if(tree->sx != NULL || tree->dx != NULL) {
            //Sceglie la stringa da stampare in base al sottoalbero dove si scende
            sprintf(tmp, "%s  |", str);
			graphic(tree->dx, tmp, 0);

            sprintf(tmp, "%s   ", str);
			graphic(tree->sx, tmp, 1);
        }
	}
    else {
        if(!last)
            printf("%s--NIL\n", str);
        else
            printf("%s\\-NIL\n", str);
    }
}

void graphicPrint(Tree T) { //Stampa graficamente in preorder l'albero
	graphic(T, "", 0);
}

void freeTree(Tree T) {
	if(T) {
		freeTree(T->sx);
		freeTree(T->dx);
		free(T);
	}
}

int checkAbr(Tree T){
  return checkAbrUtility(T,INT_MIN,INT_MAX);
}
int checkAbrUtility(Tree T, int min, int max){
  int ris=1;
  if(T!=NULL){
    if(T->info<min || T->info > max){
      ris=0;
      return ris;
    }
    return checkAbrUtility(T->sx,min,T->info) && checkAbrUtility(T->dx,T->info,max);
  }
  return ris;
}
//****************************************************************************
Ternario initNodeTern(int info) {
    Ternario A = (Ternario)malloc(sizeof(struct TTern));
    A->info = info;
    A->sx = NULL;
    A->cx = NULL;
    A->dx = NULL;
    return A;
}

Ternario insertNodeTern(Ternario A, int info) {
    if (A == NULL) {
        A = initNodeTern(info);
    } else {
        if (A->info > info) {
            A->sx = insertNodeTern(A->sx, info);
        } else if (A->info < info) {
            A->dx = insertNodeTern(A->dx, info);
        }
    }
    return A;
}

void preOrderTern(Ternario A) {
    if (A != NULL) {
        printf("%d ", A->info);
        preOrderTern(A->sx);
        preOrderTern(A->cx);
        preOrderTern(A->dx);
    }
}

Ternario TernFromBst(Tree T){
  Ternario A=NULL;
  if(T!=NULL){
    A=insertNodeTern(A,T->info);
    A->sx=TernFromBst(T->sx);
    A->dx=TernFromBst(T->dx);
  }
  return A;
}

Ternario AddMiddleSon(Ternario A){
  int val;
  if(A!=NULL){
    if(A->sx!=NULL && A->dx!=NULL){
      val=A->sx->info+A->dx->info;
      A->cx=initNodeTern(val/2);
    }
    A->sx=AddMiddleSon(A->sx);
    A->dx=AddMiddleSon(A->dx);
  }
return A;
}
