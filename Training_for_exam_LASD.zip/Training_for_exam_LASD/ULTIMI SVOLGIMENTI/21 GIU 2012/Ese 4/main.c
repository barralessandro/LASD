#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    printf("Acquisizione Grafo G \n");
    Graph G = graphCreationMenu(0);
    printf("Stampa grafo G \n");
    printGraph(G);
    printf("\n");

    int *aux1=(int *)malloc(G->nodes_count*sizeof(int));
    int *aux2=(int *)malloc(G->nodes_count*sizeof(int));

    CalcolaGadi(G,aux1,aux2);

    int i;
    for(i=0; i<G->nodes_count; i++){
      printf("Vertice %d - Grado entrante %d - Grado uscente %d \n",i,aux1[i],aux2[i]);
    }
    printf("\n");
/*
    printf("Acquisizione Grafo H \n");
    Graph H = graphCreationMenu(0);
    printf("Stampa grafo H \n");
    printGraph(H);
    printf("\n");

    Graph T=esercizio(G,H);
    printf("Grafo intersezione creato \n");
    printf("Stampa grafo T \n");
    printGraph(T);
    printf("\n");


    freeGraph(H);
    freeGraph(T); */
    freeGraph(G);

    printf("Grafi deallocati \n");
    return 0;
}
