#ifndef LISTA_H
#define LISTA_H


struct nodo{
	struct nodo* prev;
	int info;
	struct nodo* next;
};
typedef struct nodo* Lista;

int ListEmpty(Lista Head);

Lista AllocaNodo(int elem);

Lista InsCoda(Lista Head,int elem);

Lista Riempi();

void PrintList(Lista Head);

int NumElem(Lista Head);

int CheckElem(Lista Head,int elem);

Lista EliminaElem(Lista Head,int elem);

void togli_numero(Lista *Uno, Lista *Due);

Lista RimuoviOccorrenze(Lista Head,int elem);

#endif
