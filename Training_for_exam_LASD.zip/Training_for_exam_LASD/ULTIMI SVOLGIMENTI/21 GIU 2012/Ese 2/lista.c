#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int ListEmpty(Lista Head){
  return Head==NULL;
}


Lista AllocaNodo(int elem){
  Lista App=malloc(sizeof(struct nodo));
  App->info=elem;
  App->next=NULL;
  App->prev=NULL;
return App;
}


Lista InsCoda(Lista Head,int elem){
  if(!ListEmpty(Head))
    Head->next=InsCoda(Head->next,elem);
  else
    Head=AllocaNodo(elem);

return Head;
}


Lista Riempi(){
  int n,elem,i;
  Lista app=NULL;
  printf("Quanti elementi vuoi inserire nella lista? : ");
  scanf("%d",&n);
  printf("\n");

  while(n<1){
    printf("Devi inserire una dimensione maggiore o uguale ad 1 \n");
    printf("Quanti elementi vuoi inserire nella lista? : ");
    scanf("%d",&n);
    printf("\n");
  }

  for(i=0; i<n; i++){
    printf("Inserisci elemento %d nella lista:  ",i+1);
    scanf("%d",&elem);
    app=InsCoda(app,elem);
    printf("\n");
  }
return app;
}


void PrintList(Lista Head){
  if(!ListEmpty(Head)){
    printf(" %d -> ",Head->info);
    PrintList(Head->next);
    }
  else
    printf(" NULL \n");
}


int NumElem(Lista Head){
  int num=0;
  if(!ListEmpty(Head)){
    num=NumElem(Head->next);
    num=num+1;
  }
return num;
}


int CheckElem(Lista Head,int elem){
  int ris=0;
  if(!ListEmpty(Head)){
    if(Head->info==elem){
      ris=1;
      return ris;
      }
    else
      return CheckElem(Head->next,elem);
  }
return ris;
}


Lista EliminaElem(Lista Head,int elem){
  Lista app;
  if(!ListEmpty(Head)){
    if(Head->info!=elem)
      Head->next=EliminaElem(Head->next,elem);
    else{
      app=Head;
        if(!ListEmpty(Head->next))
          Head->next->prev=app->prev;
          Head=Head->next;
          free(app);
      }
  }
return Head;
}

Lista RimuoviOccorrenze(Lista Head,int elem){
  if(!ListEmpty(Head)){
    if(Head->info==elem){
      Head=EliminaElem(Head,elem);
      Head=RimuoviOccorrenze(Head,elem);
      }
    else
      Head->next=RimuoviOccorrenze(Head->next,elem);
  }
return Head;
}

void togli_numero(Lista *Uno, Lista *Due){
  int a,b;
  if(!ListEmpty(*Uno)){
    a=NumElem(*Uno);

    if(!ListEmpty(*Due)){
      if(CheckElem((*Due),a)) //controllo di esistenza elemento a nella lista Due
        (*Due)=RimuoviOccorrenze((*Due),a);
      else
        return;

    b=NumElem(*Due);
    if(CheckElem((*Uno),b))//controllo di esistenza elemento b nella lista Uno
      (*Uno)=RimuoviOccorrenze((*Uno),b);
    else
      return;
    }
    togli_numero(&(*Uno),&(*Due));
  }
}
