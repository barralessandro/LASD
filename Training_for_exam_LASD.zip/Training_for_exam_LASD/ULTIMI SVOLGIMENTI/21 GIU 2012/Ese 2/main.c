#include <stdio.h>
#include <stdlib.h>
#include "lista.h"


int main(){

  printf("Acquisizione lista uno \n");
  Lista a=Riempi();
  printf("Stampa lista uno acquisita \n");
  PrintList(a);

  
  printf("Acquisizione lista due \n");
  Lista b=Riempi();
  printf("Stampa lista due acquisita \n");
  PrintList(b);

  togli_numero(&a,&b);

  printf("Stampa lista uno dopo togli_numero \n");
  PrintList(a);
  printf("Stampa lista due dopo togli_numero \n");
  PrintList(b);

return 0;
}
