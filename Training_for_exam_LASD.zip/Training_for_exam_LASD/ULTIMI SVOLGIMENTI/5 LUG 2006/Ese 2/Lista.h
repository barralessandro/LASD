#ifndef LIbrary_list_c
#define Library_list_c

struct nodo{
	struct nodo* prev;
	int info;
	struct nodo* next;
};
typedef struct nodo* Lista;


int ListaVuota(Lista Head);

Lista AllocaNodo(int elem);

Lista InserisciInCoda(Lista Head,int elem);

Lista Riempi();

void StampaLista(Lista Head);

int MaxList(Lista Head);
int MaxListUtility(Lista Head,int max);

int MinList(Lista Head);
int MinListUtility(Lista Head,int min);

Lista EliminaElemento(Lista Head,int elem);

int CheckThree(Lista Prova);
#endif
