#include "Lista.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

int ListaVuota(Lista Head){
	return Head==NULL;
}

Lista AllocaNodo(int elem){
	Lista Head=malloc(sizeof(struct nodo));
	Head->info=elem;
	Head->next=NULL;
	Head->prev=NULL;
return Head;
}

Lista InserisciInCoda(Lista Head,int elem){
	
	if(!ListaVuota(Head))
		Head->next=InserisciInCoda(Head->next,elem);
	else
		Head=AllocaNodo(elem);
	
return Head;
}

Lista Riempi(){
int i,elem,n;
Lista Head=NULL;

	printf("Quanti elementi vuoi inserire nella lista? : ");
	scanf("%d",&n);
	printf("\n");
	
	while(n<1){
		printf("Devi inserire una dimensione maggiore o uguale ad 1 per la lista!!! \n");
		printf("Quanti elementi vuoi inserire nella lista? : ");
		scanf("%d",&n);
		printf("\n");
	}
	
	for(i=0; i<n; i++){
		printf("Inserisci %d° elemento della lista: ",i+1);
		scanf("%d",&elem);
		printf("\n");
		Head=InserisciInCoda(Head,elem);
	}
	
return Head;
}
void StampaLista(Lista Head){
	if(!ListaVuota(Head)){
		printf(" %d -> ",Head->info);
		StampaLista(Head->next);
		}
	else	
		printf(" NULL \n \n");
}

int MaxList(Lista Head){
	if(!ListaVuota(Head))
		return MaxListUtility(Head,INT_MIN);
}

int MaxListUtility(Lista Head,int max){
	if(!ListaVuota(Head)){
		
		max=MaxListUtility(Head->next,max);
		if(Head->info > max)
			max=Head->info;
		}
return max;
}

int MinList(Lista Head){
	if(!ListaVuota(Head))
		return MinListUtility(Head,INT_MAX);
}

int MinListUtility(Lista Head,int min){
	if(!ListaVuota(Head)){
		
		min=MinListUtility(Head->next,min);
		if(Head->info < min)
			min=Head->info;
		}
return min;
}

Lista EliminaElemento(Lista Head,int elem){
Lista App;
	if(!ListaVuota(Head)){
		if(Head->info!=elem)
			Head->next=EliminaElemento(Head->next,elem);
		else{
			App=Head;
			if(!ListaVuota(Head->next))
				Head->next->prev=App->next;
				Head=Head->next;
		}
	}
return Head;
}

int CheckThree(Lista Prova){
	int ris=0;
	int primo,secondo;
	if(!ListaVuota(Prova)){
		primo=Prova->info;
			if(!ListaVuota(Prova->next)){
				secondo=Prova->next->info;
					if(!ListaVuota(Prova->next->next))
						if(primo=secondo && secondo == Prova->next->next->info){
							ris=1;
							return ris;
							}
						else
							ris=CheckThree(Prova->next);
					}
				}
	return ris;
}
