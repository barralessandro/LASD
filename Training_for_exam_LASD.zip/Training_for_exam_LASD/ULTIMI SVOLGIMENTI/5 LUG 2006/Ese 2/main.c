#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"

void Gira(Lista *Head);

int main(){
		printf("ACQUISIZIONE LISTA UNO \n");
		Lista Uno=Riempi();
		
		printf("STAMPA LISTA UNO \n");
		StampaLista(Uno);
		
		
		Gira(&Uno);
		
		printf("STAMPA LISTA UNO DOPO FUNZIONE GIRA\n");
		StampaLista(Uno);
		
		return 0;
}


void Gira(Lista *Head){
int min,max;
	if(!ListaVuota((*Head)) && !CheckThree((*Head))){
		
		min=MinList((*Head));
		(*Head)=EliminaElemento((*Head),min);
	
	}
			
	if(!ListaVuota((*Head)) && !CheckThree((*Head))){
		
		max=MaxList((*Head));
		(*Head)=EliminaElemento((*Head),max);
	
		Gira(&(*Head));
	}
}
