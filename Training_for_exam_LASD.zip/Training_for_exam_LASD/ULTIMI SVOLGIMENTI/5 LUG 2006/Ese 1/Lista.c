#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"


int ListaVuota(Lista Head){
	return Head==NULL;
}

Lista AllocaNodo(int elem){
	Lista Head=malloc(sizeof(struct nodo));
	Head->info=elem;
	Head->next=NULL;
return Head;
}

Lista InserisciInTesta(Lista Head,int elem){
	Lista App=AllocaNodo(elem);
	if(!ListaVuota(Head))
		App->next=Head;
return App;
}

Lista InsOrdinato(Lista Head,int elem){
	if(!ListaVuota(Head)){
		if(Head->info < elem)
			Head->next=InsOrdinato(Head->next,elem);
		else	
			Head=InserisciInTesta(Head,elem);
		}
	else	
		Head=InserisciInTesta(Head,elem);
return Head;
}

Lista Riempi(){
int n,elem,i;
Lista Head=NULL;
	printf("Quanti elementi vuoi inserire nella lista? : ");
	scanf("%d",&n);
	printf("\n");
		while(n<1){
			printf("Devi inserire una dimensione maggiore o uguale ad 1 per la lista \n");
			printf("Quanti elementi vuoi inserire nella lista? : ");
			scanf("%d",&n);
			printf("\n");
		}
		for(i=0; i<n; i++){
			printf("Inserisci %d° elemento della lista: ",i+1);
			scanf("%d",&elem);
			Head=InsOrdinato(Head,elem);
			printf("\n");
		}
	return Head;
}

void StampaLista(Lista Head){
	if(!ListaVuota(Head)){
		printf(" %d -> ",Head->info);
		StampaLista(Head->next);
		}
	else	
		printf(" NULL \n \n");
}
