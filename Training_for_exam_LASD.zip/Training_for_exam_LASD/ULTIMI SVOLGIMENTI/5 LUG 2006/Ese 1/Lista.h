#ifndef LIBRARY_LIST_C
#define LIBRARY_LIST_C

struct nodo{
	int info;
    struct nodo* next;
};
typedef struct nodo* Lista;

int ListaVuota(Lista Head);

Lista InserisciInTesta(Lista Head,int elem);

Lista InsOrdinato(Lista Head,int elem);

Lista Riempi();

void StampaLista(Lista Head);

#endif
