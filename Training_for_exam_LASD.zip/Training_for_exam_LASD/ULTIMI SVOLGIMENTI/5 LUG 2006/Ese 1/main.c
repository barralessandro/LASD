#include <stdio.h>
#include <stdlib.h>
#include "queue.h"
#include "Lista.h"


Lista Esercizio(Queue A, Queue B);
Lista EsercizioUtility(Queue A, Queue B);

int main(int argc, const char * argv[]) {

    printf("Acquisizione coda uno \n");
    Queue uno = queueCreationMenu(0);
    
    printf("Stampa coda uno acquisita \n");
    printQueue(uno);
	
	printf("Acquisizione coda due \n");
    Queue due = queueCreationMenu(0);
    
    printf("Stampa coda due acquisita \n");
    printQueue(due);
    
	Lista Head=Esercizio(uno,due);
	printf("Stampa lista risultante: \n");
	StampaLista(Head);
	
	printf("++++++Stampa code dopo funzione esercizio \n");
	
	printf("Stampa coda uno \n");
    printQueue(uno);
	
	printf("Stampa coda due \n");
    printQueue(due);
    return 0;
}

Lista Esercizio(Queue A, Queue B){
	Lista Head=EsercizioUtility(A,B);
	reverseQueue(A);
	reverseQueue(B);
return Head;
}

Lista EsercizioUtility(Queue A, Queue B){
Lista Head=NULL;
int uno,due;
	if(!emptyQueue(A) && !emptyQueue(B)){
		uno=dequeue(A);
		due=dequeue(B);
		Head=EsercizioUtility(A,B);
		if(uno%2==1){
			Head=InsOrdinato(Head,uno);
			enqueue(A,uno);
			}
		else
			enqueue(A,uno);
		
		if(due%2==0){
			Head=InsOrdinato(Head,due);
			enqueue(B,due);
			}
		else
			enqueue(B,due);
	}
return Head;
}
