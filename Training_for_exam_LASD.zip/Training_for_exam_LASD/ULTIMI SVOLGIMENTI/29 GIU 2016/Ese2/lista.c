#include <stdlib.h>
#include <stdio.h>
#include "lista.h"


Lista AllocaNodo(int info){
  Lista Head=(struct listDoppiam*)malloc(sizeof(struct listDoppiam));
  Head->info=info;
  Head->prev=NULL;
  Head->next=NULL;
return Head;
}


int ListaVuota(Lista Head){
  return Head==NULL;
}


Lista InserisciTesta(Lista Head,int elem){
  Lista app=AllocaNodo(elem);
  if(!ListaVuota(Head)){
    app->next=Head;
    Head->prev=app->next;
    Head=app;
    return Head;
  }
  else
    return app;
}


Lista InserisciCoda(Lista Head,int elem){
  if(!ListaVuota(Head)){
    Head->next=InserisciCoda(Head->next,elem);
    Head->next->prev=Head;
  }
  else
    Head=AllocaNodo(elem);

return Head;
}


Lista riempi(){
int val,elem,i;
Lista Head=NULL;
  printf("Quanti elementi vuoi inserire nella lista? : ");
  scanf("%d",&elem);
  printf("\n");

  for(i=0;i<elem;i++){
    printf("Inserisci %d ° elemento della lista:  ",i+1);
    scanf("%d",&val);
    Head=InserisciCoda(Head,val);
    printf("\n");
  }
return Head;
}


void StampaLista(Lista Head){
  if(!ListaVuota(Head)){
    printf(" %d -> ",Head->info);
    StampaLista(Head->next);
  }
  else
    printf(" NULL \n");
}

Lista AggiornaTesta(Lista Head){
Lista temp=NULL;
  if(!ListaVuota(Head)){
    temp=Head;
    if(!ListaVuota(Head->next))
      Head->next->prev=temp->prev;
      Head=Head->next;
      free(temp);
  }
return Head;
}


Lista EliminaElem(Lista Head,int elem){
  Lista app;
  if(!ListaVuota(Head)){
    if(Head->info!=elem)
      Head->next=EliminaElem(Head->next,elem);
    else{
      app=Head;
      if(!ListaVuota(Head->next)){
        Head->next->prev=app->prev;
        Head=Head->next;
        }
      else
        Head=Head->next;
      }
    }
  free(app);
  return Head;
}

Lista InsOrdinato(Lista Head,int elem){
  if(!ListaVuota(Head)){
    if(Head->info<elem)
      Head->next=InsOrdinato(Head->next,elem);
    else
      Head=InserisciTesta(Head,elem);
  }
  else
      Head=InserisciTesta(Head,elem);
  return Head;
}

Lista SortList(Lista Head){
  int elem;
  Lista App=NULL;
  while(Head){
    elem=Head->info;
    App=InsOrdinato(App,elem);
    Head=Head->next;
  }
  deallocaLista(Head);
  return App;
}

void deallocaLista(Lista Head){
  if(!ListaVuota(Head)){
    deallocaLista(Head->next);
    free(Head);
  }
}

void rimuoviRipetizioniUtility(Lista *Head){
  int elem;
  if(!ListaVuota(*Head) && !ListaVuota((*Head)->next)){
    elem=(*Head)->info;
      if((*Head)->next->info==elem){
        (*Head)=EliminaElem((*Head),elem);
        rimuoviRipetizioniUtility(&(*Head));
        }
      else
        //rimuoviRipetizioni(&(*Head),&(*Succ)->next);
    rimuoviRipetizioniUtility(&(*Head)->next);
    }
}

void rimuoviRipetizioni(Lista *Uno, Lista *Due){
  (*Uno)=SortList((*Uno));
  (*Due)=SortList((*Due));
  rimuoviRipetizioniUtility(&(*Uno));
  rimuoviRipetizioniUtility(&(*Due));
}
