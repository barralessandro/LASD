#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tree.h"


int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    printf("Acquisizione albero T \n");
    Tree T = treeCreationMenu(0);
    printf("Stampa alberto T in preOrder \n");
    preOrderPrint(T);
    printf("\n");

    printf("La funzione ritorna %d   \n",checkAll(T));

    freeTree(T);
    printf("Albero deallocato \n");

    return 0;
}
