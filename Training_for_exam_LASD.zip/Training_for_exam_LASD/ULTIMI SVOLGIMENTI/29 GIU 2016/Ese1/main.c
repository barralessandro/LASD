#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main(int argc, char *argv[]) {

	printf("Creazione e inizializzazione stack uno \n");
	Stack uno=stackCreationMenu(0);
	printf("++Stampa stack uno \n");
	printStack(uno);

	printf("\n");

	printf("Creazione e inizializzazione stack due \n");
	Stack due=stackCreationMenu(0);
	printf("++Stampa stack due \n");
	printStack(due);

	gioco(uno,due);

	printf("\nStampa stack dopo gioco \n");
	printf("++Stampa stack uno \n");
	printStack(uno);
	printf("\n");
	printf("++Stampa stack due \n");
	printStack(due);

	free(uno);
	free(due);
	printf("\nStack deallocati \n");

	return 0;
}
