#include <stdlib.h>
#include <stdio.h>
#include "lista.h"


Lista AllocaNodo(int info){
  Lista Head=(struct listDoppiam*)malloc(sizeof(struct listDoppiam));
  Head->info=info;
  Head->prev=NULL;
  Head->next=NULL;
return Head;
}


int ListaVuota(Lista Head){
  return Head==NULL;
}


Lista InserisciTesta(Lista Head,int elem){
  Lista app=AllocaNodo(elem);
  if(!ListaVuota(Head)){
    app->next=Head;
    Head->prev=app->next;
    Head=app;
    return Head;
  }
  else
    return app;
}


Lista InserisciCoda(Lista Head,int elem){
  if(!ListaVuota(Head)){
    Head->next=InserisciCoda(Head->next,elem);
    Head->next->prev=Head;
  }
  else
    Head=AllocaNodo(elem);

return Head;
}


Lista riempi(){
int val,elem,i;
Lista Head=NULL;
  printf("Quanti elementi vuoi inserire nella lista? : ");
  scanf("%d",&elem);
  printf("\n");

  for(i=0;i<elem;i++){
    printf("Inserisci %d ° elemento della lista:  ",i+1);
    scanf("%d",&val);
    Head=InserisciCoda(Head,val);
    printf("\n");
  }
return Head;
}


void StampaLista(Lista Head){
  if(!ListaVuota(Head)){
    printf(" %d -> ",Head->info);
    StampaLista(Head->next);
  }
  else
    printf(" NULL \n");
}


void RimuoviOccorrenze(Lista *Head,int elem){
  if(!ListaVuota(*Head)){
      RimuoviOccorrenze(&(*Head)->next,elem);

      if((*Head)->info==elem){
        (*Head)=AggiornaTesta((*Head));
      }
  }
}


Lista AggiornaTesta(Lista Head){
Lista temp=NULL;
  if(!ListaVuota(Head)){
    temp=Head;
    if(!ListaVuota(Head->next))
      Head->next->prev=temp->prev;
      Head=Head->next;
      free(temp);
  }
return Head;
}
