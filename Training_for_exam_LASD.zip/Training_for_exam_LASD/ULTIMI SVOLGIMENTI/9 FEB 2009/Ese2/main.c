#include <stdlib.h>
#include <stdio.h>
#include "lista.h"

int main(){

int elem;


  printf("Acquisizione lista uno \n");
  Lista a=riempi();
  printf("Stampa lista uno acquisita\n");
  StampaLista(a);
  printf("\n");

  printf("Acquisizione lista due \n");
  Lista b=riempi();
  printf("Stampa lista due acquisita\n");
  StampaLista(b);
  printf("\n");

  printf("Inserisci numero di cui vuoi rimuovere le occorrenze: ");
  scanf("%d",&elem);
  printf("\n");

  RimuoviOccorrenze(&a,elem);
  RimuoviOccorrenze(&b,elem);

  printf("Stampa lista uno dopo eliminazione occorrenze\n");
  StampaLista(a);
  printf("\n");
  printf("Stampa lista due dopo eliminazione occorrenze\n");
  StampaLista(b);
  printf("\n");
  
  return 0;
}
