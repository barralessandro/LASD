#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    printf("creazione e inizializzazione grafo G\n");
    Graph G = graphCreationMenu(0);
    printf("Stampa grafo G \n");
    printGraph(G);
    printf("\n");

    printf("creazione e inizializzazione grafo H\n");
    Graph H = graphCreationMenu(0);
    printf("Stampa grafo H \n");
    printGraph(H);
    printf("\n");

    printf("Creazione grafo unione di G ed H \n");
    Graph T= GrafoT(G,H);
    printf("Stampa grafo T \n");
    printGraph(T);


    printf("Deallozazione grafi G - H - T \n");
    freeGraph(G);
    freeGraph(H);
    freeGraph(T);
    printf("Deallocati grafi G - H - T \n");
    return 0;
}
