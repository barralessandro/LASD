#include <stdio.h>
#include <stdlib.h>
#include "queue.h"


void moltiplica(Queue Q);
void moltiplicaUtility(Queue Q);

int main(int argc, const char * argv[]) {

    // Creo una coda
    Queue coda = queueCreationMenu(0);
    printf("Stampa coda appena creata \n");
    printQueue(coda);

    moltiplica(coda);
    printf("Stampa coda dopo funzione moltiplica \n");
    printQueue(coda);
    return 0;
}



void moltiplica(Queue Q){
  if(!emptyQueue(Q)){
    moltiplicaUtility(Q);
    reverseQueue(Q);
  }
  else
    printf("La funzione non puo' essere eseguita su una coda vuota \n");
}

void moltiplicaUtility(Queue Q){
  int uno,due,tre,prod;
  if(!emptyQueue(Q)){
    uno=dequeue(Q);
      if(!emptyQueue(Q)){
        due=dequeue(Q);
          if(!emptyQueue(Q)){
            tre=dequeue(Q);
            prod=uno*due*tre;
            moltiplicaUtility(Q);
            enqueue(Q,prod);
          }
          else{
            enqueue(Q,due);
            enqueue(Q,uno);
            }
          }
      else
            enqueue(Q,uno);
  }
}
