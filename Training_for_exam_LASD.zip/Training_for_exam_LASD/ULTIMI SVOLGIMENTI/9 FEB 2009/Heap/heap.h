#ifndef HEAP_C_LIBRARY
#define HEADP_C_LIBRARY

#define MAX 20
int ArraySize;
int HeapSize;

int left(int i);
int right(int i);
int p(int i);
void swap(int A[MAX], int i, int j);
void Heapify(int A[MAX], int i);
void BuildHeap(int A[MAX]);
void HeapSort(int A[MAX]);

int checkHeap(int A[MAX]);
void modificaElem(int A[MAX],int k,int val);
#endif
