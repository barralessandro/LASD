#include <stdlib.h>
#include <stdio.h>
#include "heap.h"


int left(int i)
{
	return 2*i+1;
}

int right(int i)
{
	return 2*i+2;
}

int p(int i)
{
	return (i-1)/2;
}

void swap(int A[MAX], int i, int j)
{
	int tmp = A[i];
	A[i] = A[j];
	A[j] = tmp;
}

void Heapify(int A[MAX], int i)
{
	int l,r,largest;
	l = left(i);
	r = right(i);
	if (l < HeapSize && A[l] > A[i])
		largest = l;
	else largest = i;
	if (r < HeapSize && A[r] > A[largest])
		largest = r;

	if (largest != i) {
		swap(A, i, largest);
		Heapify(A, largest);
	}
}

void BuildHeap(int A[MAX])
{
int i;
    HeapSize = ArraySize;
    for (i=ArraySize/2; i>=0; i--)
		Heapify(A, i);
}

void HeapSort(int A[MAX])
{
int i;
	BuildHeap(A);
	for (i=ArraySize-1; i>=1; i--) {
		swap(A, 0, i);
		HeapSize--;
		Heapify(A, 0);
	}
}

int checkHeap(int A[MAX]){
	int i,flag=1; //asserisco che sia uno Heap, se la funzione ritorna 0 non lo è
	for(i=0; i<HeapSize-2; i++)
		if(A[i]<A[2*i] || A[i]<A[2*i+1])
			flag=0;
return flag;
}

void modificaElem(int A[MAX],int k,int val){
	A[k]=A[k]+val;
	BuildHeap(A);
	printf("Proprietà Heap ripristinate \n");
}
