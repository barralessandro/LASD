#include <stdio.h>
#include <stdlib.h>
#include "heap.h"

#define MAX 20

int main() {

  int A[MAX];
  int tot;
  int k,ArraySize,HeapSize,val;

   printf("acquisizione heap UNO \n");
   printf("\nQuanti elementi deve contenere l'array (max %d elementi): ", MAX);
   scanf("%d",&tot);

   while (tot>MAX){
      printf("\n max %d MAX elementi: ", MAX);
      scanf("%d",&tot);
    }

   for (k=0;k<tot;k++){
  	 printf("\nInserire il %d° elemento: ",k+1);
  	 scanf("%d",&A[k]);
  	}

      HeapSize=tot;
      ArraySize=tot;
      BuildHeap(A);

      printf("\nArray Ordinato:");
      for (k=0;k<tot;k++)
         printf(" %d",A[k]);

    printf("\n");
    printf("Il risultato della funzione e' %d \n",checkHeap(A));


    printf("Inserire indice k dell'elemento da modificare: ");
    scanf("%d",&k);
    while(k<0 || k>ArraySize){
      printf("Puoi inserire un numero compreso fra 0 e %d ",HeapSize);
      printf("Inserire indice k dell'elemento da modificare: ");
      scanf("%d",&k);
    }
    printf("\n Inserisci valore da sommare ad A[k] =  %d  \n",A[k-1]);
    scanf("%d",&val);
    modificaElem(A,k-1,val);

    printf("Stampa array modificato \n");
    for (k=0;k<tot;k++)
       printf(" %d",A[k]);
    printf("\n");
return 0;
}
