#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

Graph EsercizioUtility(Graph G, Graph H,int *UscenteG, int *EntranteH);
Graph Esercizio(Graph G, Graph H);
void calcolaGradi(Graph G, int *entrante, int *uscente);

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("+++++ Acquisizione grafo G \n");
    Graph G = graphCreationMenu(0);
	printf("+++++ Stampa grafo G \n");
    printGraph(G);
	
	printf("+++++ Acquisizione grafo H \n");
    Graph H = graphCreationMenu(0);
	printf("+++++ Stampa grafo H \n");
    printGraph(H);
	
	Graph T=Esercizio(G,H);
	printf("+++++ Stampa grafo T \n");
    printGraph(T);
    
    freeGraph(G);
	freeGraph(H);
	freeGraph(T);
	printf("Grafi deallocati \n \n");
    return 0;
}

Graph Esercizio(Graph G, Graph H){
Graph T=NULL;
	if(G!=NULL && H!=NULL){
		int* entranteH=(int *)calloc(H->nodes_count,sizeof(int));
		int* uscenteH=(int *)calloc(H->nodes_count,sizeof(int));
		
		calcolaGradi(H,entranteH,uscenteH);
		
		T=EsercizioUtility(G,H,uscenteH,entranteH);
	}
return T;
}

void calcolaGradi(Graph G, int *entrante, int *uscente){
  int i;
  List app;
  if(G!=NULL){
    for(i=0; i<G->nodes_count; i++){
      app=G->adj[i];
      while(app){
          entrante[app->target]=entrante[app->target]+1;
          uscente[i]=uscente[i]+1;
          app=app->next;
        }
    }
  }
}

Graph EsercizioUtility(Graph G, Graph H,int *UscenteG, int *EntranteH){
List g=NULL,h=NULL;
int i,n,j,prezzo;
Graph T=NULL;
int *vertice,*costo;

	if(G!=NULL && H!=NULL){
	
		if(G->nodes_count < H->nodes_count)
			n=G->nodes_count;
		
		if(H->nodes_count <= G->nodes_count)
			n=H->nodes_count;
			
	T=initGraph(n);
	
		for(i=0; i<n; i++){
			vertice=(int *)calloc(n, sizeof(int));
			costo=(int *)calloc(n, sizeof(int));
			
			if(i<G->nodes_count){
				g=G->adj[i];
				while(g!=NULL){
					vertice[g->target]++;
					costo[g->target]=costo[g->target]+g->peso;
					g=g->next;
				}
			}
			
			if(i<H->nodes_count){
				h=H->adj[i];
				while(h!=NULL){
					vertice[h->target]++;
					costo[h->target]=costo[h->target]+h->peso;
					h=h->next;
				}
			}
			
			for(j=0; j<T->nodes_count; j++){
				if(vertice[j]==2){
					prezzo=costo[j]+UscenteG[i]+EntranteH[j];
					addEdge(T,i,j,prezzo);
				}
			}
			free(vertice);
			free(costo);
		}
	}
freeList(g);
freeList(h);
return T;
}
