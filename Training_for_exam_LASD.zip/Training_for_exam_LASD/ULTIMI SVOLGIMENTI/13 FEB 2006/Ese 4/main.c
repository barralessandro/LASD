#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tree.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("Acquisizione albero T \n");
    Tree T = treeCreationMenu(0);
    
    printf("Stampa albero T \n");
    preOrderPrint(T);
    
    printf("\n");
    
    if(CheckAbr(T))
    	printf("L'albero T è un albero binario di ricerca \n");
    else
    	printf("L'albero T non è un albero binario di ricerca \n");
   
    return 0;
}

