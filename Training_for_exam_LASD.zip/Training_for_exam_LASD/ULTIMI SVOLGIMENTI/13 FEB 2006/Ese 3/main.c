#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("Acquisizione grafo G \n");
    Graph G = graphCreationMenu(0);
    printf("Stampa grafo G \n");
    printGraph(G);
    
    G=ModificaArchi(G);
    printf("Stampa grafo G dopo rimozione archi con peso minimo \n");
    printGraph(G);
    printf("\n");
    
    freeGraph(G);
    printf("Grafo deallocato \n");
    return 0;
}

