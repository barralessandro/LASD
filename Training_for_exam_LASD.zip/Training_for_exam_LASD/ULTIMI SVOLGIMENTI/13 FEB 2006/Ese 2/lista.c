#include<stdio.h>
#include<stdlib.h>
#include "lista.h"


int ListaVuota(Lista Head){
	return Head==NULL;
}

Lista AllocaNodo(int elem){
	Lista App=malloc(sizeof(struct nodo));
	App->info=elem;
	App->next=NULL;
	App->prev=NULL;
return App;
}

Lista InserisciInTesta(Lista Head,int elem){
	Lista App=AllocaNodo(elem);
	if(!ListaVuota(Head))
		App->next=Head;
return App;
}

Lista InserisciInCoda(Lista Head,int elem){
	if(!ListaVuota(Head))
		Head->next=InserisciInCoda(Head->next,elem);
	else
		Head=AllocaNodo(elem);
return Head;
}

Lista InsOrd(Lista Head,int elem){
	if(!ListaVuota(Head)){
		if(Head->info<elem)
			Head->next=InsOrd(Head->next,elem);
		else
			Head=InserisciInTesta(Head,elem);
		}
	else
		Head=InserisciInTesta(Head,elem);
return Head;
}

Lista SortLista(Lista Head){
	Lista A=NULL;
	A=SortListaUtility(Head,NULL);
return A;
}

Lista SortListaUtility(Lista Head,Lista New){
	if(!ListaVuota(Head)){
		New=InsOrd(New,Head->info);
		New=SortListaUtility(Head->next,New);
	}
return New;
}

Lista EliminaRipetizioni(Lista Head){
	if(!ListaVuota(Head->next)){
		Head=SortLista(Head);
		Head=DelRipUtility(Head,Head->next);
	}
return Head;
}

Lista DelRipUtility(Lista Head,Lista Succ){
	if(!ListaVuota(Head) && !ListaVuota(Succ)){
		if(Head->info!=Succ->info)
			Head->next=DelRipUtility(Head->next,Succ->next);
		else{
			Head=EliminaElem(Head,Succ->info);
			Head=DelRipUtility(Head,Succ->next);
		}
	//Head=DelRipUtility(Head->next,Succ->next);
	}
return Head;
}

Lista EliminaElem(Lista Head,int elem){
Lista App=NULL;
	if(!ListaVuota(Head)){
		if(Head->info!=elem)
			Head->next=EliminaElem(Head->next,elem);
		else{
			App=Head;
			if(!ListaVuota(Head->next))
				Head->next->prev=App->next;
				Head=Head->next;
			}
		}
return Head;
}

void StampaLista(Lista Head){
	if(!ListaVuota(Head)){
		printf(" %d -> ",Head->info);
		StampaLista(Head->next);
		}
	else
		printf(" NULL \n \n");
}

Lista Riempi(){
int i,elem,n;
Lista Head=NULL;
	printf("Quanti elementi vuoi inserire nella lista? : ");
	scanf("%d",&n);
	printf("\n");
	while(n<1){
		printf("Devi inserire una dimensione maggiore o uguale ad 1 per la lista \n");
		printf("Quanti elementi vuoi inserire nella lista? : ");
		scanf("%d",&n);
	}
	for(i=0; i<n; i++){
		printf("Inserisci %d ° della lista: ",i+1);
		scanf("%d",&elem);
		Head=InserisciInCoda(Head,elem);
		printf("\n");
	}
return Head;
}

void TogliNegativi(Lista *Head){
Lista *App;
	if(!ListaVuota(*Head)){
		if((*Head)->info >= 0)
			TogliNegativi(&(*Head)->next);
		else {
			*App=*Head;
			if(!ListaVuota((*Head)->next))
				(*Head)->next->prev=(*App)->next;
				(*Head)=(*Head)->next;
				TogliNegativi(&(*Head));
			}
	}
}

void Esercizio(Lista *Uno, Lista *Due){
	TogliNegativi(&(*Uno));
	TogliNegativi(&(*Due));
	(*Uno)=EliminaRipetizioni((*Uno));
	(*Due)=EliminaRipetizioni((*Due));
}
