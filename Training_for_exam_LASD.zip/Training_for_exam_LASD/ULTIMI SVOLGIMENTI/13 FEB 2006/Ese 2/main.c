#include<stdio.h>
#include<stdlib.h>
#include "lista.h"

int main(){

	printf("Acquisizione lista Uno \n");
	Lista Uno=Riempi();
	
	printf("Stampa lista Uno acquisita \n");
	StampaLista(Uno);
	
	printf("Acquisizione lista Due \n");
	Lista Due=Riempi();
	
	printf("Stampa lista Due acquisita \n");
	StampaLista(Due);
	
	Esercizio(&Uno,&Due);
	
	printf("Stampa lista Uno dopo funzione esercizio \n");
	StampaLista(Uno);
	printf("Stampa lista Due dopo funzione esercizio \n");
	StampaLista(Due);
	
	return 0;	
}
