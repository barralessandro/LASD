#ifndef LIBRARY_LIST_C
#define LIBRARY_LIST_C

struct nodo{
	struct nodo* prev;
	int info;
	struct nodo* next;
};
typedef struct nodo* Lista;



int ListaVuota(Lista Head);

Lista AllocaNodo(int elem);

Lista InserisciInTesta(Lista Head,int elem);

Lista InserisciInCoda(Lista Head,int elem);

Lista InsOrd(Lista Head,int elem);

Lista SortLista(Lista Head);

Lista SortListaUtility(Lista Head,Lista New);

Lista EliminaRipetizioni(Lista Head);

Lista DelRipUtility(Lista Head,Lista Succ);

Lista EliminaElem(Lista Head,int elem);

void StampaLista(Lista Head);

Lista Riempi();

void TogliNegativi(Lista *Head);


void Esercizio(Lista *Uno, Lista *Due);
#endif
