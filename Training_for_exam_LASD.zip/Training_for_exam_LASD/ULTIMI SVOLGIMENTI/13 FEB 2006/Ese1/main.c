#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main(int argc, const char * argv[]) {

    printf("Acquisizione coda uno \n");
    Queue uno = queueCreationMenu(0);
    printf("Stampa coda uno \n");
    printQueue(uno);

    printf("\n");

    elimina_dispari(uno);
    printf("Stampa coda uno dopo gioco\n");
    printQueue(uno);
    return 0;
}
