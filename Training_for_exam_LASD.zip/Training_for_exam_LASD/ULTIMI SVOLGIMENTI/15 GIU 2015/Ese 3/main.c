#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"


int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    printf("Acquisizione grafo G \n");
    Graph G = graphCreationMenu(0);

    printf("Acquisizione grafo H \n");
    Graph H = graphCreationMenu(0);
    printf("Stampa grafo G \n");
    printGraph(G);
    printf("\n");

    printf("Stampa grafo H \n");
    printGraph(H);
    printf("\n");

    printf("Acquisizione lista \n");
    Lista A=Riempi();
    printf("Stampa lista \n");
    StampaLista(A);
    printf("\n");

    Graph T=Esercizio(G,H,A);
    printf("Stamap grafo risultante \n");
    printGraph(T);
    printf("\n");

    freeGraph(G);
    freeGraph(H);

    return 0;
}
