#include<stdlib.h>
#include<stdio.h>
#include "Liste.h"

Lista AllocaNodo(int elem){
  Lista App=malloc(sizeof(struct TLista));
  App->info=elem;
  App->next=NULL;
  App->prev=NULL;
  return App;
}

Lista InsertNodo(Lista Head,int elem){
  if(Head!=NULL)
    Head->next=InsertNodo(Head->next,elem);
  else
    Head=AllocaNodo(elem);
return Head;
}


void StampaLista(Lista Head){
  if(Head!=NULL){
    printf(" %d -> ",Head->info);
    StampaLista(Head->next);
  }
  else
    printf(" NULL ");
}


Lista Riempi(){
  int elem,i,val;
  Lista App=NULL;
  printf("acqusizione lista doppiamente puntata \n");
  printf("Quanti elementi vuoi inserire nella lista? ");
  scanf("%d",&elem);
  while(elem<1){
    printf("Devi inserire un numero maggiore o uguale ad uno \n");
    printf("Quanti elementi vuoi inserire nella lista? ");
    scanf("%d",&elem);
  }
  for(i=0;i<elem;i++){
    printf("Inserisci elemento %d : ",i+1);
    scanf("%d",&val);
    App=InsertNodo(App,val);
    printf("\n");
  }
  return App;
}

int checkElem(Lista Head,int elem){
  int ris=0;
  if(Head!=NULL){
    if(Head->info==elem)
      return 1;
    else
      return checkElem(Head->next,elem);
  }
return ris;
}
