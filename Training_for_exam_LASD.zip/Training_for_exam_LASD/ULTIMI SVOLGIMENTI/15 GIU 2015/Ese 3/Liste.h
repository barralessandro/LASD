#ifndef DOPPIE_C
#define DOPPIE_C

struct TLista{
  struct TLista* prev;
  int info;
  struct TLista* next;
};
typedef struct TLista* Lista;

Lista AllocaNodo(int elem);

Lista InsertNodo(Lista Head,int elem);

void StampaLista(Lista Head);

Lista Riempi();

int checkElem(Lista Head,int elem);
#endif
