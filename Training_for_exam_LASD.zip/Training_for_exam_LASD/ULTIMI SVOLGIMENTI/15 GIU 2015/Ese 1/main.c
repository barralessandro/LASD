#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main(int argc, char *argv[]) {

	printf("Acqisizione stack pari \n");
	Stack pari=stackCreationMenu(0);
	printf("Stampa stack pari \n");
	printStack(pari);
	printf("\n");

	printf("Acqisizione stack dispari \n");
	Stack dispari=stackCreationMenu(0);
	printf("Stampa stack dispari \n");
	printStack(dispari);
	printf("\n");


	gioco(pari,dispari);
	printf("Stampa stack dopo gioco \n");
	
	printf("pari \n");
	printStack(pari);
	printf("\n");

	printf("dispari \n");
	printStack(dispari);
	printf("\n");


	free(pari);
	free(dispari);
	return 0;
}
