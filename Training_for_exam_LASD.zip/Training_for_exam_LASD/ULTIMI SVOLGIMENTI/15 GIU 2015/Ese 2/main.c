#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tree.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    printf("Acquisizione albero T \n");
    Tree T = treeCreationMenu(0);
    printf("Stampa preOrder albero T \n");
    preOrderPrint(T);

    printf("Acquisizione albero T1 \n");
    Tree T1 = treeCreationMenu(0);
    printf("Stampa preOrder albero T1 \n");
    preOrderPrint(T1);

    Tree T2=SommaAlberi(T,T);
    printf("Albero binario contenente la somma creato \n");
    Ternario A=TernFromBst(T2);

    printf("Albero somma T2, copiato in un albero ternario \n");

    A=AddMiddleSon(A);
    printf("Aggiunto nodo centrale contenente la media dei fratelli \n");
    printf("Stampa albero finale \n");
    preOrderTernario(A);

    printf("\n");
    return 0;
}
