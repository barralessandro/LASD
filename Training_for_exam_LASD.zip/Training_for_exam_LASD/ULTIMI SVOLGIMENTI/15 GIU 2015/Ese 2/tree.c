#include <stdio.h>
#include <stdlib.h>
#include "tree.h"
#include "inputReader.h"

Tree randomTree(int nodes) {
    int i = 0;
    Tree T = NULL;
    for (i = 0; i < nodes; i++) {
        T = insertNodeTree(T, rand() % 40);
    }
    return T;
}

Tree treeCreationMenu(int n){
	int input=1;
	do{
		if(input==0 || input>3) printf("Nessuna azione associata al codice %d\n",input);
		printf("Seleziore il metodo di creazione del nuovo albero:\n");
		printf("1) Albero vuoto\n");
		printf("2) Albero popolato da valori forniti in input\n");
		printf("3) Albero popolato da valori random\n");
	} while(!getPositive(&input) || input>3 ||input ==0);

	if (n<=0) {
		do{
			printf("Quanti elementi da inserire?\n");
		}
		while(!getPositive(&n));
	}
	if(input==2){
		printf("Digita gli elementi da inserire : \n");
		Tree T = NULL;
		int i;
		for (i=0; i<n; i++) {
			printf("Mancano %d valori\n", n-i);
			while(!getInt(&input)){ printf("Il valore digitato non � un intero, riprovare.\n");};
			T = insertNodeTree(T, input);
		}
		return T;
	}
	else {
		return randomTree(n);
	}
}

Tree initNode(int info) {
    Tree T = (Tree)malloc(sizeof(struct TTree));
    T->info = info;
    T->sx = NULL;
    T->dx = NULL;
    return T;
}

Tree insertNodeTree(Tree T, int info) {
    if (T == NULL) {
        T = initNode(info);
    } else {
        if (T->info > info) {
            T->sx = insertNodeTree(T->sx, info);
        } else if (T->info < info) {
            T->dx = insertNodeTree(T->dx, info);
        }
    }
    return T;
}


void inOrder(Tree T) {
    if (T != NULL) {
        inOrder(T->sx);
        printf("%d ", T->info);
        inOrder(T->dx);
    }
}
void inOrderPrint(Tree T) {
	inOrder(T);
	printf("\n\n");
}

void preOrder(Tree T) {
    if (T != NULL) {
        printf("%d ", T->info);
        preOrder(T->sx);
        preOrder(T->dx);
    }
}
void preOrderPrint(Tree T) {
	preOrder(T);
	printf("\n\n");
}

void postOrder(Tree T) {
    if (T != NULL) {
        postOrder(T->sx);
        postOrder(T->dx);
        printf("%d ", T->info);
    }
}
void postOrderPrint(Tree T) {
	postOrder(T);
	printf("\n\n");
}

void graphic(Tree tree, char *str, int last){
    char tmp[100];
	if(tree!=NULL){
        //Cambia la modalit� di stampa se � l'ultimo figlio
        if(!last)
            printf("%s--%d\n", str, tree->info);
        else
            printf("%s\\-%d\n", str, tree->info);

        //Stampa i sottoalberi solo se almeno uno dei due non � vuoto
        if(tree->sx != NULL || tree->dx != NULL) {
            //Sceglie la stringa da stampare in base al sottoalbero dove si scende
            sprintf(tmp, "%s  |", str);
			graphic(tree->dx, tmp, 0);

            sprintf(tmp, "%s   ", str);
			graphic(tree->sx, tmp, 1);
        }
	}
    else {
        if(!last)
            printf("%s--NIL\n", str);
        else
            printf("%s\\-NIL\n", str);
    }
}
void graphicPrint(Tree T) { //Stampa graficamente in preorder l'albero
	graphic(T, "", 0);
}

void freeTree(Tree T) {
	if(T) {
		freeTree(T->sx);
		freeTree(T->dx);
		free(T);
	}
}

Tree SommaAlberi(Tree T, Tree T1){
  Tree T2=NULL;
  if(T!=NULL && T1!=NULL){
    T2=insertNodeTree(T2,T->info+T1->info);
    T2->sx=SommaAlberi(T->sx,T1->sx);
    T2->dx=SommaAlberi(T->dx,T1->dx);
  }
  return T2;
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Ternario initNodeTern(int info) {
    Ternario T = (Ternario)malloc(sizeof(struct TTern));
    T->info = info;
    T->sx = NULL;
    T->cx = NULL;
    T->dx = NULL;
    return T;
}

Ternario insertNodeTern(Ternario T, int info) {
    if (T == NULL) {
        T = initNodeTern(info);
    } else {
        if (T->info > info) {
            T->sx = insertNodeTern(T->sx, info);
        } else if (T->info < info) {
            T->dx = insertNodeTern(T->dx, info);
        }
    }
    return T;
}

void preOrderTernario(Ternario T) {
    if (T != NULL) {
        printf("%d ", T->info);
        preOrderTernario(T->sx);
        preOrderTernario(T->cx);
        preOrderTernario(T->dx);
    }
}

Ternario TernFromBst(Tree T){
  Ternario A=NULL;
  if(T!=NULL){
    A=insertNodeTern(A,T->info);
    A->sx=TernFromBst(T->sx);
    A->dx=TernFromBst(T->dx);
  }
return A;
}

Ternario AddMiddleSon(Ternario T){
  int val;
  if(T!=NULL){
    if(T->sx!=NULL && T->dx!=NULL){
      val=T->sx->info + T->dx->info;
      T->cx=initNodeTern(val/2);
    }
    //T->sx=AddMiddleSon(T->sx);
    //T->dx=AddMiddleSon(T->dx);
    T->sx=AddMiddleSon(T->sx);
    T->dx=AddMiddleSon(T->dx);
  }
  return T;
}
