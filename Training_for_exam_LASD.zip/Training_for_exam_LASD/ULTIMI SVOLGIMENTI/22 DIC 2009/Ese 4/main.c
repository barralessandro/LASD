#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("Acquisizione grafo G \n");
    Graph G = graphCreationMenu(0);
    
    printf("Stampa grafo G \n");
    printGraph(G);
    
    printf("Acquisizione grafo H \n");
    Graph H = graphCreationMenu(0);
   
    printf("Stampa grafo H \n");
    printGraph(H);
   
    //supponendo dim G < di dim H
    Graph T=CreaGrafo(G,H);
    printf("Stampa grafo T contenente archi in comune fra G e H \n");
    printGraph(T);
    
   /* 
    if(Esercizio(G,H))
    	printf("Il grado entrante dei vertici di G è uguale al grado uscente dei vertici di H\n");
    else
    	printf("Il grado entrante dei vertici di G NON è uguale al grado uscente dei vertici di H\n");
    	
    */	
    freeGraph(G);
    freeGraph(H);
    return 0;
}

