#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main(int argc, char *argv[]) {

	printf("Acquisizione stack uno \n");
	Stack Uno=stackCreationMenu(0);
	printf("Stampa stack uno acquisito \n");
	printStack(Uno);
			
	printf("Acquisizione stack due \n");
	Stack Due=stackCreationMenu(0);
	printf("Stampa stack due acquisito \n");
	printStack(Due);
	
	Gioco(Uno,Due);
	
	printf("++++++ Stampa stack dopo gioco +++++\n");
	printf("Stampa stack uno \n");
	printStack(Uno);
	printf("Stampa stack due \n");
	printStack(Due);
	
	printf("\n");
	free(Uno);
	free(Due);
	printf("Stack deallocato \n");
	return 0;
}
