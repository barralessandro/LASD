#include <stdio.h>
#include <stdlib.h>
#include "List.h"


int ListaVuota(Lista Head){
	return Head==NULL;
}


Lista AllocaNodo(int elem){
	Lista Head=malloc(sizeof(struct nodo));
	Head->info=elem;
	Head->next=NULL;
	Head->prev=NULL;
return Head;
}


Lista InserisciInTesta(Lista Head,int elem){
	Lista App=AllocaNodo(elem);
	if(!ListaVuota(Head)){
		App->next=Head;
		Head=App;
	}
return App;
}

Lista InserisciInCoda(Lista Head,int elem){
	if(!ListaVuota(Head))
		Head->next=InserisciInCoda(Head->next,elem);
	else
		Head=AllocaNodo(elem);
return Head;
}

void StampaLista(Lista Head){
	if(!ListaVuota(Head)){
		printf(" %d -> ",Head->info);
		StampaLista(Head->next);	
		}
	else
		printf(" NULL \n \n");
}

Lista Riempi(){
int i,elem,n;
Lista Head=NULL;
	printf("Quanti elementi vuoi inserire nella lista? : ");
	scanf("%d",&n);
	printf("\n");
	
	while(n<1){
		printf("Devi inserire una dimensione maggiore o uguale ad uno per la lista!! \n");
		printf("Quanti elementi vuoi inserire nella lista? : ");
		scanf("%d",&n);
		printf("\n");
	}
	
	for(i=0; i<n; i++){
		printf("Inserisci %d ° elemento della lista: ",i+1);
		scanf("%d",&elem);
		Head=InserisciInCoda(Head,elem);
		printf("\n");
	}
return Head;
}

Lista EliminaNegativi(Lista Head){
Lista App;
	if(!ListaVuota(Head)){
		if(Head->info >= 0)
			Head->next=EliminaNegativi(Head->next);
		else{
			App=Head;
			if(!ListaVuota(Head->next))
				Head->next->prev=App->next;
				Head=Head->next;
			Head=EliminaNegativi(Head);
		}
	}
return Head;
}


void EliminaDaListe(Lista *Uno,Lista *Due){
	if(!ListaVuota(*Uno) && !ListaVuota(*Due)){
	(*Uno)=EliminaNegativi((*Uno));
	(*Due)=EliminaNegativi((*Due));
	}
}


int CheckElem(Lista Head,int elem){
int ris=0;
	if(!ListaVuota(Head)){
		if(Head->info!=elem)
			return CheckElem(Head->next,elem);
		else{
			ris=1;
			return ris;
		}
	}
return ris;
}


Lista ControllaInserisci(Lista Uno,Lista *Due, int elem){
	if(!ListaVuota(Uno) && !ListaVuota((*Due))){
		if(!CheckElem(Uno,elem)){
			Uno=InserisciInCoda(Uno,(*Due)->info);
			Uno=ControllaInserisci(Uno,&(*Due)->next,elem);
			}	
		}
return Uno;
}

