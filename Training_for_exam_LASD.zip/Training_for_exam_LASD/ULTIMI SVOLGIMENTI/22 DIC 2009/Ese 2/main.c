#include <stdio.h>
#include <stdlib.h>
#include "List.h"


int main(){
int elem;

	printf("Acquisizione lista uno \n");
	Lista Uno=Riempi();
	printf("Stampa lista uno acquisita \n");
	StampaLista(Uno);
	
	printf("Acquisizione lista due \n");
	Lista Due=Riempi();
	printf("Stampa lista due acquisita \n");
	StampaLista(Due);
	
	
	printf("Inserisci elemento da ricercare: ");
	scanf("%d",&elem);
	printf("\n");
	//Uno=ControllaInserisci(Uno,&Due,elem);
	
	Uno=AccodaLista(Uno,Due);
	//EliminaDaListe(&Uno,&Due);
	printf("Stampa lista uno senza numeri negativi \n");
	StampaLista(Uno);
	
	printf("Stampa lista due senza numeri negativi \n");
	StampaLista(Due);
	
	return 0;
}
