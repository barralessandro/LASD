#ifndef LIBRARY_LIST_C
#define LIBRARY_LIST_C

struct nodo{
	struct nodo* prev;
	int info;
	struct nodo* next;
};
typedef struct nodo* Lista;



int ListaVuota(Lista Head);

Lista AllocaNodo(int elem);

Lista InserisciInTesta(Lista Head,int elem);

Lista InserisciInCoda(Lista Head,int elem);

void StampaLista(Lista Head);

Lista Riempi();

Lista EliminaNegativi(Lista Head);

void EliminaDaListe(Lista *Uno,Lista *Due);

Lista ControllaInserisci(Lista Uno,Lista *Due, int elem);

int CheckElem(Lista Head,int elem);
Lista AccodaLista(Lista Uno,Lista Due);
#endif
