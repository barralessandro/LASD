#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"

int main(){
	
		printf("+++ Acquisizione lista uno \n");
		Lista Uno=Riempi();
		printf("+++ Stampa lista uno acquisita \n");
		StampaLista(Uno);
		
		printf("+++ Acquisizione lista due \n");
		Lista Due=Riempi();
		printf("+++ Stampa lista due acquisita \n");
		StampaLista(Due);
		
		merge(&Uno,&Due);
		
		printf("+++ Stampa lista uno dopo merge \n");
		StampaLista(Uno);
		
		printf("+++ Stampa lista due dopo merge\n");
		StampaLista(Due);
		
		
		
		
return 0;
}
