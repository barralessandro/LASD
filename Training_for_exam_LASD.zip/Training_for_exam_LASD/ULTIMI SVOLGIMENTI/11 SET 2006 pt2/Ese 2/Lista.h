#ifndef LIBRARY_LIST_C
#define LIBRARY_LIST_C

struct nodo{	
	int info;
	struct nodo *next;
};
typedef struct nodo* Lista;

int ListaVuota(Lista Head);

Lista AllocaNodo(int elem);

Lista InserisciInTesta(Lista Head,int elem);

Lista InsOrdinato(Lista Head,int elem);

Lista Riempi();

void StampaLista(Lista Head);

Lista EliminaElem(Lista Head,int elem);

void merge(Lista *Uno, Lista *Due);
#endif
