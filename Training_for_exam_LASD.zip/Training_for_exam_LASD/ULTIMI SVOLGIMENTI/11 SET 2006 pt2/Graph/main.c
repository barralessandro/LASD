#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"
#include "stack.h"


void PuntoUno(Graph G, Graph H);

void PuntoDue(Graph G, Graph H);

Graph trasposto(Graph G);
void dfsVisit2(Graph G,int i,int *visitato,int *pred);
void dfsVisit(Graph G,int i,Stack S,int *visitato,int *pred);
void cfc(Graph G,int *pred);
int algoC(Graph G,int m);

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    Graph G,H;
	int n;
	do{
		printf("I due grafi devono avere la stessa dimensione! \n");
		printf("+++++ Acquisizione grafo G \n");
		G = graphCreationMenu(0);
		printf("+++++ Acquisizione grafo H \n");
		H = graphCreationMenu(0);
	}while(G->nodes_count!=H->nodes_count);
	
	printf("+++++ Stampa grafo G \n");
    printGraph(G);
	printf("+++++ Stampa grafo H \n");
//     printGraph(H);
	
	printf("Inserisci un intero per il punto 3 dell'esercizio: ");
	scanf("%d",&n);
	printf("\n");
	
	printf("La funzione ritorna %d \n \n",algoC(G,n));
/*
	PuntoUno(G,H);
	printf("Stampa grafi dopo punto uno \n");
	printf("+++++ Stampa grafo G \n");
    printGraph(G);
	printf("+++++ Stampa grafo H \n");
    printGraph(H);

	PuntoDue(G,H);
	printf("Stampa grafi dopo punto due \n");
	printf("+++++ Stampa grafo G \n");
    printGraph(G);
	printf("+++++ Stampa grafo H \n");
    printGraph(H);
*/	
    freeGraph(G);
	freeGraph(H);
	printf("Grafi deallocati \n");
    return 0;
}

void PuntoUno(Graph G, Graph H){
int i;
List g=NULL,h=NULL;
	if(G!=NULL && H!=NULL){
		for(i=0; i<G->nodes_count; i++){
			g=G->adj[i];
			h=H->adj[i];
			
			while(g){
				g->peso=g->target+i;
				g=g->next;
			}
			
			while(h){
				h->peso=h->target*i;
				h=h->next;
			}
		}
	}
freeList(g);
freeList(h);
}

void PuntoDue(Graph G, Graph H){
int i,costo,j;
List g=NULL,h=NULL;
int *adiacente, *peso;

	if(G!=NULL & H!=NULL){
		for(i=0; i<G->nodes_count; i++){
			g=G->adj[i];
			h=H->adj[i];
			
			adiacente=(int *)calloc(G->nodes_count,sizeof(int));
			peso=(int *)calloc(G->nodes_count,sizeof(int));
			
			while(h){
				adiacente[h->target]++;
				peso[h->target]=peso[h->target]+h->peso;
				h=h->next;
			}
			
			while(g){
				adiacente[g->target]++;
				peso[g->target]=peso[g->target]+g->peso;
				g=g->next;
			}
			
			for(j=0; j<G->nodes_count; j++){
				if(adiacente[j]==2){
					
					if(peso[j]%2==0)
						H->adj[i]=removeEdge(H,i,j);
					
					else if(peso[j]%2==1)
						G->adj[i]=removeEdge(G,i,j);
				}
			}
		}
	free(adiacente);
	free(peso);
	}
}

Graph trasposto(Graph G){
Graph Gt = initGraph(G->nodes_count);
int i;
List g;

  for (i=0;i<G->nodes_count;++i){
    for (g=G->adj[i];g;g=g->next){
      addEdge(Gt,g->target,i,g->peso);
    }
  }

return Gt;
}

void dfsVisit2(Graph G,int i,int *visitato,int *pred){
  List g;

    visitato[i] = 1;

    for (g=G->adj[i];g;g=g->next){

      if (visitato[g->target]==0){
        pred[g->target] = i;
        dfsVisit2(G,g->target,visitato,pred);
      }
      visitato[i]=2;
    }

}

void dfsVisit(Graph G,int i,Stack S,int *visitato,int *pred){

List g;

  visitato[i] = 1;

  for (g=G->adj[i];g;g=g->next){

    if (visitato[g->target]==0){
      pred[g->target] = i;
      dfsVisit(G,g->target,S,visitato,pred);
    }
    visitato[i]=2;
    push(S,i);
  }
}

void cfc(Graph G,int *pred){

int *visitato = (int*)calloc(G->nodes_count,sizeof(int));
int i,u;
List g;
Stack S = initStack();
Graph Gt = trasposto(G);

  for (i=0;i<G->nodes_count;++i){
    pred[i] = 0;
    visitato[i] = 0;
  }

  for (i=0;i<G->nodes_count;++i){
    if (visitato[i]==0){
      dfsVisit(G,i,S,visitato,pred);
    }

    for (i=0;i<G->nodes_count;++i){
      pred[i] = 0;
      visitato[i] = 0;
    }

    while (!(emptyStack(S))){
      u = pop(S);
      for (g=Gt->adj[u];g;g=g->next){
        if (visitato[g->target]==0){
          dfsVisit2(Gt,g->target,visitato,pred);
        }
      }
    }

  }

free(visitato);
}

int algoC(Graph G,int m){
int i,count=0;

int *pred = (int*)calloc(G->nodes_count,sizeof(int));

for (i=0;i<G->nodes_count;i++){
  pred[i] = -1;
}

  cfc(G,pred);

  for (i=0;i<G->nodes_count;i++){
    if (pred[i] >= 0){
      count++;
    }
  }
  if (count == m){
    return 1;
  }
  else {
    return 0;
  }
}
