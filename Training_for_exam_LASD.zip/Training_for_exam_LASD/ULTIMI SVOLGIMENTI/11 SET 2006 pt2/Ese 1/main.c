#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

void Esercizio(Stack Uno,Stack Due);
void EsercizioUtility(Stack Uno, Stack Due,int* puntiUno, int* puntiDue);

int main(int argc, char *argv[]) {
	
	printf("++++ Acqisizione stack uno \n");
	Stack Uno=stackCreationMenu(0);
	
	printf("++++ Stampa stack uno \n");
	printStack(Uno);
	
	printf("++++ Acqisizione stack due \n");
	Stack Due=stackCreationMenu(0);
	
	printf("++++ Stampa stack due \n");
	printStack(Due);
	
	Esercizio(Uno,Due);
	printf("++++ Stampa stack dopo Esercizio ++++ \n");
	
	printf("++++ Stampa stack uno \n");
	printStack(Uno);
	
	printf("++++ Stampa stack due \n");
	printStack(Due);
	
	free(Uno);
	free(Due);
	printf("Stack deallocati \n \n");
	return 0;
}


void Esercizio(Stack Uno,Stack Due){
	Stack copiaUno=Uno;
	Stack copiaDue=Due;
	int puntiUno=0,puntiDue=0;
	
	EsercizioUtility(copiaUno,copiaDue,&puntiUno,&puntiDue);
	if(puntiUno > puntiDue){
		printf("Il gioco è vinto dallo stack uno \n");
		Due->A[0]=0;
		}
	else if(puntiUno < puntiDue){
		printf("Il gioco è vinto dallo stack due \n");
		Uno->A[0]=0;
	}
	else	
		printf("Il gioco finisce in pareggio \n ");
}

void EsercizioUtility(Stack Uno, Stack Due,int* puntiUno, int* puntiDue){
	int a,b;
	if(!emptyStack(Uno) && !emptyStack(Due)){
		a=pop(Uno);
		b=pop(Due);
		
		EsercizioUtility(Uno,Due,puntiUno,puntiDue);
		
		if((a+b)%10 < 5){
			*puntiUno=*puntiUno+1;
			push(Uno,a);
			}
			
		if((a+b)%10 >= 5){
			*puntiDue=*puntiDue+1;
			push(Due,b);
		}
	}	
}
