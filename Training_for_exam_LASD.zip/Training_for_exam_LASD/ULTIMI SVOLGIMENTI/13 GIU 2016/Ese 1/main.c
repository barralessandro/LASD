#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main(int argc, const char * argv[]) {

    printf("acquisizione coda uno \n");
    Queue uno = queueCreationMenu(0);

    printf("acquisizione coda due \n");
    Queue due = queueCreationMenu(0);

    printf("Stampa coda uno acquisita \n");
    printQueue(uno);
    printf("\n");

    printf("Stampa coda due acquisita \n");
    printQueue(due);
    printf("\n");


    gioco(uno,due);
    printf("Stampa code dopo gioco \n");
    printf("Stampa coda uno\n");
    printQueue(uno);

    printf("Stampa coda due\n");
    printQueue(due);
    printf("\n");

    return 0;
}
