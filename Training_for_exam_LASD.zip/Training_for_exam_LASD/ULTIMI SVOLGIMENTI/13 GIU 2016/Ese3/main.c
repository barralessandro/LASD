#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tree.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    printf("Acquisizione albero T \n");
    Tree T = treeCreationMenu(0);
    printf("Stampa preOrder albeto T \n");
    preOrderPrint(T);
    printf("\n");

    printf("Acquisizione albero T1 \n");
    Tree T1 = treeCreationMenu(0);
    printf("Stampa preOrder albeto T1 \n");
    preOrderPrint(T1);
    printf("\n");


    Ternario A=Esercizio(T,T1);
    printf("Stampa albero ternario\n");
    preOrderTernario(A);
    printf("\n");

    return 0;
}
