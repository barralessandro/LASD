#include <stdio.h>
#include <stdlib.h>
#include "lista.h"


int ListaVuota(Lista Head){
	return Head==NULL;
}


Lista AllocaNodo(int elem){
	Lista App=malloc(sizeof(struct ListaDoppiam));
	App->info=elem;
	App->next=NULL;
	App->prev=NULL;
return App;
}


Lista InsCoda(Lista Head,int elem){
	if(ListaVuota(Head))
		Head=AllocaNodo(elem);
	else
		Head->next=InsCoda(Head->next,elem);

return Head;
}


Lista InsTesta(Lista Head,int elem){
	Lista app=AllocaNodo(elem);
	if(!ListaVuota(Head)){
		app->next=Head;
	}
return app;
}


Lista Riempi(){
	int n,elem,i;
	Lista app=NULL;
	printf("Quanti elementi vuoi inserire nella lista? : ");
	scanf("%d",&elem);

	while(elem<1){
		printf("Devi inserire una dimensione >= di 1 \n");
		printf("Quanti elementi vuoi inserire nella lista? : ");
		scanf("%d",&elem);
		printf("\n");
	}


	for(i=0; i<elem; i++){
		printf("Inserisci %d ° elemento della lista: ",i+1);
		scanf("%d",&n);
		app=InsCoda(app,n);
		printf("\n");
	}
return app;
}


void PrintList(Lista Head){
	if(!ListaVuota(Head)){
		printf(" %d ->",Head->info);
		PrintList(Head->next);
		}
	else
		printf(" NULL \n");
}


Lista EliminaElem(Lista Head,int elem){
	Lista app;
	if(!ListaVuota(Head)){
		if(Head->info!=elem)
			Head->next=EliminaElem(Head->next,elem);
		else{
			app=Head;
			if(!ListaVuota(Head->next)){
				Head->next->prev=app->prev;
				Head=Head->next;
				//Head=EliminaElem(Head,elem);
				}
			else
				Head=Head->next;
			}
		}
return Head;
}


void EliminaMultipliEdInserisci(Lista *Uno,Lista *Due,int elem){
	int a;
	if(!ListaVuota(*Uno)){
		EliminaMultipliEdInserisci(&(*Uno)->next,&(*Due),elem);
		if((*Uno)->info%elem==0){
			a=(*Uno)->info;
			(*Due)=InsTesta(*(Due),a);
			(*Uno)=EliminaElem((*Uno),a);
		}
	}
}
