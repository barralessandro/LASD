#ifndef LISTA_DOPPIAM_LIBRARY
#define LISTA_DOPPIAM_LIBRARY

struct ListaDoppiam{
  struct ListaDoppiam* prev;
  int info;
  struct ListaDoppiam* next;
};
typedef struct ListaDoppiam* Lista;


int ListaVuota(Lista Head);

Lista AllocaNodo(int elem);

Lista InsCoda(Lista Head,int elem);

Lista InsTesta(Lista Head,int elem);

Lista Riempi();

void PrintList(Lista Head);

//void EliminaMultipli(Lista *Head,Lista *Due,int elem);

//Lista EliminaMultipli(Lista Head,int elem);

Lista EliminaElem(Lista Head,int elem);

void EliminaMultipliEdInserisci(Lista *Uno,Lista *Due,int elem);

#endif
