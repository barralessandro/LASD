#include <stdio.h>
#include <stdlib.h>
#include "lista.h"


int main(){

	printf("Acquisizione lista uno \n");
	Lista a=Riempi();
	printf("Stampa lista uno \n");
	PrintList(a);
	printf("\n");

	printf("Acquisizione lista due \n");
	Lista b=Riempi();
	printf("Stampa lista due \n");
	PrintList(b);
	printf("\n");

	EliminaMultipliEdInserisci(&a,&b,2);
	EliminaMultipliEdInserisci(&b,&a,5);

	printf("Stampa liste modificate \n \n");

	printf("Stampa lista uno senza multipli di 2 ma con i multipli di 5 in lista due\n");
	PrintList(a);
	printf("\n");

	printf("Stampa lista due senza multipli di 5 ma con elementi di 2 in lista uno \n");
	PrintList(b);
	printf("\n");

	return 0;
}
