#ifndef LISTA_DOPPIAM_H
#define LISTA_DOPPIAM_H

struct nodo{
	struct nodo* prev;
	int info;
	struct nodo* next;
};
typedef struct nodo* Lista;


int EmptyLista(Lista Head);

Lista AllocaNodo(int elem);

Lista InsTesta(Lista Head,int elem);

Lista InsOrdinato(Lista Head,int elem);

Lista Riempi();

void PrintList(Lista Head);

Lista RemoveElem(Lista Head,int elem);

void merge(Lista *Uno, Lista *Due);

#endif
