#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"

int main() {

  printf("+++ Acquisizione lista uno \n");
  Lista uno=Riempi();
  printf("Stampa lista uno acquisita \n");
  PrintList(uno);
  printf("\n");

  printf("+++ Acquisizione lista due \n");
  Lista due=Riempi();
  printf("Stampa lista due acquisita \n");
  PrintList(due);
  printf("\n");

  merge(&uno,&due);

  printf("Stampa lista uno dopo funzione merge \n");
  PrintList(uno);

  printf("\n");

  printf("Stampa lista due dopo funzione merge \n");
  PrintList(due);

  printf("\n");

return 0;
}
