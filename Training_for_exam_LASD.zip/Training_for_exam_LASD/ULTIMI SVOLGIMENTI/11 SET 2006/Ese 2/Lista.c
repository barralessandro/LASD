#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"

int EmptyLista(Lista Head){
  return Head==NULL;
}

Lista AllocaNodo(int elem){
  Lista App=malloc(sizeof(struct nodo));
  App->info=elem;
  App->next=NULL;
  App->prev=NULL;
return App;
}

Lista InsTesta(Lista Head,int elem){
  Lista App=AllocaNodo(elem);
  if(!EmptyLista(Head))
    App->next=Head;

return App;
}

Lista InsOrdinato(Lista Head,int elem){
  if(!EmptyLista(Head)){
    if(Head->info < elem)
      Head->next=InsOrdinato(Head->next,elem);
    else
      Head=InsTesta(Head,elem);
    }
  else
    Head=AllocaNodo(elem);

  return Head;
}

Lista Riempi(){
  int n,elem,i;
  Lista Head=NULL;
  printf("Quanti elementi vuoi inserire nella lista? : ");
  scanf("%d",&n);

  while(n<1){
    printf("Devi inserire una dimensione maggiore o uguale ad 1 \n");
    printf("Quanti elementi vuoi inserire nella lista? : ");
    scanf("%d",&n);
  }
  for(i=0; i<n; i++){
    printf("Inserisci il %d ° elemento della lista: ",i+1);
    scanf("%d",&elem);
    Head=InsOrdinato(Head,elem);
    printf("\n");
  }
return Head;
}

void PrintList(Lista Head){
  if(!EmptyLista(Head)){
    printf(" %d -> ",Head->info);
    PrintList(Head->next);
  }
  else
    printf(" NULL \n");
}

Lista RemoveElem(Lista Head,int elem){
  Lista App;
  if(!EmptyLista(Head)){
    if(Head->info == elem){
      App=Head;
      if(!EmptyLista(Head->next)){
        Head->next->prev=App->prev;
        Head=Head->next;
        Head=RemoveElem(Head,elem);
      }
      else
        Head=Head->next;
      }
    else
      Head->next=RemoveElem(Head->next,elem);
    }
return Head;
}

void merge(Lista *Uno, Lista *Due){
  if(!EmptyLista(*Uno) && !EmptyLista(*Due)){
    if((*Due)->info%2==0){
      (*Uno)=InsOrdinato((*Uno),(*Due)->info);
      (*Due)=RemoveElem((*Due),(*Due)->info);
      merge(&(*Uno),&(*Due));
    }
    else
      merge(&(*Uno),&(*Due)->next);
  }
}
