#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main(int argc, char *argv[]) {

	printf("Acquisizione stack uno \n");
	Stack uno =stackCreationMenu(0);
	printf("Stampa stack uno \n");
	printStack(uno);
	printf("\n");

	printf("Acquisizione stack due \n");
	Stack due =stackCreationMenu(0);
	printf("Stampa stack due \n");
	printStack(due);

	gioco(uno,due);

	printf("Stampa stack dopo gioco \n");

	printf("Stack uno \n");
	printStack(uno);

	printf("\n");

	printf("Stack due \n");
	printStack(due);

	free(uno);
	free(due);
	printf("Stack deallocati \n");
	return 0;
}
