#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tree.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("Acquisizione albero T1 \n");
    Tree T1 = treeCreationMenu(0);
    printf("Stampa albero T1 \n");
    preOrderPrint(T1);
    printf("\n");
    
    printf("Acquisizione albero T2 \n");
    Tree T2 = treeCreationMenu(0);
    printf("Stampa albero T2 \n");
    preOrderPrint(T2);
    printf("\n");
    
    Tree T3=SommaAlberi(T1,T2);
    printf("Stampa albero risultante T3 \n");
    preOrderPrint(T3);
    printf("\n");
    
    Quadernario A= QuadFromBst(T1);
    A=AddMiddleSon(A);
    printf("Stampa albero quadernario dopo aggiunta figli centrali \n");
    preOrderQuadernario(A);
    printf("\n");
    
    
    return 0;
}

