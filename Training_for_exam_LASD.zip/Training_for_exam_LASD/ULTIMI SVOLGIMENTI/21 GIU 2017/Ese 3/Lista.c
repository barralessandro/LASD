#include <stdlib.h>
#include <stdio.h>
#include "Liste.h"


int ListEmpty(Lista Head){
	return Head==NULL;
}


Lista AllocaNodo(int elem){
	Lista Head=malloc(sizeof(struct nodo));
	Head->info=elem;
	Head->next=NULL;
	Head->prev=NULL;
return Head;
}

Lista InserisciInCoda(Lista Head, int elem){
	if(ListEmpty(Head))
		Head=AllocaNodo(elem);
	else
		Head->next=InserisciInCoda(Head->next,elem);
		
return Head;
}

void StampaLista(Lista Head){
	if(!ListEmpty(Head)){
		printf(" %d ->",Head->info);
		StampaLista(Head->next);
		}
	else
		printf(" NULL \n \n");
}

Lista Riempi(){
int i,n,elem;
Lista A=NULL;
	printf("Quanti elementi vuoi inserire nella lista? : ");
	scanf("%d",&n);
	
	while(n<1){
		printf("Devi inserire una dimensione maggiore o uguale ad 1 per la lista \n");
		printf("Quanti elementi vuoi inserire nella lista? : ");
		scanf("%d",&n);
	}
	for(i=0; i<n; i++){
		printf("Inserisci %d° elemento della lista: ",i+1);
		scanf("%d",&elem);
		A=InserisciInCoda(A,elem);
		printf("\n");
	}
return A;
}

int CheckElem(Lista Head,int elem){
int ris=0;
	if(!ListEmpty(Head)){
		if(Head->info!=elem)
			return CheckElem(Head->next,elem);
		else{
			ris=1;
			return ris;
			}
	}
return ris;
}

Lista EliminaElemento(Lista Head,int elem){
Lista App;
	if(!ListEmpty(Head)){
		if(Head->info!=elem)
			Head->next=EliminaElemento(Head->next,elem);
		else{
			App=Head;
			if(!ListEmpty(Head->next))
				//Head->prev->next=App->next;
				Head->next->prev=App->next;
				Head=Head->next;
		}
	}
return Head;
}
