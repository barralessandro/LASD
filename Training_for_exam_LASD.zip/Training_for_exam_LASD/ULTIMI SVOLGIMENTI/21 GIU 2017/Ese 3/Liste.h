#ifndef LIST_LIBRARY_C
#define LIST_LIBRARY_C

struct nodo{
	struct nodo* prev;
	int info;
	struct nodo* next;
};
typedef struct nodo* Lista;

int ListEmpty(Lista Head);

Lista AllocaNodo(int elem);

Lista InserisciInCoda(Lista Head,int elem);

void StampaLista(Lista Head);

Lista Riempi();

int CheckElem(Lista Head,int elem);

Lista EliminaElemento(Lista Head,int elem);

#endif
