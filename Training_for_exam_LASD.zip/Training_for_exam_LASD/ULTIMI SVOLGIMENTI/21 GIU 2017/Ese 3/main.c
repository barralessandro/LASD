#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

#include "Liste.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("Acquisizione grafo G \n");
    Graph G = graphCreationMenu(0);
    printf("Acquisizione grafo H \n");
    Graph H = graphCreationMenu(0);
    
    printf("Stampa grafo G \n");
    printGraph(G);
    printf("\n");
    
    printf("Stampa grafo H \n");
    printGraph(H);
    printf("\n");
    
    printf("Acquisizione lista doppiamente puntata \n");
    Lista A=Riempi();
    printf("Stampa lista doppiamente puntata acquisita \n");
    StampaLista(A);
    
      Graph T=NULL;
   		if(G->nodes_count < H->nodes_count)
			T=initGraph(G->nodes_count);
			
		if(H->nodes_count <= G->nodes_count)
			T=initGraph(H->nodes_count);
			
    T = EsercizioUtility(G,H,T,&A);
    printf("Stampa grafo T risultante \n");
    printGraph(T);
    printf("\n");
     printf("Stampa lista doppiamente dopo eserczio \n");
    StampaLista(A);
    
    freeGraph(G);
    freeGraph(H);
    freeGraph(T);
    
    printf("Grafi deallocati \n");
    return 0;
}

