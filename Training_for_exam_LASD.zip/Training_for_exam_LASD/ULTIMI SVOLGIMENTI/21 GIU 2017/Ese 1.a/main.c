#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main(int argc, char *argv[]) {

	printf("Acquisizione stack dritto \n");
	Stack dritto=stackCreationMenu(0);
	printf("Stampa stack dritto \n");
	printStack(dritto);
	
	printf("Acquisizione stack rovescio \n");
	Stack rovescio=stackCreationMenu(0);
	printf("Stampa stack rovescio \n");
	printStack(rovescio);	
		
	if(CheckReverseStack(dritto,rovescio))
		printf("I due stack sono reciprocamente inversi \n");
	else
		printf("I due stack non sono reciprocamente inversi \n");
	
	
	
	free(dritto);
	free(rovescio);	
	printf("Stack deallocati \n");
	return 0;
}
