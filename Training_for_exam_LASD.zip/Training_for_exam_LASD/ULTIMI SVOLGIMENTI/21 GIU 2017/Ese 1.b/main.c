#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main(int argc, const char * argv[]) {
    
    printf("Acquisizione coda uno \n");
    Queue uno = queueCreationMenu(0);
    
    printf("Stampa coda uno aquisita \n");
    printQueue(uno);
    
    printf("Acquisizione coda due \n");
    Queue due = queueCreationMenu(0);
    
    printf("Stampa coda due aquisita \n");
    printQueue(due);
    
    if(CheckReverseQueue(uno,due))
    	printf("Le due code sono reciprocamente inverse \n");
    else
    	printf("Le due code non sono reciprocamente inverse \n");
    	
    	
    return 0;
}
