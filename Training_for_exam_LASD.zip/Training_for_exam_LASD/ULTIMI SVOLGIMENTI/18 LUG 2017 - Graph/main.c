#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

Graph Esercizio(Graph G, Graph H);


int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("+++++ Acquisizione grafo G \n \n");
    Graph G = graphCreationMenu(0);
	printf("+++++ Stampa grafo G \n \n");
    printGraph(G);
	
	printf("+++++ Acquisizione grafo H \n \n");
    Graph H = graphCreationMenu(0);
	printf("+++++ Stampa grafo H \n \n");
    printGraph(H);
    
	
    G=Esercizio(G,H);
	printf("Stampa grafo G risultante \n \n ");
	printGraph(G);
	
    freeGraph(G);
	freeGraph(H);
// 	freeGraph(T);
 	printf("Grafi deallocati \n \n");
	return 0;
}


Graph Esercizio(Graph G, Graph H){
int i,flag;

List g=NULL,h=NULL;

int *vertice;
int *grado;

	if(G!=NULL && H!=NULL){
		for(i=0; i<G->nodes_count; i++){
			g=G->adj[i];
 			
			vertice=(int *)calloc(H->nodes_count, sizeof(int));
			grado=(int *)calloc(H->nodes_count, sizeof(int));
			
			if(i<H->nodes_count){
				h=H->adj[i];
				while(h){
					vertice[h->target]=vertice[h->target]+1;
					grado[h->target]=grado[h->target]+h->peso;
				h=h->next;
				}
				flag=1;
			}
			
 			while(g && flag){
				if(vertice[g->target]==1){
					g->peso=g->peso - grado[g->target];
					if(g->peso < 10)
						G->adj[i]=removeEdge(G,i,g->target);
				}
				g=g->next;
			}
			flag=0;
		}
	}
return G;
}
