#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main(int argc, const char * argv[]) {
    
    printf("Acquisizione coda A \n");
    Queue A = queueCreationMenu(0);
    
    printf("Acquisizione coda B \n");
    Queue B = queueCreationMenu(0);
    
    printf("Acquisizione coda C \n");
    Queue C = queueCreationMenu(0);
    
    printf("Acquisizione coda D \n");
    Queue D = queueCreationMenu(0);
    
    printf("Stampa code prima di gioco \n");
    printf("Stampa coda A acquisita \n");
    printQueue(A);
    printf("Stampa coda B acquisita \n");
    printQueue(B);
    printf("Stampa coda C acquisita \n");
    printQueue(C);
    printf("Stampa coda D acquisita \n");
    printQueue(D);
    
    GiocoDue(A,B,C,D);
    
    printf("+++++ Stampa code dopo gioco +++++\n\n");
    printf("Stampa coda A \n");
    printQueue(A);
    printf("Stampa coda B \n");
    printQueue(B);
    printf("Stampa coda C \n");
    printQueue(C);
    printf("Stampa coda D \n");
    printQueue(D);
    
    return 0;
}
