#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    printf("Acquisizione grafo G \n");
    Graph G = graphCreationMenu(0);
    printf("Stampa grafo G \n");
    printGraph(G);
    
    Graph G1=initGraph(G->nodes_count);
    Graph G2=initGraph(G->nodes_count);
    
    SplitGraph(&G,&G1,&G2);
    
    printf("Stampa grafo G1 con archi modulo 2\n");
    printGraph(G1);
    
    printf("Stampa grafo G2 con archi modulo 3\n");
    printGraph(G2);
    
    
    RimuoviNodiIsolati(G1,G2);

    printf("Stampa grafo G1 dopo rimozione nodi isolati \n");
    printGraph(G1);
    
    printf("Stampa grafo G2 dopo rimozione nodi isolati \n");
    printGraph(G2);
    
    if(CheckGraphEquals(G,G2))
      	printf("I due grafi sono uguali! \n");
    else
    	printf("I due grafi NON sonouguali! \n");
    	
    printf("\n");
    freeGraph(G);
    freeGraph(G1);
    freeGraph(G2);
    printf("Grafi deallocati \n");
    
    return 0;
}

