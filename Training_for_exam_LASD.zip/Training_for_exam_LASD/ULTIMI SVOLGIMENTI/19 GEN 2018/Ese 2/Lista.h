#ifndef LIBRARY_LIST_C
#define LIBRARY_LIST_C

struct nodo{
	struct nodo *prev;
	int info;
	struct nodo *next;
	};
typedef struct nodo* Lista;


int ListaVuota(Lista Head);

Lista AllocaNodo(int elem);

Lista InserisciInCoda(Lista Head,int elem);

void StampaLista(Lista Head);

Lista Riempi();

Lista EliminaElem(Lista Head, int elem);

void DeleteSomePosition(Lista *Uno, Lista *Due,int n);

void DeleteSomePositionUtility(Lista *Uno, Lista *Due);
#endif
