#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"


int ListaVuota(Lista Head){
	return Head==NULL;
}


Lista AllocaNodo(int elem){
	Lista Head=malloc(sizeof(struct nodo));
	Head->info=elem;
	Head->next=NULL;
	Head->prev=NULL;
return Head;
}


Lista InserisciInCoda(Lista Head,int elem){
	if(!ListaVuota(Head))
		Head->next=InserisciInCoda(Head->next,elem);
	else
		Head=AllocaNodo(elem);
return Head;	
}


void StampaLista(Lista Head){
	if(!ListaVuota(Head)){
		printf(" %d -> ",Head->info);
		StampaLista(Head->next);
		}
	else
		printf(" NULL \n \n");
}


Lista Riempi(){
int n,elem,i;
Lista Head=NULL;
	printf("Quanti elementi vuoi inserire nella lista?  :");
	scanf("%d",&n);
	printf("\n");
	while(n<1){
		printf("Devi inserire una dimensione maggiore o uguale ad 1 \n");
		printf("Quanti elementi vuoi inserire nella lista?  :");
		scanf("%d",&n);
		printf("\n");
	}
	
	for(i=0; i<n; i++){
		printf("Inserisci %d° elemento della lista ",i+1);
		scanf("%d",&elem);
		Head=InserisciInCoda(Head,elem);
		printf("\n");
	}
return Head;
}


Lista EliminaElem(Lista Head, int elem){
Lista App;
	if(!ListaVuota(Head)){
		if(Head->info!=elem)
			Head->next=EliminaElem(Head->next,elem);
		else{
			App=Head;
			if(!ListaVuota(Head->next))
				Head->next->prev=App->next;
				Head=Head->next;		
		}
	}
return Head;
}

void DeleteSomePosition(Lista *Uno, Lista *Due,int n){
	if(n>=1){
		if(!ListaVuota(*Uno) && !ListaVuota(*Due)){
			DeleteSomePositionUtility(Uno,Due);
		}
	n=n-1;
	DeleteSomePosition(&(*Uno),&(*Due),n);
	}
}

void DeleteSomePositionUtility(Lista *Uno, Lista *Due){
	if(!ListaVuota(*Uno) && !ListaVuota(*Due) ){
	
		if((*Uno)->info == (*Due)->info) {
			(*Uno)=EliminaElem((*Uno),(*Uno)->info);
			(*Due)=EliminaElem((*Due),(*Due)->info);
			//DeleteSomePositionUtility(&(*Uno),&(*Due));
		}
		else	
			DeleteSomePositionUtility(&(*Uno)->next,&(*Due)->next);
	}
}

