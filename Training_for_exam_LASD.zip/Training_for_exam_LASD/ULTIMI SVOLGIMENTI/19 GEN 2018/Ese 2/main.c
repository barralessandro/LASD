#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"


int main(){
int n;
	printf("Acquisizione lista Uno \n");
	Lista Uno = Riempi();
	printf("Stampa lista Uno acquisita : \n");
	StampaLista(Uno);
	

	printf("Acquisizione lista Due \n");
	Lista Due = Riempi();
	printf("Stampa lista Due acquisita : \n");
	StampaLista(Due);

	printf("Inserisci numero di volte da ricercare elementi uguali nelle due liste: ");
	scanf("%d",&n);
	printf("\n");
	
	DeleteSomePosition(&Uno,&Due,n);
	printf("Stampa lista Uno dopo elimina elem stessa posizione \n");
	StampaLista(Uno);
	
	printf("Stampa lista Due dopo elimina elem stessa posizione \n");
	StampaLista(Due);
	
	
return 0;
}
