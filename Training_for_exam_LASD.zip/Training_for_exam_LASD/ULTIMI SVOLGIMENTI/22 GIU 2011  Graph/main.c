#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "graph.h"

Graph Esercizio(Graph G, Graph H);

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
	
Graph G=NULL,H=NULL;

    do{
            printf("I DUE GRAFI DEVONO AVERE LA STESSA DIMENSIONE \n");
    	    printf("+++++ Acquisizione grafo G \n");
			G = graphCreationMenu(0);
	    
	
	    printf("+++++ Acquisizione grafo H \n");
	    H = graphCreationMenu(0);
  	}while(G->nodes_count != H->nodes_count);
  
	printf("+++++ Stampa grafo G \n");
	printGraph(G);
    	
    	printf("+++++ Stampa grafo H \n");
	printGraph(H);
	    
	printf("+++ Stampa grafi dopo funzione esercizio +++ \n");
	
	Graph T=Esercizio(G,H);
	printf("+++++ Stampa grafo T risultante \n");
    	printGraph(T);
    
    freeGraph(G);
	freeGraph(H);
	freeGraph(T);
	printf("Grafi deallocati \n");
    return 0;
}


Graph Esercizio(Graph G, Graph H){
int i,flag,p;
List g=NULL,h=NULL;
int *vertice,*costo;
Graph T=NULL;
	if(G!=NULL && H!=NULL){
		
		T=initGraph(H->nodes_count);
		
		for(i=0; i<H->nodes_count; i++){
			h=H->adj[i];
			g=G->adj[i];
			
			vertice=(int *)calloc(H->nodes_count,sizeof(int));
			costo=(int *)calloc(H->nodes_count,sizeof(int));
			
			if(i<G->nodes_count){
				while(g!=NULL){
					vertice[g->target]++;
					costo[g->target]=costo[g->target]+g->peso;
					g=g->next;
					} 
			flag=1;
			}
			
			while(h!=NULL && flag){
				if(vertice[h->target]==1){
					p=costo[h->target] - h->peso;
 					if(p >=0)
						addEdge(T,i,h->target,p);
				}
				else if(vertice[h->target]==0){ //l'arco è in H ma non in G
						addEdge(T,i,h->target,h->peso);
					}
				h=h->next;
			}
			flag=0;
			
		free(vertice);
		free(costo);
		}
	}
freeList(g);
freeList(h);
return T;
}

