#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"
//Struttura albero con tre nodi.
struct TTree_Tern {
    int info;
    struct TTree_Tern* sx;
    struct TTree_Tern* dx;
    struct TTree_Tern* middle;
};

typedef struct TTree_Tern* Tree_Tern;
Tree_Tern estensione(Tree T1,Tree T2,Tree_Tern T); //Funzione che estende T1.
Tree_Tern initNode_Tern(int info); //Inizializza nodo in albero ternario.
Tree_Tern insertNodeTree_Tern(Tree_Tern T, int info); //Inserisce nodo in albero ternario.
void inOrder_Tern(Tree_Tern T); //Stampa albero ternario.
int ricerca(Tree T1,int info,int ricercato); //Ricerca di un nodo.

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    
    Tree T1 = randomTree(10);  //Creo T1;
    Tree T2 = randomTree(10);  //Creo T2;
    Tree_Tern T=NULL;   //Creo T ternario.
   
    inOrder(T1); //Stampo T1;
    printf("\n"); 
    inOrder(T2);  //Stampo T2;
    printf("\n");
    T=estensione(T1,T2,T); //Torno in T il nuovo albero contenente i nodi di T1 e middle=1 se uguali a T2.
    inOrder_Tern(T); //Stampo T.
    
   
    return 0;
}

/*Questa funzione si occupa di estendere T1 nell'albero ternario T. Prende in input i due alberi binari e un albero ternario.
In output ritorna la radice del nuovo albero ternario.*/
Tree_Tern estensione(Tree T1,Tree T2,Tree_Tern T) {
    if (T1 != NULL) { //Se T1 è pieno...
	T=insertNodeTree_Tern(T,T1->info); //Copia T1 in T.
        if(ricerca(T2,T1->info,0)==1){  //Se T1->info è presente in T2...
	  T->middle=insertNodeTree_Tern(T->middle,1);} //...imposta T->middle=1.
        T->sx=estensione(T1->sx,T2,T->sx); //Scendi a sinistra
	T->dx=estensione(T1->dx,T2,T->dx); //Scendi a destra
        
    }    
       
return T;
         
        
    }

/*Ricerca di un valore all'interno dell'albero binario di ricerca. Ritorna ricercato=1 se lo trova,ricercato=0 altrimenti*/
int ricerca(Tree T1,int info,int ricercato){
	if(T1!=NULL && ricercato==0) {
	 if(T1->info==info)
    	    ricercato=1;
 	 else if(T1->info>info)  ricercato=ricerca(T1->sx,info,ricercato);
 	 else ricercato=ricerca(T1->dx,info,ricercato); }

return ricercato; }

/*Questa funzione si occupa di inizializzare un nuovo nodo dell'albero ternario.Ritorna il nuovo nodo.*/
Tree_Tern initNode_Tern(int info) {
    Tree_Tern T = malloc(sizeof(struct TTree_Tern));
    T->info = info;
    T->sx = NULL;
    T->dx = NULL;
    T->middle=NULL;
    return T;
}
/*Questa funzione si occupa di inserire nell'albero ternario un nuovo nodo. Ritorna la nuova testa dell'albero. */
Tree_Tern insertNodeTree_Tern(Tree_Tern T, int info) {
    if (T == NULL) {
        T = initNode_Tern(info);
    } else {
        if (T->info >= info) {
            T->sx = insertNodeTree_Tern(T->sx, info);
        } else if (T->info < info) {
            T->dx = insertNodeTree_Tern(T->dx, info);
        }
    }
    return T;
}

/*Stampa a video dell'albero ternario*/
void inOrder_Tern(Tree_Tern T) {
    if (T != NULL) {
        inOrder_Tern(T->sx);
        printf("%d ", T->info);
        if(T->middle!=NULL)
        printf("[%d]",T->middle->info);
        inOrder_Tern(T->dx);
    }
}

