#include <stdio.h>
#include "queue.h"
int main(int argc, const char * argv[]) {
    int err = 0;

    // Inizializzo una coda
    Queue Q = initQueue();
    enqueue(Q,3,&err);
    enqueue(Q,2,&err);
    enqueue(Q,2,&err);
    enqueue(Q,4,&err);
    enqueue(Q,1,&err);
    enqueue(Q,5,&err);
    enqueue(Q,7,&err);
    enqueue(Q,2,&err);

    printf("Stampa coda Q acquisita\n");
    printQueue(Q, &err);
    printf("\n");

    moltiplica(Q);

    // Stampo le code
    printf("Stampa coda Q dopo moltiplica \n");
    printQueue(Q, &err);
    printf("\n");





    return 0;
}
