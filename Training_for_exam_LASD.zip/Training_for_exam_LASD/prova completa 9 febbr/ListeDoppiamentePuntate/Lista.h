#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED


struct nodo{
	struct nodo *prev;
	int info;
	struct nodo *next;
};

typedef struct nodo *Lista;

//funzione di allocazione
Lista AllocaNodo();



//stampa la lista
void PrintList(Lista prova);

//funzione di inserimento con acquisiazione dimensione da tastiera (funzione iterativa)
Lista Riempi();

// ritorna 1 se la lista Head è vuota, 0 altrimenti
int ListEmpty(Lista Head);

//elimina il nodo con valore info uguale a val dalla lista
Lista eliminaNodo(Lista a, int val);

void deallocaLista(Lista Head);

Lista aggiornaHead(Lista Head);


void deleteElem(Lista *Head, int elem);

void eliminaRipetizioni(Lista *Uno, Lista *Due, int elem);
#endif
