#include<stdio.h>
#include<stdlib.h>
#include"Lista.h"

int main(){

	int elem;

	printf("Acquisizione lista uno \n");
	Lista a=Riempi();
	printf("Stampa lista uno acquisita \n");
	PrintList(a);
	printf("\n");

	printf("Acquisizione lista due \n");
	Lista b=Riempi();
	printf("Stampa lista due acquisita \n");
	PrintList(b);
	printf("\n");

	printf("Inserisci elemento di cui vuoi eliminare le ripetizioni da L1 e L2:  ");
	scanf("%d",&elem);
	printf("\n\n");


	eliminaRipetizioni(&a,&b,elem);

	printf("+ Stampa lista uno dopo eliminazione \n");
	PrintList(a);
	printf("\n \n");

	printf("+ Stampa lista due dopo eliminazione \n");
	PrintList(b);
	printf("\n");

	deallocaLista(a);
	deallocaLista(b);
	return 0;
}
