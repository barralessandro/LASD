#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    Tree T = NULL;
    T = insertNodeTree(T,10);
    T = insertNodeTree(T,16);
    T = insertNodeTree(T,7);
    T = insertNodeTree(T,19);
    T = insertNodeTree(T,4);
    T = insertNodeTree(T,3);
    T = insertNodeTree(T,5);

    printf("Stampa albero T \n");
    preOrder(T);
    printf("\n");
    printf("\n");
    Tree T1 = NULL;
    T1 = insertNodeTree(T1,10);
    T1 = insertNodeTree(T1,16);
    T1 = insertNodeTree(T1,7);
    T1 = insertNodeTree(T1,19);
    T1 = insertNodeTree(T1,4);
    T1 = insertNodeTree(T1,3);
    T1 = insertNodeTree(T1,5);

    printf("Stampa albero T1 \n");
    preOrder(T1);
    printf("\n");

    T= esercizioUno(T);
    printf("Stampa albero T dopo esercizioUno(T) \n");
    preOrder(T);
    printf("\n");
/*
    T1 = esercizioDue(T1);
    printf("Stampa albero T1 dopo esercizioDue(T1) \n");
    preOrder(T1);
    printf("\n");
*/
    return 0;
}
