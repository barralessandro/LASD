#include <stdio.h>
#include <stdlib.h>
#include "Tree.h"

Tree randomTree(int index) {
    int i = 0;
    Tree T = NULL;
    for (i = 0; i < index; i++) {
        T = insertNodeTree(T, rand() % 40);
    }
    return T;
}

Tree initNode(int info) {
    Tree T = malloc(sizeof(struct TTree));
    T->info = info;
    T->sx = NULL;
    T->dx = NULL;
    return T;
}

Tree insertNodeTree(Tree T, int info) {
    if (T == NULL) {
        T = initNode(info);
    } else {
        if (T->info > info) {
            T->sx = insertNodeTree(T->sx, info);
        } else if (T->info < info) {
            T->dx = insertNodeTree(T->dx, info);
        }
    }
    return T;
}


void inOrder(Tree T) {
    if (T != NULL) {
        inOrder(T->sx);
        printf("%d ", T->info);
        inOrder(T->dx);
    }
}

void preOrder(Tree T) {
    if (T != NULL) {
        printf("%d ", T->info);
        preOrder(T->sx);
        preOrder(T->dx);
    }
}

void postOrder(Tree T) {
    if (T != NULL) {
        postOrder(T->sx);
        postOrder(T->dx);
        printf("%d ", T->info);
    }
}

Tree staccaMin(Tree T, Tree P){
  if(T!=NULL){
    if(T->sx!=NULL)
      return staccaMin(T->sx,T);
    else
      if(T == P->sx)
        P->sx = T->dx;
      else
      P->dx = T->dx;
  }
  return T;
}


Tree deleteNode(Tree T,int k){
  Tree nodo=NULL;
  if(T!=NULL){
    if(T->info>k)
      T->sx=deleteNode(T->sx,k);
    else if(T->info<k)
      T->dx=deleteNode(T->dx,k);
    else{
    if(T->info==k) //quando trovo il nodo
      nodo=T;
      if(nodo->dx==NULL)
        T=nodo->sx;
      else
        if(nodo->sx==NULL)
          T=nodo->dx;
        else{
          nodo=staccaMin(T,NULL);
          T->info=nodo->info;
          free(nodo);
        }
      }
    }
  free(nodo);
return T;
}


/*implementare una funzione che rimuova da T1 tutti i nodi con valore inforadice
minore della metà della somma dei suoi figli e da T2 quelli con valore maggiore. */
/*Tree esercizioUno(Tree T){
  int val;
  if(T!=NULL){
    T->sx = esercizioUno(T->sx);
    T->dx = esercizioUno(T->dx);
      if(T->sx != NULL && T->dx != NULL){
          val=(T->sx->info + T->dx->info)/2;
          if(T->info < val)
            T=deleteNode(T,T->info);

          }
        }
  return T;
}*/

Tree esercizioUno(Tree T){
  int val;
  if(T!=NULL){
    if(T->sx != NULL && T->dx != NULL){
        val=(T->sx->info + T->dx->info)/2;
        if(T->info < val)
          T=deleteNode(T,T->info);
        }
  T->sx=esercizioUno(T->sx);
  T->dx=esercizioUno(T->dx);
  }
  return T;
}

Tree esercizioDue(Tree T){
  int val;
  if(T!=NULL){
    T = esercizioDue(T->sx);
    T = esercizioDue(T->dx);
      if(T->sx != NULL && T->dx != NULL){
          val=(T->sx->info + T->dx->info)/2;
          if(T->info > val){
            T=deleteNode(T,T->info);
            }
          }
        }
  return T;
}
