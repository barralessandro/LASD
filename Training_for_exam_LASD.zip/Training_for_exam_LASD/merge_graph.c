/* GRAFI - UNIONE*/
//supposto G->nodes_count < H->nodes_count
Graph esercizio(Graph G, Graph H){
	Graph T = initGraph(H->nodes_count);
	List g,h;
	int i,j,peso,flag;
	int aux1 = (int)calloc(H->nodes_count,sizeof(int));
	int aux2 = (int)calloc(H->nodes_count,sizeof(int));
	for(i = 0; i < H->nodes_count; ++i){
		flag = 0;
		if(i < G->nodes_count){
			g = G->adj[i];
			flag = 1;
		}
		h = H->adj[i];
		while(h){
			aux1[h->target] = h->peso;
			aux2[h->target] = 1;
			h = h->next;
		}
		while(g && flag){
			if(aux2[g->target] == 1){
                              //arco in comune
				
				/*Inizio condizione peso*/
				//se aux1[g->target] > g->peso peso = aux1[g->target] altrimenti peso = g->peso
				peso = aux1[g->target] > g->peso ? aux1[g->target] : g->peso;
				addEdge(T,i,g->target,peso);
				
				aux2[g->target] = 0;
			}
			else
			//arco presente solo in G
				addEdge(T,i,g->target,g->peso);
			g = g->next;
		}
		//arco presente solo in H
		for(j = 0; j < H->nodes_count; ++j)
			if(aux2[j] == 1){
				addEdge(T,i,j,aux1[j]);
				aux2[j] = 0;
		}
	}
	return T;
}

